GIT_BASE_URL = "https://vaprd078.schneider.com/schneider/"
GIT_CREDENTIAL = 'eebde66b-39b8-4483-9ba0-7dc8d5d209da'
GIT_DOMAIN = "vaprd078.schneider.com/schneider/"
AWS_ECR_URL = "212713346890.dkr.ecr.us-west-2.amazonaws.com"

GIT_CLOUD_BASE_URL = "git@github.com:schneidertech/"
GIT_CLOUD_CREDENTIAL = 'externalgithub-snideployer'

K8S_DEPLOYMENT_YAML = "deployment.yml"
DEPLOYMENT_ARTIFACTS_REPO = "foundation-deployment-artifacts"
XL_DEPLOYIT_MANIFEST_FILE_NAME = "deployit-manifest.xml"
SONAR_URL = "http://uxunt2601:8080/sonarqube"
// AWS ECR command to print the docker login command with token
ECR_LOGIN = "/export/home/sa_xebiaadm/bin/aws ecr get-login --no-include-email --region us-west-2"
// AWS ECR command to list all repository
ECR_DESC_REPO = "/export/home/sa_xebiaadm/bin/aws ecr describe-repositories --repository-names"
// AWS ECR command to create a repository
ECR_CREATE_REPO = "/export/home/sa_xebiaadm/bin/aws ecr create-repository --repository-name"
// COMPOSER_AUTH is a github oauth token used to get the common packages from github when building php using composer inside docker build
COMPOSER_AUTH="{\"github-oauth\":{\"github.com\": \"ef7b92c6a4c5a1c30bcd37baa2f8a06e802125e6\"}}"
//Add a lifecycle policy for the ecr repository to remove untagged immages
ECR_REPO_LIFECYCLE_POLICY="{
    \"rules\": [
        {
            \"rulePriority\": 1,
            \"description\": \"Expire images if more than 3\",
            \"selection\": {
                \"tagStatus\": \"untagged\",
                \"countType\": \"imageCountMoreThan\",
                \"countNumber\": 3
            },
            \"action\": {
                \"type\": \"expire\"
            }
        }
    ]
}"

XLD_FOLDER_PREFIX = "Cloud/EKS/Services"

REPO_NAME = GitRepoName.trim()
GIT_BRANCH_NAME = GitBranchName.trim()
REPO_LOCATION = GitRepoLocation.trim()
PROJECT_NAMESPACE = ProjectNamespace.trim()
XLD_FOLDER = XLDFolder.trim()


XLD_RESOURCE_NODE = """<k8s.ResourcesFile name=\"/{{REPO_NAME}}-{{RESOURCE_FOLDER_NAME}}\" file=\"{{RESOURCE_FOLDER_PATH}}\"><tags><value>${PROJECT_NAMESPACE}</value></tags><scanPlaceholders>true</scanPlaceholders><preScannedPlaceholders>true</preScannedPlaceholders><placeholders /><delimiters>{{ }}</delimiters></k8s.ResourcesFile>"""
node('prd-xebia-build-agent') {
    stage("Execute Build Job - ${REPO_NAME}") {  

        if(REPO_NAME == "") {
            error "Build Parameter - GitRepoName is missing"
        }
        if(GIT_BRANCH_NAME == "") {
            error "Build Parameter - GitBranchName is missing"
        }
        if(XLD_FOLDER == "") {
            error "Build Parameter - XLDFolder is missing"
        }
        if(PROJECT_NAMESPACE == "") {
            error "Build Parameter - ProjectNamespace is missing"
        }
        executeBuildFlowFor(REPO_NAME, GIT_BRANCH_NAME)
        println '********* Execute Build Job Successful **********'
    }
}

def executeBuildFlowFor (repoName, branchName) {
    stage("Git Checkout") {
        if(REPO_LOCATION == "Cloud") {
            println "******** Checking out source code from External Git *********"
            dir(path: "${repoName}") {
                def repoUrl = GIT_CLOUD_BASE_URL + repoName + '.git'
                git branch: branchName, credentialsId: 'externalgithub-snideployer', url: repoUrl
                env.gitCommitId = sh(returnStdout: true, script: "git log -n 1 --pretty=format:'%h'").take(7)
                println "******** External Git Checkout Successful *********"
            }
        }
        else {
            println "******** Checking out source code from Internal Git *********"
            gitCheckoutFor(repoName, branchName)
            env.gitCommitId = getLatestCommitIdFor(repoName, branchName)
            println "******** Internal Git Checkout Successful *********"
        }
    } 
    stage("Build & Push Docker Image to ECR") {

        gitCheckoutFor(DEPLOYMENT_ARTIFACTS_REPO, "master")   
        
        println "*********** Build and Push Docker Image *************"
        buildandPushDockerImage(repoName, env.gitCommitId)
        println "*********** Build and Push Image Successful *************"
    }

    stage("Build XL Deploy DAR Package") {

        sh("cp -r ./${repoName}/k8s/* ./${repoName}")
        sh "cp ./${DEPLOYMENT_ARTIFACTS_REPO}/xebia/AWS/${XL_DEPLOYIT_MANIFEST_FILE_NAME} ${repoName}/${XL_DEPLOYIT_MANIFEST_FILE_NAME}"
        resourceFiles = sh(
                    script: "find ./${repoName}/k8s/ -name '*.yml' -print",
                    returnStdout: true
            ).trim()

        resourceFiles = resourceFiles.replace("./${repoName}/k8s", "")
        println "************ Resources in k8s Folder ************"
        println "${resourceFiles}"

        xldResourcesNode = generateResourcesOnXLDManifestFile(repoName, resourceFiles)     
        println("************* Generated XLD Resources Node *****************")
        println "${xldResourcesNode}"

        sh("sed -i 's~{{IMAGE_VERSION}}~${BUILD_NUMBER}-${env.gitCommitId}~g' ${repoName}/${K8S_DEPLOYMENT_YAML}");
        sh("sed -i 's~{{XLD_FOLDER_PREFIX}}~${XLD_FOLDER_PREFIX}~g' ${repoName}/${XL_DEPLOYIT_MANIFEST_FILE_NAME}");
        sh("sed -i 's~{{ARTIFACT_VERSION}}~${BUILD_NUMBER}-${env.gitCommitId}~g' ${repoName}/${XL_DEPLOYIT_MANIFEST_FILE_NAME}");
        sh("sed -i 's~{{XLD_FOLDER}}~${XLD_FOLDER}~g' ${repoName}/${XL_DEPLOYIT_MANIFEST_FILE_NAME}");
        if(XLD_FOLDER.equalsIgnoreCase("Snapshots")) {
            sh("sed -i 's~{{REPO_NAME}}~${repoName}-snapshot~g' ${repoName}/${XL_DEPLOYIT_MANIFEST_FILE_NAME}");
        }
        else {
            sh("sed -i 's~{{REPO_NAME}}~${repoName}~g' ${repoName}/${XL_DEPLOYIT_MANIFEST_FILE_NAME}");
        }
        sh("sed -i 's~{{REPO_NAME}}~${repoName}~g' ${repoName}/${XL_DEPLOYIT_MANIFEST_FILE_NAME}");
        sh("sed -i 's~{{XLD_RESOURCES_NODES}}~${xldResourcesNode}~g' ${repoName}/${XL_DEPLOYIT_MANIFEST_FILE_NAME}");

        xldCreatePackage artifactsPath: "", manifestPath: "${repoName}/${XL_DEPLOYIT_MANIFEST_FILE_NAME}", darPath: "${repoName}/${repoName}-${gitCommitId}.dar" 
        println "### Build XL Deploy DAR Package Successful ###";
    }

    stage('XL Deploy Publish') {  
        xldPublishPackage serverCredentials: 'XldCreds', darPath: "${repoName}/${repoName}-${gitCommitId}.dar"
        println "Pushed docker image with version ${gitCommitId}"
        println "Cleaning up workspace ..."
        dir(path: "${repoName}") {
            deleteDir()
        }
        println "### XL Deploy Publish Successful ###"
    }
}

def gitCheckoutFor(repoName, branchName) {
    withCredentials([
         [$class: 'UsernamePasswordMultiBinding', credentialsId: 'internalgithub-snideployer', usernameVariable: 'GIT_USERNAME', passwordVariable: 'GIT_PASSWORD']
        ]) {
            def repoUrl = repoName + '.git'
            println "Pulling code for repoUrl =" + repoUrl
            sh("rm -rf ${repoName}")
            sh("git clone --branch ${branchName} https://${GIT_USERNAME}:${GIT_PASSWORD}@${GIT_DOMAIN}${repoUrl} ${repoName}")
        }
}

def buildandPushDockerImage(repoName, gitCommitId){
    dir(path: "${repoName}") {
        env.datetime = new Date().format( 'yyyyMMddHHmmssSSS' )
        ECR_LOGIN_CMD = sh(
                        script: "${ECR_LOGIN}",
                        returnStdout: true
                ).trim()
        sh("${ECR_LOGIN_CMD}")
        sh("docker build -t ${AWS_ECR_URL}/${repoName}:${datetime}-${gitCommitId} -t ${AWS_ECR_URL}/${repoName}:latest --build-arg COMPOSER_AUTH=\"${COMPOSER_AUTH}\" .")
        
        def status = sh(returnStatus: true, script: "${ECR_DESC_REPO} ${repoName}")
        if (status != 0) {
            println "Repository does not exist in ECR- Creating"
            sh("${ECR_CREATE_REPO} ${repoName}")
            sh("echo ${ECR_REPO_LIFECYCLE_POLICY} > lifecycle-policy.json")
            sh("aws ecr put-lifecycle-policy --repository-name ${repoName} --lifecycle-policy-text file://lifecycle-policy.json")
        }
        sh("docker push ${AWS_ECR_URL}/${repoName}:${datetime}-${gitCommitId}")
        sh("docker push ${AWS_ECR_URL}/${repoName}:latest")
        sh("docker rmi ${AWS_ECR_URL}/${repoName}:${datetime}-${gitCommitId}")
        sh("docker rmi ${AWS_ECR_URL}/${repoName}:latest")
    }
}

def getLatestCommitIdFor(repoName, branchName) {
    withCredentials([
         [$class: 'UsernamePasswordMultiBinding', credentialsId: 'internalgithub-snideployer', usernameVariable: 'GIT_USERNAME', passwordVariable: 'GIT_PASSWORD']
         ]) {
            latestGitCommitId = sh(
                    script: "git ls-remote https://${GIT_USERNAME}:${GIT_PASSWORD}@${GIT_DOMAIN}${repoName} ${branchName} | cut -f1",
                    returnStdout: true
            ).trim()
        }
    return latestGitCommitId.substring(0,7)
}

def generateResourcesOnXLDManifestFile(repoName, resourceFiles) {
    def xldResourcesNode = "";
    ymlFiles = resourceFiles.split('\n');

    def resourceNames = ["configmap", "secret", "deployment", "autoscaling","service", "ingress"]
    def order = 1
    
    for(int index=0; index < resourceNames.size(); index++) {
        ymlFiles.each() {
            if(it) {
                if(it.contains(resourceNames[index])) {
                    resourceNode = "${XLD_RESOURCE_NODE}";
                    resourceNode = resourceNode.replace("{{RESOURCE_FOLDER_PATH}}", repoName+"/"+it);
                    resourceNode = resourceNode.replace("{{REPO_NAME}}", order + "-" + repoName);
                    println "Updating resource file name for ${resourceNames[index]} = " + it.contains(resourceNames[index])
                    resourceNode = resourceNode.replace("{{RESOURCE_FOLDER_NAME}}", it.split("/")[1]);
                    order++
                    xldResourcesNode = xldResourcesNode + resourceNode;
                }
            }
            else {
                error "Unable to retrieve the Yml files inside k8s folder for ${repoName}";
            }
        }
    }
    return xldResourcesNode;
}