GIT_BASE_URL = "https://vaprd078.schneider.com/schneider/"
GIT_CREDENTIAL = 'eebde66b-39b8-4483-9ba0-7dc8d5d209da'
GIT_DOMAIN = "vaprd078.schneider.com/schneider/"
DOCKER_REGISTRY_URL = "dockerregistryunt1.intra.schneider.com"
DOCKER_REGISTRY_USERNAME = "dockerregistry"
DOCKER_REGISTRY_PASSWORD = "dockerregistry42018"
DEPLOYMENT_ARTIFACTS_REPO = "foundation-deployment-artifacts"
HELM_CHARTS_REPO = "/opt/kubernetes/helm-templates/service-template"
SERVICE_NAME = ServiceName.trim()
GIT_BRANCH_NAME = GitBranchName.trim()
ENV_PROFILE_NAME = "default"

node('uxtst411') {
    stage("Execute Build Job - ${SERVICE_NAME}") {  

        if(SERVICE_NAME == "") {
            error "Build Parameter - ServiceName is missing"
        }

        if(GIT_BRANCH_NAME == "") {
            error "Build Parameter - GitBranchName is missing"
        }

         if(ENV_PROFILE_NAME == "") {
            error "Build Parameter - EnvProfileName is missing"
        }

        executeBuildFlowFor(SERVICE_NAME, GIT_BRANCH_NAME)
        println '********* Execute Build Job Successful **********'
    }
}

def executeBuildFlowFor (repoName, branchName) {
    
    stage("Git Checkout") {
        println "******** Checking out source code from Git *********"
        gitCheckoutFor(repoName, branchName)
        println "******** Git Checkout Successful *********"
    }

    stage("Update Pom For Release") {
        println "******** Updating Pom For Release - Removing snapshot version and add a unique build # for release ***********"
        def gitCommitId = getLatestCommitIdFor(SERVICE_NAME, GIT_BRANCH_NAME) 
        jarFileName = updatePomForRelease(repoName, gitCommitId)
        println "************* Update Pom For Release Successful *************"
    }

    stage("Build Jar") {
        println "*********** Compiling maven project to build the jar *************"
        executeMvnGoal(repoName, "-Dmaven.test.skip=true clean install package")
        println "*********** Build Jar And Publish to Repository Successful *************"
    }

    stage("Build Docker Image") {
        gitCheckoutFor(DEPLOYMENT_ARTIFACTS_REPO, "master")
        sh("pwd")
        sh("cp ${repoName}/target/${jarFileName}.jar ./${DEPLOYMENT_ARTIFACTS_REPO}/mapr/${repoName}.jar")
        sh "sed -i 's~{{SERVICE_NAME}}~${repoName}~g' ./${DEPLOYMENT_ARTIFACTS_REPO}/mapr/Dockerfile"
        sh "sed -i 's~{{PROFILE_NAME}}~${ENV_PROFILE_NAME}~g' ./${DEPLOYMENT_ARTIFACTS_REPO}/mapr/config/application.yml"
        sh "sed -i 's~{{REPO_NAME}}~${repoName}~g' ./${DEPLOYMENT_ARTIFACTS_REPO}/mapr/config/application.yml"
        sh("docker build -t ${DOCKER_REGISTRY_URL}/${repoName}:latest ./${DEPLOYMENT_ARTIFACTS_REPO}/mapr/")
        println "*********** Build docker image And Publish to registry Successful *************"
    }

    stage("Push to Docker Registry") {
        sh("echo ${DOCKER_REGISTRY_PASSWORD} | docker login ${DOCKER_REGISTRY_URL} --username ${DOCKER_REGISTRY_USERNAME} --password-stdin")
        sh("docker push ${DOCKER_REGISTRY_URL}/${repoName}:latest")
        println "Cleaning up workspace and images..."
        deleteDir()
        sh("docker rmi ${DOCKER_REGISTRY_URL}/${repoName}:latest")
        println "*********** Pushing docker image to registry Successful *************"
    }

     stage("Deploy to Kubernetes") {
        node("uxunt4500") {
            sh("rm -rf ${repoName}-charts")
            sh("cp -r ${HELM_CHARTS_REPO} ${repoName}-charts")
            sh "sed -i 's~{{CHART_NAME}}~${repoName}~g' ./${repoName}-charts/Chart.yaml"

            def releaseName = getReleaseNameIfExists("${repoName}-${GIT_BRANCH_NAME}")
            if(releaseName == null || releaseName == "") {
                println "Installing a new release with name ${repoName}-${GIT_BRANCH_NAME}"
                sh("helm install ./${repoName}-charts --name=${repoName}-${GIT_BRANCH_NAME} --namespace sni-services --set image.repository=${DOCKER_REGISTRY_URL}/${repoName} --set probe.path=/${repoName}/health --set ingress.path=/${repoName},replicaCount=1")
            }
            else {
                println "Upgrading the existing release - ${repoName}-${GIT_BRANCH_NAME}"
                sh("helm delete --purge ${repoName}-${GIT_BRANCH_NAME}")
                sh("helm install ./${repoName}-charts --name=${repoName}-${GIT_BRANCH_NAME} --namespace sni-services --set image.repository=${DOCKER_REGISTRY_URL}/${repoName} --set probe.path=/${repoName}/health --set ingress.path=/${repoName},replicaCount=1")
                // sh("helm upgrade ${repoName}-${GIT_BRANCH_NAME} ./${repoName}-charts --namespace sni-services --set image.repository=${DOCKER_REGISTRY_URL}/${repoName} --set probe.path=/${repoName}/health --set ingress.path=/${repoName},replicaCount=1")
            }  
            // Cleanup older charts directory
            deleteDir()
            println "*********** Deploy to Kubernetes Successful *************" 
        }
    }
}

def getReleaseNameIfExists(releaseName) {
     releaseName = sh(
                    script: "helm ls ${releaseName} | cut -f1",
                    returnStdout: true
            ).trim()
    return releaseName
}

def gitCheckoutFor(repoName, branchName) {
    withCredentials([
         [$class: 'UsernamePasswordMultiBinding', credentialsId: GIT_CREDENTIAL, usernameVariable: 'GIT_USERNAME', passwordVariable: 'GIT_PASSWORD']
        ]) {
            def repoUrl = repoName + '.git'
            println "Pulling code for repoUrl =" + repoUrl
            sh("rm -rf ${repoName}")
            sh("git clone --branch ${branchName} https://${GIT_USERNAME}:${GIT_PASSWORD}@${GIT_DOMAIN}${repoUrl} ${repoName}")
        }
}

def getLatestCommitIdFor(repoName, branchName) {
    withCredentials([
         [$class: 'UsernamePasswordMultiBinding', credentialsId: GIT_CREDENTIAL, usernameVariable: 'GIT_USERNAME', passwordVariable: 'GIT_PASSWORD']
         ]) {
            latestGitCommitId = sh(
                    script: "git ls-remote https://${GIT_USERNAME}:${GIT_PASSWORD}@${GIT_DOMAIN}${repoName} ${branchName} | cut -f1",
                    returnStdout: true
            ).trim()
        }
    return latestGitCommitId
}

def updatePomForRelease(repoName, gitCommitId) {
    def pom = readMavenPom file: repoName + '/pom.xml'
    def version = ""

    try {
        if(pom.version.contains("-SNAPSHOT")) {
            version = pom.version.replace("-SNAPSHOT", ".${gitCommitId}")
         }
        else {
            version = pom.version+".${gitCommitId}"
        }
    }
    catch (Exception e) {
        println "Version tag is missing in pom.xml for " + repoName
        sh "exit 1"
    }
 
    executeMvnGoal(repoName, "versions:set versions:commit -DnewVersion=${version}")
    def jarFileName = pom.artifactId + "-" + version   
    return jarFileName
}

def executeMvnGoal(repoName, mvnGoal) {
    withMaven(
        maven: 'M3',
        mavenSettingsConfig: '861beabf-0e69-49b4-bc3c-aa5de0b1eb7e',
        mavenLocalRepo: '.repository'
    ) {
        sh "mvn -f ./${repoName}/pom.xml ${mvnGoal}"
    }
}