GIT_BASE_URL = "https://vaprd078.schneider.com/schneider/"
GIT_CREDENTIAL = 'eebde66b-39b8-4483-9ba0-7dc8d5d209da'
GIT_DOMAIN = "vaprd078.schneider.com/schneider/"

SERVICE_NAME = ServiceName.trim().toLowerCase()
XLD_FOLDER = XLDFolder.trim().toLowerCase()
GIT_BRANCH_NAME = GitBranchName.trim().toLowerCase()
GIT_COMMIT_ID = GitCommitId.trim()

node('prd-xebia-build-agent') {
    stage("Validate Input Parameters") {  
        if(SERVICE_NAME == "") {
            error "Build Parameter - ServiceName is missing"
        }

        if(XLD_FOLDER == "") {
            error "Build Parameter - DeployToEnv is missing"
        }

        if(GIT_BRANCH_NAME == "" && GIT_COMMIT_ID == "") {
            error "Build Parameter - Either one of GitCommitId or GitBranchName is mandatory"
        } 
        
        if (GIT_COMMIT_ID != "" && GIT_COMMIT_ID.length() < 7) {
            error "Build Parameter - Must have atleast 7 characters for the gitCommitId"
        }

        println SERVICE_NAME 
        println XLD_FOLDER 
        println GIT_BRANCH_NAME 
        println GIT_COMMIT_ID
    }

    stage("Git Checkout") {
        gitCheckoutFor(SERVICE_NAME, GIT_BRANCH_NAME, GIT_COMMIT_ID)
        println "******** Git Checkout Successful *********"
    }

    stage("Has Snapshots in pom.xml") {
        dir(path: "${SERVICE_NAME}") {
            pomXmlExists = sh(
                    script: "find . -name pom.xml -print",
                    returnStdout: true
            ).trim()

            if(pomXmlExists) {
                if(XLD_FOLDER.equalsIgnoreCase("releases")) {
                    def pom = readMavenPom file: 'pom.xml'
                    try {
                        if(pom.version.contains("-SNAPSHOT")) {
                            version = pom.version.replace("-SNAPSHOT", ".0")
                            executeMvnGoal("versions:set versions:commit -DnewVersion=${version}")
                            println "Removed SNAPSHOT from ${pom}"
                        }
                    }
                    catch (Exception e) {
                        println "Version tag is missing in pom.xml for " + SERVICE_NAME
                    }

                    sh("sed -i '/<!--/,/-->/d' pom.xml")
                    sh("sed -i '/<distributionManagement>/,/<\\/distributionManagement>/c<distributionManagement></distributionManagement>' pom.xml");

                    hasSnapshotsinPomXml = sh(
                        script: "grep -i 'snapshot' pom.xml -B 1 || echo ''",
                        returnStdout: true
                    ).trim()

                    if(hasSnapshotsinPomXml) {
                        println "List of Snapshots found in pom.xml"
                        println hasSnapshotsinPomXml
                        error "Validation - Has Snapshots in pom.xml - Failed - SNAPSHOTS not allowed for ${XLD_FOLDER} (FIT/PRD/TRN)"
                    } else {
                        println "Validation - Has Snapshots in pom.xml - Successful"
                    }
                } else {
                    println "Validation - Has Snapshots in pom.xml - Ignored for ${XLD_FOLDER} folders (UNT)"
                }
            } else {
                println "Validation - Has Snapshots in pom.xml - Ignored as pom.xml not exists in code"
            }
        }
    }       
}

def gitCheckoutFor(repoName, branchName, gitCommitId) {
    withCredentials([
         [$class: 'UsernamePasswordMultiBinding', credentialsId: GIT_CREDENTIAL, usernameVariable: 'GIT_USERNAME', passwordVariable: 'GIT_PASSWORD']
        ]) {
            def repoUrl = repoName + '.git'
            println "Pulling code for repoUrl =" + repoUrl
            sh("rm -rf ${repoName}")
            if(gitCommitId) {
                println "Checking out using git commit id for ${repoName}"
                sh("git clone https://${GIT_USERNAME}:${GIT_PASSWORD}@${GIT_DOMAIN}${repoUrl} ${repoName}")
                sh("git -C ./${repoName} reset --hard ${gitCommitId}")
            }
            else if(branchName) {
                println "Checking out using branch name for ${repoName}"
                sh("git clone --branch ${branchName} https://${GIT_USERNAME}:${GIT_PASSWORD}@${GIT_DOMAIN}${repoUrl} ${repoName}")
            }
            else {
                error "Both branchName and gitCommitId are null, Either one of them is mandatory"
            }
        }
}

def executeMvnGoal(mvnGoal) {
    withMaven(
        maven: 'M3',
        mavenSettingsConfig: '861beabf-0e69-49b4-bc3c-aa5de0b1eb7e',
        mavenLocalRepo: '.repository'
    ) {
        sh "mvn ${mvnGoal}"
    }
}