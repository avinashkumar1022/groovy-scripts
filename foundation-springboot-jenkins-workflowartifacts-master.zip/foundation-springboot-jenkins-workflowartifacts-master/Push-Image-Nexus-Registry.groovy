NEXUS_DOCKER_REGISTRY_URL = "sonatypenexus.schneider.com:21443"

IMAGE_NAME = ImageName.trim()
IMAGE_TAG = ImageTag.trim()
DEPLOY_TO_ENV = DeployToEnv.trim()
FROM_FOLDER = FromFolder.trim()

node('prd-xebia-build-agent') {

    stage ("Pull image from Nexus docker registry") {
        fromFolder = FROM_FOLDER
        withCredentials([
            [$class: 'UsernamePasswordMultiBinding', credentialsId: 'docker_nexus_push', usernameVariable: 'NEXUS_CONTAINER_REGISTRY_USERNAME', passwordVariable: 'NEXUS_CONTAINER_REGISTRY_PASSWORD']])
            {
                sh("docker login ${NEXUS_DOCKER_REGISTRY_URL} -u ${NEXUS_CONTAINER_REGISTRY_USERNAME} -p ${NEXUS_CONTAINER_REGISTRY_PASSWORD}")
                sh("docker pull ${NEXUS_DOCKER_REGISTRY_URL}/${fromFolder}/${IMAGE_NAME}:${IMAGE_TAG}")
            }
    }

    stage ("Push image to Azure docker registry") {

        pushImage(IMAGE_NAME, IMAGE_TAG, DEPLOY_TO_ENV, FROM_FOLDER)

    }
}

def pushImage(ImageName, ImageTag, DeployToEnv, FromFolder) {
    println "*********** Push Docker Image to Nexus Container Registry Folder ${DeployToEnv} *************"
    withCredentials([
        [$class: 'UsernamePasswordMultiBinding', credentialsId: 'docker_nexus_push', usernameVariable: 'NEXUS_CONTAINER_REGISTRY_USERNAME', passwordVariable: 'NEXUS_CONTAINER_REGISTRY_PASSWORD']])
        {
            sh("docker login ${NEXUS_DOCKER_REGISTRY_URL} -u ${NEXUS_CONTAINER_REGISTRY_USERNAME} -p ${NEXUS_CONTAINER_REGISTRY_PASSWORD}")
            sh("docker tag ${NEXUS_DOCKER_REGISTRY_URL}/${FromFolder}/${ImageName}:${ImageTag} ${NEXUS_DOCKER_REGISTRY_URL}/${DeployToEnv}/${ImageName}:${ImageTag}")
            sh("docker push ${NEXUS_DOCKER_REGISTRY_URL}/${DeployToEnv}/${ImageName}:${ImageTag}")
            sh("docker rmi ${NEXUS_DOCKER_REGISTRY_URL}/${DeployToEnv}/${ImageName}:${ImageTag}")
            sh("docker rmi ${NEXUS_DOCKER_REGISTRY_URL}/${FromFolder}/${ImageName}:${ImageTag}")
        }
    println "*********** Push Docker Image to Nexus Container Registry Folder ${DeployToEnv} Successful *************"  

}