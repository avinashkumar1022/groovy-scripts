AZURE_CONTAINER_UNT_REGISTRY_URL = "untsniregistry.azurecr.io"
AZURE_CONTAINER_PRD_REGISTRY_URL = "prdsniregistry.azurecr.io"

IMAGE_NAME = ImageName.trim()
IMAGE_TAG = ImageTag.trim()
DEPLOY_TO_ENV = DeployToEnv.trim()

node('prd-xebia-build-agent') {

    stage ("Pull image from Azure unt docker registry") {
        fromFolder = "uat"
        withCredentials([
            [$class: 'UsernamePasswordMultiBinding', credentialsId: 'untsniregistryazurecr', usernameVariable: 'AZURE_CONTAINER_REGISTRY_USERNAME', passwordVariable: 'AZURE_CONTAINER_REGISTRY_PASSWORD']])
            {
                sh("docker login ${AZURE_CONTAINER_UNT_REGISTRY_URL} -u ${AZURE_CONTAINER_REGISTRY_USERNAME} -p ${AZURE_CONTAINER_REGISTRY_PASSWORD}")
                sh("docker pull ${AZURE_CONTAINER_UNT_REGISTRY_URL}/${fromFolder}/${IMAGE_NAME}:${IMAGE_TAG}")
            }
    }

    stage ("Push image to Azure docker registry") {

        pushImage(IMAGE_NAME, IMAGE_TAG, DEPLOY_TO_ENV, "uat")

    }
}

def pushImage(ImageName, ImageTag, DeployToEnv, FromFolder) {
    if (DeployToEnv == "prd"){
    println "*********** Push Docker Image to Azure Container Registry ${DeployToEnv} *************"
    withCredentials([
        [$class: 'UsernamePasswordMultiBinding', credentialsId: 'prdsniregistryazurecr', usernameVariable: 'AZURE_CONTAINER_REGISTRY_USERNAME', passwordVariable: 'AZURE_CONTAINER_REGISTRY_PASSWORD']])
        {
            sh("docker login ${AZURE_CONTAINER_PRD_REGISTRY_URL} -u ${AZURE_CONTAINER_REGISTRY_USERNAME} -p ${AZURE_CONTAINER_REGISTRY_PASSWORD}")
            sh("docker tag ${AZURE_CONTAINER_UNT_REGISTRY_URL}/${FromFolder}/${ImageName}:${ImageTag} ${AZURE_CONTAINER_PRD_REGISTRY_URL}/${DeployToEnv}/${ImageName}:${ImageTag}")
            sh("docker push ${AZURE_CONTAINER_PRD_REGISTRY_URL}/${DeployToEnv}/${ImageName}:${ImageTag}")
            sh("docker rmi ${AZURE_CONTAINER_PRD_REGISTRY_URL}/${DeployToEnv}/${ImageName}:${ImageTag}")
            sh("docker rmi ${AZURE_CONTAINER_UNT_REGISTRY_URL}/${FromFolder}/${ImageName}:${ImageTag}")
        }
    println "*********** Push Docker Image to Azure Container Registry ${DeployToEnv} Successful *************"  
    }

}