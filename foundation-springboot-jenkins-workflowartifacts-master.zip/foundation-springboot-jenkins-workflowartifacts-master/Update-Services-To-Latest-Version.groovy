GIT_BASE_URL = "https://vaprd078.schneider.com/schneider/"
GIT_CREDENTIAL = 'eebde66b-39b8-4483-9ba0-7dc8d5d209da'
GIT_DOMAIN = "vaprd078.schneider.com/schneider/"

LIST_OF_REPOSITORIES = ListOfRepositories.trim()
GIT_BRANCH_NAME = GitBranchName.trim()
EMAIL_ID = EmailId.trim()

LOGS_HOME = "/opt/schneider/jenkins/nxgapps/workspace/Springboot"

node('uxprd1480') {
    
    stage("Validate Input Parameters") {  
        if(LIST_OF_REPOSITORIES == "") {
            error "Build Parameter - ServiceName is missing"
        }

        if(GIT_BRANCH_NAME == "") {
            error "Build Parameter - GitBranchName is missing"
        }

        if(EMAIL_ID == "") {
            error "Build Parameter - EmailId is missing"
        }
    }

    stage("Execute Update Version Flow") {
        LIST_OF_REPOSITORIES.split("\n").each() {
            if(it.trim()) {
                executeUpdateVersionFlowFor(it, GIT_BRANCH_NAME)
            }
        }
    }
}

def executeUpdateVersionFlowFor (repoName, branchName) {

    def successfulServices = [:]
    def failedServices = [:]
    env.datetime = new Date().format( 'yyyyMMddHHmmss' )
    
    stage("Git Checkout - ${repoName}") {
        println "******** Checking out source code from Git *********"
        gitCheckoutFor(repoName, branchName)
        env.gitCommitId = sh(
                    script: "git -C ./${repoName} rev-parse HEAD",
                    returnStdout: true
                ).trim()
        println "******** Git Checkout Successful *********"
    }

    stage("Update Pom with latest Release - ${repoName}") {
        executeMvnGoal(repoName, "versions:update-parent")
        executeMvnGoal(repoName, "versions:use-releases")
        executeMvnGoal(repoName, "versions:use-latest-releases -Dincludes=com.schneider*")
        executeMvnGoal(repoName, "-N versions:update-child-modules")
        println "************* Updated Pom with the latest release version *************"
    }

    stage("Build Jar - ${repoName}") {
        println "*********** Compiling maven project to build the jar *************"
        statusCode = executeMvnGoal(repoName, "-Dmaven.test.failure.ignore=true clean test install package")
        if(statusCode.equals(0)) {
            println "Successfully built jar for ${repoName}"
        }
        else {
            failedServices.put(repoName, env.gitCommitId)
        }
        println "*********** Build Jar For ${repoName} Successful *************"
    }

    stage("Verify Starting the service - ${repoName}") { 
        sh("mv ${repoName}/target/*.jar ${repoName}/target/${repoName}.jar")
        withEnv(['JENKINS_NODE_COOKIE=dontkill']) {
            dir(path: "${repoName}") {
                sh("java -jar target/${repoName}.jar > ${repoName}.log 2>&1 &")
                echo "Waiting 120 seconds to check if the service is started successfully"
                sleep 120
                env.isStartedSuccessfully = sh(
                    script: "grep 'Tomcat started on port(s)' ${repoName}.log",
                    returnStdout: true
                ).trim()
            }
        }

        PID = sh(
            script: "ps -ef | grep ${repoName} | grep -v grep | awk '{print\$2}' | head -n 1",
            returnStdout: true
        ).trim()

        if(PID) {
            println "Killing PID of ${repoName} = " + PID
            sh("kill -9 ${PID}")
        }
    }

    stage("Commit/Push To GIT") {
        if(env.isStartedSuccessfully) {
            pushToGit(repoName, branchName)
            successfulServices.put(repoName, env.gitCommitId)
            echo "************** Updated and committed to GIT successfully ${repoName} with the latest version **********************"
        } else {
            failedServices.put(repoName, env.gitCommitId)
        }
    }

    stage('Cleanup') {  
        deleteDir()
    }   

    stage("Print Summary") {
        println "********** Overall Summary **********"
        println "########## Successfully updated Services to the latest version #############"
        
        sh("echo \"-------------- ${EMAIL_ID} --- ${env.datetime}---------------------\" >> $LOGS_HOME/logs/history.log")
        sh("echo \"**** Successfully Updated Services ****\" >> $LOGS_HOME/logs/history.log")
        successfulServices.keySet().each() {
            println it
            commitId = successfulServices[it]
            sh("echo $it : $commitId >> $LOGS_HOME/logs/history.log")
        }
        
        if(failedServices.size() > 0) {
            println "########## Failed Services #############" 
            sh("echo \"**** failed Services ****\" >> $LOGS_HOME/logs/history.log")
            failedServices.keySet().each() {
                println it
                commitId = failedServices[it]
                sh("echo $it : $commitId >> $LOGS_HOME/logs/history.log")
            }
        } else {
            println "******** All Services are updated to latest version successfully *********"
        }
        sh("echo \"\" >> $LOGS_HOME/logs/history.log")
    }
}

def gitCheckoutFor(repoName, branchName) {
   withCredentials([
         [$class: 'UsernamePasswordMultiBinding', credentialsId: GIT_CREDENTIAL, usernameVariable: 'GIT_USERNAME', passwordVariable: 'GIT_PASSWORD']
        ]) {
            def repoUrl = repoName + '.git'
            println "Pulling code for repoUrl =" + repoUrl
            sh("rm -rf ${repoName}")
            sh("git clone --branch ${branchName} https://${GIT_USERNAME}:${GIT_PASSWORD}@${GIT_DOMAIN}${repoUrl} ${repoName}")
        }
}

def executeMvnGoal(repoName, mvnGoal) {
    def statusCode = 0
    withMaven(
        maven: 'M3',
        mavenSettingsConfig: '861beabf-0e69-49b4-bc3c-aa5de0b1eb7e',
        mavenLocalRepo: '.repository'
    ) {
        statusCode = sh script:"mvn -f ./${repoName}/pom.xml ${mvnGoal}", returnStatus:true
    }
    return statusCode
}

def pushToGit(repoName, branchName) {
    def repoUrl = repoName + '.git'
    println 'Pushing to ' + repoUrl
    withCredentials([
         [$class: 'UsernamePasswordMultiBinding', credentialsId: GIT_CREDENTIAL, usernameVariable: 'GIT_USERNAME', passwordVariable: 'GIT_PASSWORD']
         ]) {
             sh("git -C ./${repoName} pull https://${GIT_USERNAME}:${GIT_PASSWORD}@${GIT_DOMAIN}${repoUrl} ${branchName}")
             sh("git -C ./${repoName} config user.name 'sni-deployer'")		
             sh("git -C ./${repoName} config user.email '${EMAIL_ID}'")
             sh("git -C ./${repoName} add pom.xml")
             sh("git -C ./${repoName} diff --quiet --exit-code --cached || git -C ./${repoName} commit -am 'Updated pom.xml to latest version via Jenkins Flow - .${currentBuild.id}'")
             sh("git -C ./${repoName} push https://${GIT_USERNAME}:${GIT_PASSWORD}@${GIT_DOMAIN}${repoUrl} ${branchName}")
        }
}