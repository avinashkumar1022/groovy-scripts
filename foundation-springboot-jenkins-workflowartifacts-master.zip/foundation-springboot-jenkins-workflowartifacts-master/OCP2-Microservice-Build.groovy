GIT_BASE_URL = "https://vaprd078.schneider.com/schneider/"
GIT_CREDENTIAL = 'eebde66b-39b8-4483-9ba0-7dc8d5d209da'
GIT_DOMAIN = "vaprd078.schneider.com/schneider/"
NEXUS_DOCKER_REGISTRY_URL = "sonatypenexus.schneider.com:21443"

DEPLOYMENT_ARTIFACTS_REPO = "foundation-deployment-artifacts"
XL_DEPLOYIT_MANIFEST_FILE_NAME = "deployit-manifest.xml"
DEPLOYMENT_YAML_PATH = "k8s-4.3/deployment/deployment.yml"
SONAR_URL = "http://uxprd2600:8080/sonarqube"

K8S_DEPLOYMENT_YAML = "deployment.yml"
K8S_ROUTE_YAML = "route.yml"

XLD_FOLDER_PREFIX = "On-Premise/OCP2/Services"

SERVICE_NAME = ServiceName.trim()
GIT_BRANCH_NAME = GitBranchName.trim()
ENV_PROFILE_NAME = "env"
XLD_FOLDER = XLDFolder.trim()
PROJECT_NAMESPACE = ProjectNamespace.trim()
nexusFolder = NexusFolder.trim()
GIT_COMMIT_ID = GitCommitId.trim()
UnitTestResult="False"
DeploymentArtifactsRepoBranch = "master"

XLD_RESOURCE_NODE = """<openshift.ResourcesFile name=\"/{{REPO_NAME}}-{{RESOURCE_FOLDER_NAME}}\" file=\"{{RESOURCE_FOLDER_PATH}}\"><tags><value>${PROJECT_NAMESPACE}-ocp2</value></tags><scanPlaceholders>true</scanPlaceholders><preScannedPlaceholders>false</preScannedPlaceholders><placeholders /><delimiters>{{ }}</delimiters></openshift.ResourcesFile>"""

node('prd-xebia-build-agent') {
    stage("Execute Build Job - ${SERVICE_NAME}") {  

        if(SERVICE_NAME == "") {
            error "Build Parameter - ServiceName is missing"
        }

        if(GIT_BRANCH_NAME == "" && GIT_COMMIT_ID == "") {
            error "Build Parameter - Either one of GitCommitId or GitBranchName is mandatory"
        } 
        
        if (GIT_COMMIT_ID != "" && GIT_COMMIT_ID.length() < 7) {
            error "Build Parameter - Must have atleast 7 characters for the gitCommitId"
        }

        if(ENV_PROFILE_NAME == "") {
            error "Build Parameter - EnvProfileName is missing"
        }

        if(XLD_FOLDER == "") {
            error "Build Parameter - XLDFolder is missing"
        }

        if(PROJECT_NAMESPACE == "") {
            error "Build Parameter - ProjectNamespace is missing"
        }

        if(nexusFolder == "") {
            error "Build Parameter - NexusFolder is missing"
        }

        executeBuildFlowFor(SERVICE_NAME, GIT_BRANCH_NAME, GIT_COMMIT_ID)
        println '********* Execute Build Job Successful **********'
    }
}

def executeBuildFlowFor (repoName, branchName, gitCommitId) {
    
    stage("Git Checkout") {
        println "******** Checking out source code from Git *********"
        gitCheckoutFor(repoName, branchName, gitCommitId)
        println "******** Git Checkout Successful *********"
    }

    stage("Update Pom For Release") {
        println "******** Updating Pom For Release - Removing snapshot version and add a unique build # for release ***********"
        if(GIT_COMMIT_ID) {
            env.gitCommitId = GIT_COMMIT_ID.substring(0,7)
        }
        else {
            env.gitCommitId = getLatestCommitIdFor(SERVICE_NAME, GIT_BRANCH_NAME)
        }
        env.datetime = new Date().format( 'yyyyMMddHHmmss' )
        jarFileName = updatePomForRelease(repoName, env.gitCommitId)
        println "************* Update Pom For Release Successful *************"
    }

    stage("Build Jar") {
        println "*********** Compiling maven project to build the jar *************"
        executeMvnGoal(repoName, "clean verify test install package")
        println "*********** Build Jar And Publish to Repository Successful *************"
    }
	
	
    stage('Code Coverage') { 

         dir(path: "${repoName}") {
             jacocoExecFilePath = sh(
                    script: "find . -name jacoco*.exec -print",
                    returnStdout: true
            ).trim()

            jacocoXmlPath = sh(
                    script: "find . -name jacoco.xml -print",
                    returnStdout: true
            ).trim()
	    
	    println "Jacoco Xml Path = ${jacocoXmlPath}"
            println "Jacoco Exec File Path = ${jacocoExecFilePath}"

            sh "/opt/schneider/sonar-scanner-cli/bin/sonar-scanner -e -Dsonar.projectKey=${repoName} -Dsonar.host.url=${SONAR_URL} -Dsonar.login=bfc9f8d776ff0e8ff1f75121160b853765daf8b1 -Dsonar.language=java -Dsonar.projectBaseDir=$WORKSPACE/${repoName} -Dsonar.java.binaries=. -Dsonar.java.coveragePlugin=jacoco -Dsonar.jacoco.reportPaths=${jacocoExecFilePath} -Dsonar.coverage.jacoco.xmlReportPaths=${jacocoXmlPath} -Dsonar.source=$WORKSPACE/${repoName}/src -Dsonar.sourceEncoding=UTF-8 -Dsonar.exclusions=**/site/**"
         }
     }
	stage('Nexus IQ Policy Evaluation'){
		
		def policyEvaluationResult=nexusPolicyEvaluation advancedProperties: '', failBuildOnNetworkError: false, iqApplication: manualApplication("${repoName}"), iqScanPatterns: [[scanPattern: '**/*.jar'], [scanPattern: '**/*.war'], [scanPattern: '**/*.ear']], iqStage: 'build', jobCredentialsId: 'nexus_iq_scan'
		currentBuild.rawBuild.@result = hudson.model.Result.SUCCESS
	}

     stage("Push Github Topics as Pod Labels") {
        def topicsJson = readJSON text: getRepoTopics(repoName)
        println "Topics For ${repoName} = ${topicsJson.names}"

        def supportESNum = ""
        def supportServerity = ""

        topicsJson.names.each() {
            if(it.contains("support")) {
                 if(it.contains("support-level")) {
                     supportServerity = it.split("-")[2]
                 } else {
                     supportESNum = it.split("-")[1]
                 }
            }
            if(it.contains("testing")) {
                DeploymentArtifactsRepoBranch = "testing"
            }
        }

        if(supportESNum == "") {
            println "Unable to find the support-* from git topics for repository=${repoName}"
        } else {
            println "Found support topics - supportESNum=${supportESNum}"
            updateYaml("${repoName}/${DEPLOYMENT_YAML_PATH}", "EventScenario", supportESNum.toUpperCase())
        }
        
        if(supportServerity == "") {
            println "Unable to find the support-level-<severity>* from git topics for repository=${repoName}"
        } else {
            println "Found support topics - supportServerity=${supportServerity}"
            updateYaml("${repoName}/${DEPLOYMENT_YAML_PATH}", "SupportLevel", supportServerity)
        }
     }
		 
    stage("Build Docker Image") {        
      
        println "*********** Bulding Docker Image from local docker file*************"
        buildDockerImageInProject(jarFileName, repoName, env.gitCommitId, nexusFolder)
        println "*********** Bulding Docker Image Successful *************"
    }
	
    stage("Aqua Scan Docker Image") {
        aqua locationType: 'local', localImage: "${NEXUS_DOCKER_REGISTRY_URL}/${nexusFolder}/${repoName}:${env.datetime}-${env.gitCommitId}", onDisallowed: 'pass', notCompliesCmd: '', policies: 'Default', register: false, registry: 'Docker UAT', showNegligible: false
        println "*********** Aqua scan successful *************"
    }

    stage("Push to Docker Registry") {
        pushImageToNexus(repoName, env.gitCommitId, nexusFolder)
    }

    stage("Build XL Deploy DAR Package") {
        
        k8sDeploymentFile = sh(
            script: "find ./${repoName}/k8s-4.3 -name '${K8S_DEPLOYMENT_YAML}'",
            returnStdout: true
        ).trim()
        k8sRouteFile = sh(
            script: "find ./${repoName}/k8s-4.3 -name '${K8S_ROUTE_YAML}'",
            returnStdout: true
        ).trim()        
        
        println "${k8sDeploymentFile}"
        println "${k8sRouteFile}"

        // Replace deployment.yml and route.yml files

        sh("sed -i 's~{{IMAGE_VERSION}}~${datetime}-${env.gitCommitId}~g' ${k8sDeploymentFile}");
        sh("sed -i 's~{{NAMESPACE}}~${PROJECT_NAMESPACE}~g' ${k8sRouteFile}");
        sh("sed -i 's~minReadySeconds:[ 0-9]*~minReadySeconds: 10~g' ${k8sDeploymentFile}");          
        
        sh("cp -r ./${repoName}/k8s-4.3/* ./${repoName}")

        resourceFiles = sh(
                    script: "find ./${repoName}/k8s-4.3/ -name '*.yml' -print",
                    returnStdout: true
            ).trim()

        resourceFiles = resourceFiles.replace("./${repoName}/k8s-4.3", "")
        println "************ Resources in k8s-4.3 Folder ************"
        println "${resourceFiles}"

        xldResourcesNode = generateResourcesOnXLDManifestFile(repoName, resourceFiles)     
        println("************* Generated XLD Resources Node *****************")
        println "${xldResourcesNode}"

        // Copy default deployit-manifest file for XLD and replace

        gitCheckoutFor(DEPLOYMENT_ARTIFACTS_REPO, DeploymentArtifactsRepoBranch, "")
        echo "Using ${DeploymentArtifactsRepoBranch} branch for ${DEPLOYMENT_ARTIFACTS_REPO}"

        sh "cp ./${DEPLOYMENT_ARTIFACTS_REPO}/xebia/K8S/${XL_DEPLOYIT_MANIFEST_FILE_NAME} ${repoName}/${XL_DEPLOYIT_MANIFEST_FILE_NAME}"

        sh("sed -i 's~{{ARTIFACT_VERSION}}~${env.datetime}-${env.gitCommitId}~g' ${repoName}/${XL_DEPLOYIT_MANIFEST_FILE_NAME}");
        sh("sed -i 's~{{XLD_FOLDER}}~${XLD_FOLDER}~g' ${repoName}/${XL_DEPLOYIT_MANIFEST_FILE_NAME}");
        sh("sed -i 's~{{XLD_FOLDER_PREFIX}}~${XLD_FOLDER_PREFIX}~g' ${repoName}/${XL_DEPLOYIT_MANIFEST_FILE_NAME}");
        if(XLD_FOLDER.equalsIgnoreCase("Snapshots")) {
            sh("sed -i 's~{{REPO_NAME}}~${repoName}-snapshot-ocp2~g' ${repoName}/${XL_DEPLOYIT_MANIFEST_FILE_NAME}");
        }
        else {
            sh("sed -i 's~{{REPO_NAME}}~${repoName}-ocp2~g' ${repoName}/${XL_DEPLOYIT_MANIFEST_FILE_NAME}");
        }

        sh("sed -i 's~{{XLD_RESOURCES_NODES}}~${xldResourcesNode}~g' ${repoName}/${XL_DEPLOYIT_MANIFEST_FILE_NAME}");

        xldCreatePackage artifactsPath: "", manifestPath: "${repoName}/${XL_DEPLOYIT_MANIFEST_FILE_NAME}", darPath: '${serviceName}-${gitCommitId}.dar'
        println "### Build XL Deploy DAR Package Successful ###";
    }

    stage('XL Deploy Publish') {  
        xldPublishPackage serverCredentials: 'XldCreds', darPath: '${serviceName}-${gitCommitId}.dar'
        println "Pushed docker image with version ${env.gitCommitId}"
        println "Cleaning up workspace ..."
        deleteDir()
        println "### XL Deploy Publish Successful ###"
    }   
}

def gitCheckoutFor(repoName, branchName, gitCommitId) {
    withCredentials([
         [$class: 'UsernamePasswordMultiBinding', credentialsId: GIT_CREDENTIAL, usernameVariable: 'GIT_USERNAME', passwordVariable: 'GIT_PASSWORD']
        ]) {
            def repoUrl = repoName + '.git'
            println "Pulling code for repoUrl =" + repoUrl
            sh("rm -rf ${repoName}")
            if(gitCommitId) {
                println "Checking out using git commit id for ${repoName}"
                sh("git clone https://${GIT_USERNAME}:${GIT_PASSWORD}@${GIT_DOMAIN}${repoUrl} ${repoName}")
                sh("git -C ./${repoName} reset --hard ${gitCommitId}")
            }
            else if(branchName) {
                println "Checking out using branch name for ${repoName}"
                sh("git clone --branch ${branchName} https://${GIT_USERNAME}:${GIT_PASSWORD}@${GIT_DOMAIN}${repoUrl} ${repoName}")
            }
            else {
                error "Both branchName and gitCommitId are null, Either one of them is mandatory"
            }
        }
}

def getLatestCommitIdFor(repoName, branchName) {
    withCredentials([
         [$class: 'UsernamePasswordMultiBinding', credentialsId: GIT_CREDENTIAL, usernameVariable: 'GIT_USERNAME', passwordVariable: 'GIT_PASSWORD']
         ]) {
            latestGitCommitId = sh(
                    script: "git ls-remote https://${GIT_USERNAME}:${GIT_PASSWORD}@${GIT_DOMAIN}${repoName} ${branchName} | cut -f1",
                    returnStdout: true
            ).trim()
        }
    return latestGitCommitId.substring(0,7)
}

def updatePomForRelease(repoName, gitCommitId) {
    def pom = readMavenPom file: repoName + '/pom.xml'
    def version = ""

    try {
        if(pom.version.contains("-SNAPSHOT")) {
            version = pom.version.replace("-SNAPSHOT", ".${gitCommitId}")
         }
        else {
            version = pom.version+".${gitCommitId}"
        }
    }
    catch (Exception e) {
        println "Version tag is missing in pom.xml for " + repoName
        sh "exit 1"
    }
 
    executeMvnGoal(repoName, "versions:set versions:commit -DnewVersion=${version}")
    def jarFileName = pom.artifactId + "-" + version   
    return jarFileName
}

def executeMvnGoal(repoName, mvnGoal) {
    withMaven(
        maven: 'M3',
        mavenSettingsConfig: '861beabf-0e69-49b4-bc3c-aa5de0b1eb7e',
        mavenLocalRepo: '.repository'
    ) {
        sh "mvn -f ./${repoName}/pom.xml ${mvnGoal}"
    }
}

def generateResourcesOnXLDManifestFile(repoName, resourceFiles) {
    def xldResourcesNode = "";
    ymlFiles = resourceFiles.split('\n');

    def resourceNames = ["configmap", "secret", "deployment", "service", "route", "hpa"]
    
    for(int index=0; index < resourceNames.size(); index++) {
        ymlFiles.each() {
            if(it) {
                if(it.contains(resourceNames[index])) {
                    resourceNode = "${XLD_RESOURCE_NODE}";
                    resourceNode = resourceNode.replace("{{RESOURCE_FOLDER_PATH}}", repoName+"/"+it);
                    resourceNode = resourceNode.replace("{{REPO_NAME}}", index+2 + "-" + repoName);
                    println "Updating resource file name for ${resourceNames[index]} = " + it.contains(resourceNames[index])
                    resourceNode = resourceNode.replace("{{RESOURCE_FOLDER_NAME}}", it.split("/")[2]);
                    xldResourcesNode = xldResourcesNode + resourceNode;
                }
            }
            else {
                error "Unable to retrieve the Yml files inside k8s folder for ${repoName}";
            }
        }
    }
    return xldResourcesNode;
}

def getRepoTopics(repoName) {
    def topics = ""
    withCredentials([
         [$class: 'UsernamePasswordMultiBinding', credentialsId: GIT_CREDENTIAL, usernameVariable: 'GIT_USERNAME', passwordVariable: 'GIT_PASSWORD']
        ]) {
            topics= sh (
                script: "curl -X GET https://${GIT_USERNAME}:${GIT_PASSWORD}@vaprd078.schneider.com/api/v3/repos/schneider/${repoName}/topics -H 'Accept: application/vnd.github.mercy-preview+json'",
                returnStdout: true
            )
          }
    return topics
}

def updateYaml(yamlPath, key, value) {
        sh("sed -i 's~{{~<~g' ${yamlPath}");
        sh("sed -i 's~}}~>~g' ${yamlPath}");
        deploymentYaml = readYaml file: "${yamlPath}"

        podLabelsNode = deploymentYaml.spec.template.metadata.labels
        podLabelsNode.put(key, value)

        deploymentYaml.spec.template.metadata.labels = podLabelsNode

        sh("rm -rf ${yamlPath}")
        
        writeYaml file: "${yamlPath}", data: deploymentYaml

        sh("sed -i 's~<~{{~g' ${yamlPath}");
        sh("sed -i 's~>~}}~g' ${yamlPath}");
}

def buildDockerImageInProject(jarFileName, repoName, gitCommitId, nexusFolder){

    def folderName = "docker"
    sh("mkdir -p ${repoName}/${folderName}")
    sh("mv ${repoName}/target/${jarFileName}.jar ./${repoName}/${folderName}/${repoName}.jar")
    sh "sed -i 's~{{SERVICE_NAME}}~${repoName}~g' ${repoName}/Dockerfile"
    sh("mv ${repoName}/Dockerfile ./${repoName}/${folderName}/")

    sh("docker build -t ${NEXUS_DOCKER_REGISTRY_URL}/${nexusFolder}/${repoName}:${env.datetime}-${env.gitCommitId} ${repoName}/${folderName}/.")
}

def pushImageToNexus(repoName, gitCommitId, nexusFolder){

    println "*********** Push Docker Image to Nexus Docker Registry *************"
    withCredentials([
        [$class: 'UsernamePasswordMultiBinding', credentialsId: 'docker_nexus_push', usernameVariable: 'NEXUS_DOCKER_REGISTRY_USERNAME', passwordVariable: 'NEXUS_DOCKER_REGISTRY_PASSWORD']
        ]) {
            sh("docker login ${NEXUS_DOCKER_REGISTRY_URL} -u ${NEXUS_DOCKER_REGISTRY_USERNAME} -p ${NEXUS_DOCKER_REGISTRY_PASSWORD}")
            sh("docker push ${NEXUS_DOCKER_REGISTRY_URL}/${nexusFolder}/${repoName}:${datetime}-${gitCommitId}")
            sh("docker rmi ${NEXUS_DOCKER_REGISTRY_URL}/${nexusFolder}/${repoName}:${datetime}-${gitCommitId}")
        }
    println "*********** Push Docker Image to Nexus Docker Registry Successful *************"   
}
