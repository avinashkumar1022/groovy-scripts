SERVICE_NAME = ServiceName.trim()
GIT_COMMIT_ID = GitCommitId.trim()
DEPLOY_TO_ENV = DeployToEnv.trim().toLowerCase()

GIT_CREDENTIAL = 'eebde66b-39b8-4483-9ba0-7dc8d5d209da'
GIT_DOMAIN = "vaprd078.schneider.com/schneider/"

SERVICE_INSTRUCTION_JSON_FILE_NAME = "./src/main/resources/service-instruction.json"

node('prd-xebia-build-agent') {
    stage("Validate Input Parameters") {  
        if(SERVICE_NAME == "") {
            error "Build Parameter - ServiceName is missing"
        }

        if(GIT_COMMIT_ID == "") {
            error "Build Parameter - GitCommitId is missing"
        } 

        if(DEPLOY_TO_ENV == "") {
            error "Build Parameter - DeployToEnv is missing"
        }

        println SERVICE_NAME
        println GIT_COMMIT_ID
        println DEPLOY_TO_ENV
    }

    stage("Git Checkout") {
        println "******** Git Checkout for ${SERVICE_NAME} ${GIT_COMMIT_ID}*********"
        gitCheckoutFor(SERVICE_NAME, GIT_COMMIT_ID)
        println "******** Git Checkout Successful *********"
    }

    stage("Service Instruction Registration") {
	    if(DEPLOY_TO_ENV.equalsIgnoreCase("prd")) {
            println "Ignoring PRD Service Instruction as per OA Team request temporarily"
			currentBuild.result = 'SUCCESS'
            // return here instead of throwing error to keep the build "green"
            return
        } 
        println "Exists = " + isServiceInstrcutionJsonFileExistsInCode(SERVICE_NAME)
        if(isServiceInstrcutionJsonFileExistsInCode(SERVICE_NAME)) {
            println "${SERVICE_INSTRUCTION_JSON_FILE_NAME} exists in ${SERVICE_NAME} for ${GIT_COMMIT_ID}, so registering the SI"
            accessToken = getJWTToken(DeployToEnv)
            if(accessToken) {
                println "Successfully retrieved the token for ${DEPLOY_TO_ENV}"
                dir(path: "${SERVICE_NAME}") {
                    serviceInstrJsonData = readFile "${SERVICE_INSTRUCTION_JSON_FILE_NAME}"
                }
                httpResponse = registerServiceInstructionFor(accessToken, serviceInstrJsonData, DEPLOY_TO_ENV) 
                responseJson = readJSON text: httpResponse
                if(responseJson['userMessage'].contains("service with servicename ${SERVICE_NAME}")) {
                    println "Successfully published the SI for servicename ${SERVICE_NAME}"
                } else {
                    error "Error occured while publishing the SI, Please see logs above for more details"
                }
            } else {
                error "Unable to retrive the token for ${DEPLOY_TO_ENV}"
            }
        } else {
            println "${SERVICE_INSTRUCTION_JSON_FILE_NAME} does not exists in ${SERVICE_NAME} for ${GIT_COMMIT_ID}"
        }

        println "Cleaning up workspace ..."
        deleteDir()
    }
}

def isServiceInstrcutionJsonFileExistsInCode(repoName) {
    dir(path: "${repoName}") {
             serviceInstrnFileExists = sh(
                    script: "[ -f ${SERVICE_INSTRUCTION_JSON_FILE_NAME} ] && echo 1 || echo ''",
                    returnStdout: true
            ).trim()    
    }
    return serviceInstrnFileExists
}

def registerServiceInstructionFor(accessToken, serviceInstrJsonData, DEPLOY_TO_ENV) {
    serviceInstrJsonDataAsString = new groovy.json.JsonBuilder(serviceInstrJsonData).toPrettyString()
    jsonPayload = "'{\"serviceName\": \"${SERVICE_NAME}\", \"scenarioName\": \"DEFAULT\", \"payload\": ${serviceInstrJsonDataAsString}}'"
    response = invokeHttpRequest("POST", getResourceUrlForServiceControllerAPI(), jsonPayload, accessToken)
    println response
    return response
}

def invokeHttpRequest(httpMethod, url, payload, accessToken) {
    httpResponse = sh(
                script: "curl -v --silent -d ${payload} -H 'Accept: application/json' -H 'Content-Type: application/json; charset=utf-8' -H 'Authorization: Bearer ${accessToken}' -X ${httpMethod} ${url}",
                returnStdout: true
            ).trim()
    return httpResponse;
}

def getResourceUrlForServiceControllerAPI() {
    def baseUrl = "https://enterprise-servicecontroller-service-${DEPLOY_TO_ENV}-oms.apps.ocpunt.schneider.com/v1/publish"
    if(DEPLOY_TO_ENV.equalsIgnoreCase("prd")) {
        baseUrl = baseUrl.replace("ocpunt", "ocp")
    }
    return baseUrl
}

def getJWTToken(env) {
    def accessToken = ""
    oAuthTokenUrl = "https://oauth2${DEPLOY_TO_ENV}.schneider.com/f5-oauth2/v1/token"
    if(env.equalsIgnoreCase("fit")) {
        oAuthTokenUrl = oAuthTokenUrl.replace("fit", "uat")
    } else if(env.equalsIgnoreCase("prd")) {
        oAuthTokenUrl = oAuthTokenUrl.replace("prd", "")
    }

    withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId:"sa_freighteval_${env}", usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD']]) {
        withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId:"F5_OAuth2_creds_${env}", usernameVariable: 'CLIENT_ID', passwordVariable: 'CLIENT_SECRET']]) {
            payload = "\"grant_type=password&username=${USERNAME}&password=${PASSWORD}&scope=&client_id=${CLIENT_ID}&client_secret=${CLIENT_SECRET}\""
			httpResponse = sh(
                    script: "curl -v --silent -d ${payload} -H 'Accept: application/json' -H 'Content-Type: text/plain' -X POST ${oAuthTokenUrl}",
                    returnStdout: true
            ).trim()
            jwtTokenJson = readJSON text: httpResponse
            accessToken = jwtTokenJson['access_token']
        } 
    } 
    return accessToken        
}

def gitCheckoutFor(repoName, gitCommitId) {
    withCredentials([
         [$class: 'UsernamePasswordMultiBinding', credentialsId: GIT_CREDENTIAL, usernameVariable: 'GIT_USERNAME', passwordVariable: 'GIT_PASSWORD']
        ]) {
            def repoUrl = repoName + '.git'
            println "Pulling code for repoUrl =" + repoUrl
            sh("rm -rf ${repoName}")
            if(gitCommitId) {
                println "Checking out using git commit id for ${repoName}"
                sh("git clone https://${GIT_USERNAME}:${GIT_PASSWORD}@${GIT_DOMAIN}${repoUrl} ${repoName}")
                sh("git -C ./${repoName} reset --hard ${gitCommitId}")
            }
            else {
                error "gitCommitId is null, its mandatory for service instruction registration"
            }
        }
}