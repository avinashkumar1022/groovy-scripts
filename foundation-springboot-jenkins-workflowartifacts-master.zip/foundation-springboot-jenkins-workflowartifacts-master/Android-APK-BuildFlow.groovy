GIT_BASE_URL = "https://vaprd078.schneider.com/schneider/"
GIT_CREDENTIAL = 'internalgithub-snideployer'
GIT_DOMAIN = "vaprd078.schneider.com/schneider/"

GIT_CLOUD_BASE_URL = "git@github.com:schneidertech/"
GIT_CLOUD_CREDENTIAL = 'externalgithub-snideployer'

GIT_BRANCH_NAME = GitBranchName.trim()
REPO_LOCATION = GitRepoLocation.trim()
REPO_NAME = GitRepoName.trim()

node('uxunt2203') {
    stage("Execute Build Job") {  
        executeBuildFlowFor(REPO_NAME, GIT_BRANCH_NAME)
        println '********* Build Job Successful **********'
    }
}

def executeBuildFlowFor (repoName, branchName) {
    stage("Git Checkout") {
        if(REPO_LOCATION == "Cloud") {
            println "******** Checking out source code from External Git *********"
            println "Cleaning up workspace ..."
            deleteDir()
            dir(path: "${repoName}") {
                def repoUrl = GIT_CLOUD_BASE_URL + repoName + '.git'
                git branch: branchName, credentialsId: 'externalgithub-snideployer', url: repoUrl
                env.gitCommitId = sh(returnStdout: true, script: "git log -n 1 --pretty=format:'%h'").take(7)
                println "******** External Git Checkout Successful *********"
            }
        }
        else {
            println "******** Checking out source code from Internal Git *********"
            gitCheckoutFor(repoName, branchName)
            env.gitCommitId = getLatestCommitIdFor(repoName, branchName)
            println "******** Internal Git Checkout Successful *********"
        }
    }

    stage("Run npm build and add ionic and capacitor modules for Android") {
        println "*********** Adding Capacitor Dependencies *************"
        dir(path: "${repoName}") {
            sh "rm -rf node_modules"
            sh "npm install"
            //sh "npm install -D typescript"
            sh "npm install @types/node --save-dev"
            sh "npm i @types/node"
            sh "npm install ionic"
            sh "npm i fcm-node"
            //sh "npm install react-scripts"
            //sh "npm install @ionic/react-hooks"
            //sh "npm install node-sass"
            //sh "npm install --save-dev @types/googlemaps"
            //sh "npm install reactjs-pdf-reader"
            sh "npm install @capacitor/core @capacitor/cli"
            //sh "npm install run-script-os"
            sh "npm i os"
            sh "npm run build"
            //sh "npx cap init Schneider com.cognizantmobilityenterprise.schneider"
            //sh "npx cap add android"
            //sh "cordova platform add android@7.1.0"
            sh "npx cap copy android"
            sh "npx cap sync android"
        }
        println "*********** Adding ionic and capacitor dependencies successful *************"
    }

    stage("Gradle Build APK") {
        println "*********** Building APK *************"
        dir(path: "${repoName}/android") {
            
            sh "cp /opt/telematics/jenkins/gradlejar/gradle-5.6.4-all.zip ./gradle/wrapper"

            withGradle {
                //sh '/opt/xl-telematics/gradle-6.3/bin/gradle --debug build'
                sh "chmod 755 gradlew"
                sh "./gradlew build"
            }
        }
        println "*********** Building APK Successful *************"
    }
    
stage('Sign APK'){
dir(path: "${repoName}/android/app/build/outputs/apk/release") {
 signAndroidApks (
 keyStoreId: "android-apk0schneider",
 keyAlias: "",
 apksToSign: "**/*.apk"
 )
 }
}   
    
     stage("Publish to Azure App Center") {
   
        dir(path: "${repoName}") {
            
            appCenter apiToken: 'c2ed2768db5c8e4802a110f8750b339061405149', appName: 'SNI-Azure-Pipeline', distributionGroups: 'CE2O-DEV', notifyTesters: false, ownerName: 'KumarA8-schneider.com', pathToApp: 'android/app/build/outputs/apk/release/*release.apk', pathToDebugSymbols: '', pathToReleaseNotes: '', releaseNotes: 'Published from Jenkins Internal'
        }
    }
}

 def gitCheckoutFor(repoName, branchName) {
    withCredentials([
         [$class: 'UsernamePasswordMultiBinding', credentialsId: GIT_CREDENTIAL, usernameVariable: 'GIT_USERNAME', passwordVariable: 'GIT_PASSWORD']
        ]) {
            def repoUrl = repoName + '.git'
            println "Pulling code for repoUrl =" + repoUrl
            sh("rm -rf ${repoName}")
            sh("git clone --branch ${branchName} https://${GIT_USERNAME}:${GIT_PASSWORD}@${GIT_DOMAIN}${repoUrl} ${repoName}")
        }
}

def getLatestCommitIdFor(repoName, branchName) {
    withCredentials([
         [$class: 'UsernamePasswordMultiBinding', credentialsId: GIT_CREDENTIAL, usernameVariable: 'GIT_USERNAME', passwordVariable: 'GIT_PASSWORD']
         ]) {
            latestGitCommitId = sh(
                    script: "git ls-remote https://${GIT_USERNAME}:${GIT_PASSWORD}@${GIT_DOMAIN}${repoName} ${branchName} | cut -f1",
                    returnStdout: true
            ).trim()
        }
    return latestGitCommitId.substring(0,7)
} 