GIT_BASE_URL = "https://vaprd078.schneider.com/schneider/"
GIT_CREDENTIAL = 'eebde66b-39b8-4483-9ba0-7dc8d5d209da'
GIT_DOMAIN = "vaprd078.schneider.com/schneider/"
DOCKER_REGISTRY_URL = "dockerregistryunt1.intra.schneider.com"
DOCKER_REGISTRY_USERNAME = "dockerregistry"
DOCKER_REGISTRY_PASSWORD = "dockerregistry42018"
DEPLOYMENT_ARTIFACTS_REPO = "foundation-deployment-artifacts"
XL_DEPLOYIT_MANIFEST_FILE_NAME = "deployit-manifest.xml"
K8S_DEPLOYMENT_YAML = "./deployment/deployment.yml"
OCP_NONPRD_URL = "https://master.ocpunt.schneider.com:443"
OCP_PRD_URL = "https://master.ocp.schneider.com:443"

GIT_REPO_NAME = GitRepositoryName.trim()
GIT_BRANCH_NAME = GitBranchName.trim()
CONTEXT_PATH = ContextPath.trim()
XLD_FOLDER = XLDFolder.trim()
PROJECT_NAMESPACE = ProjectNamespace.trim()
GIT_COMMIT_ID = GitCommitId.trim()

XLD_RESOURCE_NODE = """<openshift.ResourcesFile name=\"/{{REPO_NAME}}-{{RESOURCE_FOLDER_NAME}}\" file=\"{{RESOURCE_FOLDER_PATH}}\"><tags><value>${PROJECT_NAMESPACE}</value></tags><scanPlaceholders>true</scanPlaceholders><preScannedPlaceholders>true</preScannedPlaceholders><placeholders /><delimiters>{{ }}</delimiters></openshift.ResourcesFile>"""

node('uxprd1480') {
    stage("Execute Build Job - ${GIT_REPO_NAME}") {  

        if(GIT_REPO_NAME == "") {
            error "Build Parameter - GitRepositoryName is missing"
        }

        if(CONTEXT_PATH == "") {
            error "Build Parameter - ContextPath is missing"
        }

        if(GIT_BRANCH_NAME == "" && GIT_COMMIT_ID == "") {
            error "Build Parameter - Either one of GitCommitId or GitBranchName is mandatory"
        } 
        
        if (GIT_COMMIT_ID != "" && GIT_COMMIT_ID.length() < 7) {
            error "Build Parameter - Must have atleast 7 characters for the gitCommitId"
        }

        if(XLD_FOLDER == "") {
            error "Build Parameter - XLDFolder is missing"
        }

        if(PROJECT_NAMESPACE == "") {
            error "Build Parameter - ProjectNamespace is missing"
        }

        executeBuildFlowFor(GIT_REPO_NAME, GIT_BRANCH_NAME, GIT_COMMIT_ID)
        println '********* Execute Build Job Successful **********'
    }
}

def executeBuildFlowFor (repoName, branchName, gitCommitId) {
    
    stage("Git Checkout") {
        println "******** Checking out source code from Git *********"
        gitCheckoutFor(repoName, branchName, gitCommitId)
        println "******** Git Checkout Successful *********"
    }

    stage("Build Docker Image") {
        if(GIT_COMMIT_ID) {
            env.gitCommitId = GIT_COMMIT_ID.substring(0,7)
        }
        else {
            env.gitCommitId = getLatestCommitIdFor(GIT_REPO_NAME, GIT_BRANCH_NAME)
        }
        gitCheckoutFor(DEPLOYMENT_ARTIFACTS_REPO, "master", "")
        sh("cp -r ${repoName} ./${DEPLOYMENT_ARTIFACTS_REPO}/tiles/${CONTEXT_PATH}")
        sh "sed -i 's~{{GIT_REPO_NAME}}~${CONTEXT_PATH}~g' ./${DEPLOYMENT_ARTIFACTS_REPO}/tiles/Dockerfile"
        sh("docker build -t ${DOCKER_REGISTRY_URL}/${repoName}:${BUILD_NUMBER}-${env.gitCommitId} ./${DEPLOYMENT_ARTIFACTS_REPO}/tiles/")
        println "*********** Build docker image And Publish to registry Successful *************"
    }

    stage("Push to Docker Registry") {
        sh("docker login ${DOCKER_REGISTRY_URL} --username ${DOCKER_REGISTRY_USERNAME} --password ${DOCKER_REGISTRY_PASSWORD}")
        sh("docker push ${DOCKER_REGISTRY_URL}/${repoName}:${BUILD_NUMBER}-${env.gitCommitId}")
        sh("docker rmi ${DOCKER_REGISTRY_URL}/${repoName}:${BUILD_NUMBER}-${env.gitCommitId}")
        println "*********** Pushing docker image to registry Successful *************"
    }

    stage("Build XL Deploy DAR Package") {
        sh("cp -r ./${repoName}/k8s/* .")
        sh "cp ./${DEPLOYMENT_ARTIFACTS_REPO}/xebia/${XL_DEPLOYIT_MANIFEST_FILE_NAME} ${XL_DEPLOYIT_MANIFEST_FILE_NAME}"

        resourceFiles = sh(
                    script: "find ./${repoName}/k8s/ -name '*.yml' -print",
                    returnStdout: true
            ).trim()

        resourceFiles = resourceFiles.replace("./${repoName}/k8s", "")
        println "************ Resources in k8s Folder ************"
        println "${resourceFiles}"

        xldResourcesNode = generateResourcesOnXLDManifestFile(repoName, resourceFiles)     
        println("************* Generated XLD Resources Node *****************")
        println "${xldResourcesNode}"

        sh("sed -i 's~{{IMAGE_VERSION}}~${BUILD_NUMBER}-${env.gitCommitId}~g' ${K8S_DEPLOYMENT_YAML}");

        sh("sed -i 's~minReadySeconds:[ 0-9]*~minReadySeconds: 10~g' ${K8S_DEPLOYMENT_YAML}");

        sh("sed -i 's~{{ARTIFACT_VERSION}}~${BUILD_NUMBER}-${env.gitCommitId}~g' ${XL_DEPLOYIT_MANIFEST_FILE_NAME}");
        sh("sed -i 's~{{XLD_FOLDER}}~${XLD_FOLDER}~g' ${XL_DEPLOYIT_MANIFEST_FILE_NAME}");

        if(XLD_FOLDER.equalsIgnoreCase("Snapshots")) {
            sh("sed -i 's~{{REPO_NAME}}~${repoName}-snapshot~g' ${XL_DEPLOYIT_MANIFEST_FILE_NAME}");
        }
        else {
            sh("sed -i 's~{{REPO_NAME}}~${repoName}~g' ${XL_DEPLOYIT_MANIFEST_FILE_NAME}");
        }

        sh("sed -i 's~{{REPO_NAME}}~${repoName}~g' ${XL_DEPLOYIT_MANIFEST_FILE_NAME}");
        sh("sed -i 's~{{XLD_RESOURCES_NODES}}~${xldResourcesNode}~g' ${XL_DEPLOYIT_MANIFEST_FILE_NAME}");

        xldCreatePackage artifactsPath: "", manifestPath: "${XL_DEPLOYIT_MANIFEST_FILE_NAME}", darPath: '${GitRepositoryName}-${gitCommitId}.dar'
        println "### Build XL Deploy DAR Package Successful ###";
    }

    stage("Deploy to OCP") {
       sh("cp -r /export/home/sa_xebiaadm/oc-client/binaries .")
       sh("oc version")

       ymlFiles = resourceFiles.split('\n');
        ymlFiles.each() {
            if(it) {
                println "Deploying to OCP"
                withCredentials([string(credentialsId: 'ocp-nonprd-token', variable: 'OCP_NONPRD_TOKEN')]) {
                    loginWithCredentials(OCP_NONPRD_URL, OCP_NONPRD_TOKEN, "fit-oms")
                }
                sh("oc apply -f .${it}")
            }
            else {
                error "Unable to retrieve the Yml files inside k8s folder for ${repoName}";
            }
        }

       println "### Deploy to OCP Successful ###";
    }

    // stage('XL Deploy Publish') {  
    //     xldPublishPackage serverCredentials: 'XldCreds', darPath: '${serviceName}-${gitCommitId}.dar'
    //     println "Pushed docker image with version ${env.gitCommitId}"
    //     println "Cleaning up workspace ..."
    //     deleteDir()
    //     println "### XL Deploy Publish Successful ###"
    // } 
}

def gitCheckoutFor(repoName, branchName, gitCommitId) {
    withCredentials([
         [$class: 'UsernamePasswordMultiBinding', credentialsId: GIT_CREDENTIAL, usernameVariable: 'GIT_USERNAME', passwordVariable: 'GIT_PASSWORD']
        ]) {
            def repoUrl = repoName + '.git'
            println "Pulling code for repoUrl =" + repoUrl
            sh("rm -rf ${repoName}")
            if(gitCommitId) {
                println "Checking out using git commit id for ${repoName}"
                sh("git clone https://${GIT_USERNAME}:${GIT_PASSWORD}@${GIT_DOMAIN}${repoUrl} ${repoName}")
                sh("git -C ./${repoName} reset --hard ${gitCommitId}")
            }
            else if(branchName) {
                println "Checking out using branch name for ${repoName}"
                sh("git clone --branch ${branchName} https://${GIT_USERNAME}:${GIT_PASSWORD}@${GIT_DOMAIN}${repoUrl} ${repoName}")
            }
            else {
                error "Both branchName and gitCommitId are null, Either one of them is mandatory"
            }
        }
}

def getLatestCommitIdFor(repoName, branchName) {
    withCredentials([
         [$class: 'UsernamePasswordMultiBinding', credentialsId: GIT_CREDENTIAL, usernameVariable: 'GIT_USERNAME', passwordVariable: 'GIT_PASSWORD']
         ]) {
            latestGitCommitId = sh(
                    script: "git ls-remote https://${GIT_USERNAME}:${GIT_PASSWORD}@${GIT_DOMAIN}${repoName} ${branchName} | cut -f1",
                    returnStdout: true
            ).trim()
        }
    return latestGitCommitId.substring(0,7)
}

def generateResourcesOnXLDManifestFile(repoName, resourceFiles) {
    def xldResourcesNode = "";
    ymlFiles = resourceFiles.split('\n');

    def resourceNames = ["configmap", "secret", "deployment", "service", "route"]
    def order = 1
    
    for(int index=0; index < resourceNames.size(); index++) {
        ymlFiles.each() {
            if(it) {
                if(it.contains(resourceNames[index])) {
                    resourceNode = "${XLD_RESOURCE_NODE}";
                    resourceNode = resourceNode.replace("{{RESOURCE_FOLDER_PATH}}", it);
                    resourceNode = resourceNode.replace("{{REPO_NAME}}", order + "-" + repoName);
                    println "Updating resource file name for ${resourceNames[index]} = " + it.contains(resourceNames[index])
                    resourceNode = resourceNode.replace("{{RESOURCE_FOLDER_NAME}}", it.split("/")[2]);
                    order++
                    xldResourcesNode = xldResourcesNode + resourceNode;
                }
            }
            else {
                error "Unable to retrieve the Yml files inside k8s folder for ${repoName}";
            }
        }
    }
    return xldResourcesNode;
}

def loginWithCredentials(ocpUrl, token, namespace) {
    sh("oc login ${ocpUrl} --token=${token} -n ${namespace}")
}