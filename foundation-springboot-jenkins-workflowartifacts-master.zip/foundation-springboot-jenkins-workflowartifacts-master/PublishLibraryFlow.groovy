GIT_BASE_URL = "https://vaprd078.schneider.com/schneider/"
GIT_CREDENTIAL = 'eebde66b-39b8-4483-9ba0-7dc8d5d209da'
GIT_DOMAIN = "vaprd078.schneider.com/schneider/"
GIT_REPO_NAME = GitRepoName.trim()
BRANCH_NAME = BranchName.trim()
RELEASE_DESCRIPTION = ReleaseDescription
PRE_RELEASE=PreRelease

GIT_REPO_RELEASE_RESOURCE_URL = "/repos/schneider";
GIT_HOST = "https://vaprd078.schneider.com";
GIT_API = "/api/v3";
URL_SEPARATOR = '/';
SONAR_URL = "http://uxprd2600:8080/sonarqube"

node('prd-xebia-build-agent') {
    stage("Git Checkout - ${GIT_REPO_NAME}") {

        if(GIT_REPO_NAME == "") {
            error "Build Parameter - GitRepoName is missing"
        }

        if(BRANCH_NAME == "") {
            error "Build Parameter - BranchName is missing"
        }

        if(RELEASE_DESCRIPTION == "") {
            error "Build Parameter - ReleaseDescription is missing, Please provide a detailed description of this release changes"
        }

        println "******** Checking out source code from Git *********"
        gitCheckoutFor(GIT_REPO_NAME, BRANCH_NAME)
        println "******** Git Checkout Successful *********"
    }

    stage("Update Pom For Release - ${GIT_REPO_NAME}") {
        println "******** Updating Pom For Release - Removing snapshot version and add a unique build # for release ***********"
        artifactVersion = updatePomForRelease(GIT_REPO_NAME)
        versionNum = "v${artifactVersion.split(":")[2]}"
        println "************* Update Pom For Release Successful *************"
    }

    stage("Build Jar - ${GIT_REPO_NAME}") {
        println "*********** Compiling maven project to build the jar *************"
        if(versionNum.toLowerCase().contains("snapshot")){
            executeMvnGoal(GIT_REPO_NAME, "clean verify test source:jar source:test-jar install package")
        }
        else {
            executeMvnGoal(GIT_REPO_NAME, "clean verify test install package") 
        }
    }

    stage('Sonar Quality Gate') { 
         sonarServiceUrl = "${SONAR_URL}/dashboard?id=${GIT_REPO_NAME}"
         dir(path: "${GIT_REPO_NAME}") {
             jacocoExecFilePath = sh(
                    script: "find . -name jacoco*.exec -print",
                    returnStdout: true
            ).trim()

            jacocoXmlPath = sh(
                    script: "find . -name jacoco.xml -print",
                    returnStdout: true
            ).trim()

            sh "/opt/schneider/sonar-scanner-cli/bin/sonar-scanner -e -Dsonar.projectKey=${GIT_REPO_NAME} -Dsonar.host.url=${SONAR_URL} -Dsonar.login=bfc9f8d776ff0e8ff1f75121160b853765daf8b1 -Dsonar.language=java -Dsonar.projectBaseDir=$WORKSPACE/${GIT_REPO_NAME} -Dsonar.java.binaries=. -Dsonar.java.coveragePlugin=jacoco -Dsonar.jacoco.reportPaths=${jacocoExecFilePath} -Dsonar.coverage.jacoco.xmlReportPaths=${jacocoXmlPath} -Dsonar.source=$WORKSPACE/${GIT_REPO_NAME}/src -Dsonar.sourceEncoding=UTF-8"
			sleep 5
            if(isSonarQualityGatePassed(GIT_REPO_NAME)) {
                println "Sonar Quality Gate passed ...."
            } else {
                error "Sonar Quality Gate Check Failed, For more details, Please check here ${sonarServiceUrl}"
            }
         }
     }

     stage("Publish to Repository - ${GIT_REPO_NAME}") {
         executeMvnGoal(GIT_REPO_NAME, "-Dmaven.test.skip=true -Dmaven.install.skip=true deploy") 
         println "Published ${GIT_REPO_NAME} library with version - ${artifactVersion}"
     }

    stage("Create tag - ${GIT_REPO_NAME}") {
        def preRelease = false;   
        def createRelease = false;
        if(versionNum.toLowerCase().contains("snapshot")){
            preRelease = true;
            if(PRE_RELEASE == 'YES'){
                createRelease = true;
            }else{
                println "It is a SNAPSHOT version with PreRelease NO, so skipping tag creation"
            }
        }else{
            createRelease = true;
        }
        if(createRelease){
			def version = ""+versionNum; 
            createTagFor(GIT_REPO_NAME, versionNum);  
            def gitRepositoryReleaseUrl = GIT_HOST + GIT_API + GIT_REPO_RELEASE_RESOURCE_URL + URL_SEPARATOR + GIT_REPO_NAME + URL_SEPARATOR + 'releases';
            def releaseRequest = readJSON text: '{}'
            releaseRequest.put("tag_name",version);
            releaseRequest.put("target_commitish", BRANCH_NAME);
            releaseRequest.put("name", GIT_REPO_NAME);
            releaseRequest.put("body", RELEASE_DESCRIPTION);
            releaseRequest.put("draft", false);
            releaseRequest.put("prerelease", preRelease);
            def releaseRequestString = releaseRequest.toString();
            println releaseRequestString;
	    //adding  ignoreSslErrors: true - because of cert issue - this should be fixed by hosting team as our cert is
	    //self-signed
            def releaseResponse = httpRequest acceptType: 'APPLICATION_JSON', 
                            authentication: GIT_CREDENTIAL, 
                            consoleLogResponseBody: true, 
                            httpMode: 'POST', 
                            requestBody: releaseRequestString, 
                            responseHandle: 'LEAVE_OPEN',
		            ignoreSslErrors: true,
                            timeout: 60, 
                            url: gitRepositoryReleaseUrl, 
                            validResponseCodes: '200:422';
    
            if(releaseResponse.status == 201){
                 println("** released version = "+ version + "**");
            }
        }

        echo "----------------------------------------------------------------------------------"
        echo "<dependency>\n<groupId>${artifactVersion.split(":")[0]}</groupId>\n<artifactId>${artifactVersion.split(":")[1]}</artifactId>\n<version>${artifactVersion.split(":")[2]}</version>\n</dependency>"
        echo "----------------------------------------------------------------------------------"
    }
}

def gitCheckoutFor(repoName, branchName) {
    
    withCredentials([
         [$class: 'UsernamePasswordMultiBinding', credentialsId: GIT_CREDENTIAL, usernameVariable: 'GIT_USERNAME', passwordVariable: 'GIT_PASSWORD']
        ]) {
            def repoUrl = repoName + '.git'
            println "Pulling code for repoUrl =" + repoUrl
            sh("rm -rf ${repoName}")
            sh("git clone --branch ${branchName} https://${GIT_USERNAME}:${GIT_PASSWORD}@${GIT_DOMAIN}${repoUrl} ${repoName}")
        }
}

def updatePomForRelease(repoName) {
    def pom = readMavenPom file: repoName + '/pom.xml'
    def version = ""

    try {
        version = pom.version
    }
    catch (Exception e) {
        println "Version tag is missing in pom.xml for " + repoName
        sh "exit 1"
    }
    
    def newArtifactVersion = pom.groupId + ":" + pom.artifactId + ":" + version   
    executeMvnGoal(repoName, "versions:set versions:commit -DnewVersion=${version}")
    return newArtifactVersion
}

def executeMvnGoal(repoName, mvnGoal) {
    withMaven(
        maven: 'M3',
        mavenSettingsConfig: '861beabf-0e69-49b4-bc3c-aa5de0b1eb7e',
        mavenLocalRepo: '.repository'
    ) {
        sh "mvn -f ./${repoName}/pom.xml ${mvnGoal}"
    }
}

def createTagFor(repoName, version) {
    def repoUrl = repoName + '.git'
    echo "Creating tag for repository ${repoName} with tag as ${version}"
    withCredentials([
         [$class: 'UsernamePasswordMultiBinding', credentialsId: GIT_CREDENTIAL, usernameVariable: 'GIT_USERNAME', passwordVariable: 'GIT_PASSWORD']
         ]) {
            sh("git -C ./${repoName} tag -a ${version} -m 'Tag Created for Build Id: ${env.BUILD_ID} with version:${version}'")   
            sh("git -C ./${repoName} push https://${GIT_USERNAME}:${GIT_PASSWORD}@${GIT_DOMAIN}${repoUrl} tag ${version}")
        }
}

def isSonarQualityGatePassed(repoName) {
    qualityGateStatusUrl = "${SONAR_URL}/api/project_branches/list?project=${repoName}"
    qualityGateStatusJson = sh (
                script: "curl -X GET ${qualityGateStatusUrl} -H 'Accept: application/json'",
                returnStdout: true
            )
    println "QualityGateJson=${qualityGateStatusJson}" 
    qualityGateStatus = readJSON text: qualityGateStatusJson
    if(qualityGateStatus != null && qualityGateStatus.branches[0].status.qualityGateStatus == "OK") {
        println "Sonar Quality Gate Check Passed"
        return true
    } else {
        return false
    }
}

