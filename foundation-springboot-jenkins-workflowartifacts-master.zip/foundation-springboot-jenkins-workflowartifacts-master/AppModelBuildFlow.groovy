GIT_BASE_URL = "https://vaprd078.schneider.com/schneider/"
GIT_CREDENTIAL = 'eebde66b-39b8-4483-9ba0-7dc8d5d209da'
APP_MODEL_REPO = "foundation-springboot-appmodels"
GIT_DOMAIN = "vaprd078.schneider.com/schneider/"

GIT_BRANCH = 'git-branch'
GIT_COMMIT_ID = 'git-commit-id'
LATEST_BUILD_VERSION = 'latest-build-version'

APPLICATION_NAME = ApplicationName.trim()
GIT_BRANCH_NAME = GitBranchName.trim()
MODEL_FILE = APPLICATION_NAME + ".json"
GIT_BRANCH_NODE = "git-${GIT_BRANCH_NAME}"

node('prd-xebia-build-agent') {

    def modifiedRepositories = []
    appGraph = "";

    stage("Load App Model from Git - ${APPLICATION_NAME}") {

        if(APPLICATION_NAME == "") {
            error "Build Parameter - ApplicationName is missing"
        }

        if(GIT_BRANCH_NAME == "") {
            error "Build Parameter - GitBranchName is missing"
        }

        println 'Loading App Model from ' + MODEL_FILE
        gitCheckoutFor(APP_MODEL_REPO, 'master')
        appGraph = readJSON file: APP_MODEL_REPO+'/'+ MODEL_FILE
        modifiedRepositories = getModifiedRepositories(appGraph)
        println "List of Modified Repositories: " + modifiedRepositories
        println "******** Load App Model from Git Successful *********"
    }

    stage("Execute Build Job - ${APPLICATION_NAME}") {   
        def index = 0
    
        modifiedRepositories.each {
            def repoName = modifiedRepositories[index]['repoName']
            def gitBranch = modifiedRepositories[index]['gitBranch']
            def gitCommitId = modifiedRepositories[index]['gitCommitId']

            if(gitCommitId == "") {
                echo "No git-commit-id found - ${GIT_BRANCH_NAME}, so ignoring build artifacts flow for ${repoName}"
            }
            else {
                println "Building " + repoName + " for branch " + gitBranch
                executeBuildFlowFor(repoName, gitBranch, gitCommitId)
                updateAppModel(appGraph, repoName, GIT_COMMIT_ID, modifiedRepositories[index]['gitCommitId']);
            }

            index++
        }
        println '********* Execute Build Job Successful **********'
    }

    stage("Update App Model to git - ${APPLICATION_NAME}") {
        writeJSON file: APP_MODEL_REPO+'/'+ MODEL_FILE, json: appGraph, pretty: 4
        pushToGit(APP_MODEL_REPO, 'master')
        println "Cleaning up workspace ..."
        deleteDir()
        sh "ls -ltr"
        println '********* Update App Model to Git with latest values Successful **********'
    }
}

def executeBuildFlowFor (repoName, branchName, gitCommitId) {
    
    stage("Git Checkout - ${repoName}") {
        println "******** Checking out source code from Git *********"
        gitCheckoutFor(repoName, branchName)
        println "******** Git Checkout Successful *********"
    }

    stage("Update Pom For Release - ${repoName}") {
        println "******** Updating Pom For Release - Removing snapshot version and add a unique build # for release ***********"
        artifactVersion = updatePomForRelease(repoName, gitCommitId)
        updateAppModel(appGraph, repoName, LATEST_BUILD_VERSION, artifactVersion);
        println "************* Update Pom For Release Successful *************"
    }

    stage("Build Jar And Publish to Repository - ${repoName}") {
        println "*********** Compiling maven project to build the jar *************"
        if(isArtifactExists(repoName, artifactVersion)) {
            echo "Artifact with version ${artifactVersion} already exists, so ignoring rebuild and updating App Model only"
        }
        else {
            executeMvnGoal(repoName, "-Dmaven.test.skip=true clean install package deploy")
        }
        println "*********** Build Jar And Publish to Repository Successful *************"
    }
}

def isArtifactExists(repoName, version) {
    def appVersionSplits = version.split(':');
    def splitGroupId = appVersionSplits[0].replace('.','/');
    def splitArtifactId = appVersionSplits[1];
    def splitVersionId = appVersionSplits[2];
    def jarFile = splitArtifactId+"-"+splitVersionId + ".jar"
    httpStatusCode = sh(script: "curl -s -o /dev/null -w \"%{http_code}\" -I ${ARCHIVA_URL}/${splitGroupId}/${splitArtifactId}/${splitVersionId}/${jarFile}", returnStdout: true).trim()
    echo "Checking HTTP Status Code if artifact exists: " + httpStatusCode
    return httpStatusCode.equalsIgnoreCase("200")
}

def gitCheckoutFor(repoName, branchName) {
    
    withCredentials([
         [$class: 'UsernamePasswordMultiBinding', credentialsId: GIT_CREDENTIAL, usernameVariable: 'GIT_USERNAME', passwordVariable: 'GIT_PASSWORD']
        ]) {
            def repoUrl = repoName + '.git'
            println "Pulling code for repoUrl =" + repoUrl
            sh("rm -rf ${repoName}")
            sh("git clone --branch ${branchName} https://${GIT_USERNAME}:${GIT_PASSWORD}@${GIT_DOMAIN}${repoUrl} ${repoName}")
        }
}

def updatePomForRelease(repoName, gitCommitId) {
    def pom = readMavenPom file: repoName + '/pom.xml'
    def version = ""

    try {
        if(pom.version.contains("-SNAPSHOT")) {
            //version = pom.version.replace("-SNAPSHOT", ".${currentBuild.timeInMillis}")
            version = pom.version.replace("-SNAPSHOT", ".${gitCommitId}")
         }
        else {
            //version = pom.version+".${currentBuild.timeInMillis}"
            version = pom.version+".${gitCommitId}"
        }
    }
    catch (Exception e) {
        println "Version tag is missing in pom.xml for " + repoName
        sh "exit 1"
    }
    
    def newArtifactVersion = pom.groupId + ":" + pom.artifactId + ":" + version    
    executeMvnGoal(repoName, "versions:set versions:commit -DnewVersion=${version}")
    return newArtifactVersion
}

def executeMvnGoal(repoName, mvnGoal) {
    withMaven(
        maven: 'M3',
        mavenSettingsConfig: '861beabf-0e69-49b4-bc3c-aa5de0b1eb7e',
        mavenLocalRepo: '.repository'
    ) {
        sh "mvn -f ./${repoName}/pom.xml ${mvnGoal}"
    }
}

def getInfoFromAppModel(appGraph, repoName) {

    for (int nodePos = 0; nodePos < appGraph.graphs[0].nodes.size(); nodePos++) {
        if (appGraph.graphs[0].nodes[nodePos].id == repoName) {
            createBranchNodeifnotExists(appGraph, repoName, nodePos)
            jsonNode = appGraph.graphs[0].nodes[nodePos][GIT_BRANCH_NODE];
            break;
        }
    }

    return jsonNode;
}

def createBranchNodeifnotExists(appGraph, repoName, nodePos) {

    def latestCommitId = getLatestCommitIdFor(repoName, GIT_BRANCH_NAME) 
    
    if(latestCommitId == "" || latestCommitId == null) {
        echo "Git branch with name ${GIT_BRANCH_NAME} does not exists for repository ${repoName}, continuing the build flow"
    }
    else {
        echo "Found ${GIT_BRANCH_NAME} with git-commit-id - ${latestCommitId} for ${repoName}" 
        if(appGraph.graphs[0].nodes[nodePos][GIT_BRANCH_NODE] == null) {
            echo "Json node - ${GIT_BRANCH_NODE} not available, so creating one ..."
            def branchNode = [:]
            branchNode.put(GIT_COMMIT_ID, "")
            branchNode.put(LATEST_BUILD_VERSION, "")
            appGraph.graphs[0].nodes[nodePos][GIT_BRANCH_NODE] = branchNode
            echo "Created ${GIT_BRANCH_NODE} with value: " + appGraph.graphs[0].nodes[nodePos][GIT_BRANCH_NODE]
        }
    }

    return appGraph
}

def updateAppModel(appGraph, repoName, attrName, newValue) {
    for (int nodePos = 0; nodePos < appGraph.graphs[0].nodes.size(); nodePos++) {
        if (appGraph.graphs[0].nodes[nodePos].id == repoName) {
            appGraph.graphs[0].nodes[nodePos][GIT_BRANCH_NODE][attrName] = newValue;
            break;
        }
     }
}

def getLatestCommitIdFor(repoName, branchName) {
    withCredentials([
         [$class: 'UsernamePasswordMultiBinding', credentialsId: GIT_CREDENTIAL, usernameVariable: 'GIT_USERNAME', passwordVariable: 'GIT_PASSWORD']
         ]) {
            latestGitCommitId = sh(
                    script: "git ls-remote https://${GIT_USERNAME}:${GIT_PASSWORD}@${GIT_DOMAIN}${repoName} ${branchName} | cut -f1",
                    returnStdout: true
            ).trim()
        }
    return latestGitCommitId
}

def getModifiedRepositories(appGraph) {
    def pos = 0;
    def repoName = "";
    def modifiedRepoList = []

    appGraph.graphs[0].edges.each {
        
        if (appGraph.graphs[0].edges[pos].source == APPLICATION_NAME) {
            repoName = appGraph.graphs[0].edges[pos].target
            def jsonNode = getInfoFromAppModel(appGraph, repoName)
            println "Working on Json Node for ${repoName}: " + jsonNode
           
            def latestCommitId = getLatestCommitIdFor(repoName, GIT_BRANCH_NAME)

            if(jsonNode == null) {
                println "No valid branch ${GIT_BRANCH_NAME} exists for ${repoName}, continuing the build flow"
            }
            else {
                println "Latest Commit Id=[" + latestCommitId + "] Latest Build Version=[" + jsonNode[LATEST_BUILD_VERSION] + "]"
                println "Compare=" + (latestCommitId.equalsIgnoreCase(jsonNode[GIT_COMMIT_ID]))

                if ((latestCommitId.equalsIgnoreCase(jsonNode[GIT_COMMIT_ID]) == false) || (jsonNode[LATEST_BUILD_VERSION] == "")) {
                    println 'Identified modifications in code for ' + repoName + ', so executing build flow'
                    def repoNode = [:]
                    repoNode.put('repoName', repoName)
                    repoNode.put('gitCommitId', latestCommitId)
                    repoNode.put('gitBranch', GIT_BRANCH_NAME)

                    modifiedRepoList << repoNode
                } 
                else {
                    println "No Changes, so skipping repourl=" + repoName
                }
            }
        }
        pos++
    }
    return modifiedRepoList
}

def pushToGit(repoName, branchName) {
    
    def repoUrl = repoName + '.git'
    println 'Pushing to ' + repoUrl
    
    withCredentials([
         [$class: 'UsernamePasswordMultiBinding', credentialsId: GIT_CREDENTIAL, usernameVariable: 'GIT_USERNAME', passwordVariable: 'GIT_PASSWORD']
         ]) {
             sh "ls -ltr"
             sh "pwd"
             sh("git -C ./${repoName} pull https://${GIT_USERNAME}:${GIT_PASSWORD}@${GIT_DOMAIN}${repoUrl} ${branchName}")
             sh("git -C ./${repoName} config user.name 'sni-deployer'")		
             sh("git -C ./${repoName} config user.email 'subramanij@schneider.com'")
             sh("git -C ./${repoName} add ${MODEL_FILE}")
             sh("git -C ./${repoName} diff --quiet --exit-code --cached || git -C ./${repoName} commit -am 'Updated From Jenkins Build Flow ID - .${currentBuild.id} for ${APPLICATION_NAME}'")
             sh("git -C ./${repoName} push https://${GIT_USERNAME}:${GIT_PASSWORD}@${GIT_DOMAIN}${repoUrl} ${branchName}")
        }
}
