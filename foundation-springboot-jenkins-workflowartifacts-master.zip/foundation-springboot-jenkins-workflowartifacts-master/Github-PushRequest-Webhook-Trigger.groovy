GIT_CREDENTIAL = 'eebde66b-39b8-4483-9ba0-7dc8d5d209da'
GIT_DOMAIN = "vaprd078.schneider.com/schneider/"
SA_XEBIADEPLOYERPRD = "internal_git_xebiadeployerprd"

node("prd-xebia-build-agent") {
	echo repoName
	echo "Push request to ${ref} by ${notificationId}"
    echo newCommitId
    buildUrl = "${BUILD_URL}/console"
    def autoCancelled = false
        try {
           stage('Validating Push Request Branches') { 
               if(ref.toLowerCase() == "refs/heads/release") {
		          echo "${ref} - code sync - exexuting the steps"
		       } else {
                 autoCancelled = true
                 echo "skipping push request trigger for ${ref}"
                 error "Aborting the build"
		      }
           }
       } catch (Exception e) {
           if (autoCancelled) {
              currentBuild.result = 'SUCCESS'
               // return here instead of throwing error to keep the build "green"
              return
           }
           throw e
       }

       stage("Git Checkout") {
           gitCheckoutFor(repoName, "release", "")
       }

       stage("Code Sync from release to sprint_release") {
             baseBranch = "release"
             headBranch = "sprint_release"
             isBranchUptodate = checkBranchAheadOf(baseBranch, headBranch)
             if(!isBranchUptodate) {
               codeSync(baseBranch, headBranch)
             }
       }

       stage("Code Sync from release to uat_release") {
            baseBranch = "release"
            headBranch = "uat_release"
            isBranchUptodate = checkBranchAheadOf(baseBranch, headBranch)
            if(!isBranchUptodate) {
                codeSync(baseBranch, headBranch)
            }
       }

       stage("Cleanup") {
           deleteDir()
       }
}

def codeSync(baseBranch, headBranch) {
    prResponseStr = createPR(baseBranch, headBranch)
    println prResponseStr
    prResponseJson = readJSON text: prResponseStr
    prNumber = prResponseJson['number']
    if(prNumber) {
        sha = prResponseJson['head']['sha']
        println "Cretead PR ${prNumber} from ${baseBranch} to ${headBranch} successfully with head.sha = ${sha}"
        sleep 5
        reviewResponseStr = createReviewForPR(prNumber, sha)
        println reviewResponseStr
        sleep 5
        mregeResponseStr = mergePR(baseBranch, headBranch, prNumber, sha)
        println mregeResponseStr
    } else {
        error "Ignoring the auto-merge because either PR already exists from ${baseBranch} to ${headBranch} or no commits between ${baseBranch} and ${headBranch}"
    }   
}

def createReviewForPR(prNumber, sha) {
    jsonPayload = readJSON text: '{}'
    jsonPayload['commit_id'] = sha
    jsonPayload['event'] = "APPROVE"
    jsonPayloadAsString = new groovy.json.JsonBuilder(jsonPayload).toPrettyString()
    println "${jsonPayloadAsString}"
    response = invokeGithubApi("POST", "pulls/${prNumber}/reviews", "${jsonPayloadAsString}", SA_XEBIADEPLOYERPRD)
    return response
}

def mergePR(baseBranch, headBranch, prNumber, sha) {
    jsonPayload = readJSON text: '{}'
    jsonPayload['commit_title'] = "jenkins - merge " + baseBranch + " to " + headBranch
    jsonPayload['commit_message'] = "Auto merged by Jenkins"
    jsonPayload['sha'] = sha
    jsonPayload['merge_method'] = "merge"
    jsonPayloadAsString = new groovy.json.JsonBuilder(jsonPayload).toPrettyString()
    println "${jsonPayloadAsString}"
    response = invokeGithubApi("PUT", "pulls/${prNumber}/merge", "${jsonPayloadAsString}")
    return response
}

def createPR(baseBranch, headBranch) {
    jsonPayload = readJSON text: '{}'
    jsonPayload['title'] = "jenkins - " + baseBranch + " to " + headBranch
    jsonPayload['body'] = "Created by Jenkins Push hook on commit to release branch"
    jsonPayload['head'] = baseBranch
    jsonPayload['base'] = headBranch
    jsonPayloadAsString = new groovy.json.JsonBuilder(jsonPayload).toPrettyString()
    println "${jsonPayloadAsString}"
    response = invokeGithubApi("POST", "pulls", "${jsonPayloadAsString}")
    return response
}

def checkBranchAheadOf(baseBranchName, headBranchName) {
    def isBranchUptodate = true;
    println "Checking branch ${baseBranchName} is ahead of ${headBranchName}"
    dir(path: "${repoName}") {
            commitDiff = sh (
                script: "git diff origin/${headBranchName}...origin/${baseBranchName}",
                returnStdout: true
            ).trim()
            println commitDiff
            if(commitDiff == "") {
                println "Branch ${baseBranchName} is in sync with ${headBranchName}"
                isBranchUptodate = isBranchUptodate
            }
            else {
                println "Branch ${baseBranchName} is not in sync with ${headBranchName}"
                isBranchUptodate = false
            }
            return isBranchUptodate
        }
}

def invokeGithubApi(httpMethod, apiPath, payload) {
    return invokeGithubApi(httpMethod, apiPath, payload, GIT_CREDENTIAL)
}

def invokeGithubApi(httpMethod, apiPath, payload, credsId) {
    withCredentials([
		[$class: 'UsernamePasswordMultiBinding', credentialsId: credsId, usernameVariable: 'GIT_USERNAME', passwordVariable: 'GIT_PASSWORD']
		]) {
            response = sh (
                script: "curl -s -X ${httpMethod} https://${GIT_USERNAME}:${GIT_PASSWORD}@vaprd078.schneider.com/api/v3/repos/schneider/${repoName}/${apiPath} -H 'Content-Type: application/json' -d '${payload}'",
                returnStdout: true
            ).trim()
		}
        
    return response
}

def gitCheckoutFor(repoName, branchName, gitCommitId) {
    withCredentials([
         [$class: 'UsernamePasswordMultiBinding', credentialsId: GIT_CREDENTIAL, usernameVariable: 'GIT_USERNAME', passwordVariable: 'GIT_PASSWORD']
        ]) {
            def repoUrl = repoName + '.git'
            println "Pulling code for repoUrl =" + repoUrl
            sh("rm -rf ${repoName}")
            if(gitCommitId) {
                println "Checking out using git commit id for ${repoName}"
                sh("git clone https://${GIT_USERNAME}:${GIT_PASSWORD}@${GIT_DOMAIN}${repoUrl} ${repoName}")
                sh("git -C ./${repoName} reset --hard ${gitCommitId}")
            }
            else if(branchName) {
                println "Checking out using branch name for ${repoName}"
                sh("git clone --branch ${branchName} https://${GIT_USERNAME}:${GIT_PASSWORD}@${GIT_DOMAIN}${repoUrl} ${repoName}")
            }
            else {
                error "Both branchName and gitCommitId are null, Either one of them is mandatory"
            }
        }
}