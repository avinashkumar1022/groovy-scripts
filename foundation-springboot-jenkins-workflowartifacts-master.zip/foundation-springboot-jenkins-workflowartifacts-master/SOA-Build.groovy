SUCCESS='\033[1;38;5;35m'; //Green
ERROR='\033[1;31m'; //Red
INFO='\033[38;5;20m'; //Blue

import static groovy.io.FileType.*
import java.text.DecimalFormat

def DeployMDSToUnit() 

{

    stage('Getting Environmental Properties')
    {
        def props= readProperties file: "${EnvPropFile}"
        env.soapass=props['SOASERVER_PASSWORD']
        env.soauser =props['SOASERVER_USERNAME']
    }
    stage('GetDecoded Environment Password')
    {		
        env.soapass=library('Global-Shared-Lib@Branch').sni.common.GetCredential.decryptPassword(env.soapass)	    
    }
				  
	stage ('Deploy MDS to Unit')
    {
	
        def tempPath = sh(script: '#!/bin/sh -e\n'+ "cd ${Unstash_SlaveBuildPath}/${applicationname};find . -type d -name SNIComponents 2>/dev/null", returnStdout: true).split("\r?\n")
        ansiColor('xterm') {echo "${INFO}### MDS Folder Location: ${tempPath} ###"}			
        if (tempPath.toString().length()>2)	{					
        env.Pathop = "${tempPath}".substring(3,("${tempPath}".lastIndexOf("/SNIComponents")))
        ansiColor('xterm') {echo "${INFO}### MDS Folder Name: ${Pathop} ###"}
        pomLoc=env.Unstash_SlaveBuildPath+"/"+env.applicationname+"/"+Pathop
        dir(path:"${pomLoc}")
        {
            sh("cp zip-assembly-descriptor.xml zip-assembly-descriptor.xmlOrig;sed -i 's:apps/SNIComponents:SNIComponents:g' zip-assembly-descriptor.xml")
            sh('#!/bin/sh -e\n'+ "export PATH=$PATH:/usr/java/jdk1.8.0_65/bin \n ${env.Maven_Path}/mvn package  -DPATH=$PATH:/usr/java/jdk1.8.0_65/bin -DserverURL=dummy -Duser=${env.soauser} -Dsoapassword=${env.soapass}")
            sh("mv zip-assembly-descriptor.xmlOrig zip-assembly-descriptor.xml")
        }
        def deployPropfolderloc="${DeployURLPropFile}".substring(0,("${DeployURLPropFile}".lastIndexOf(".properties")))
		env.DeployPropfileloc=deployPropfolderloc+"_"+env.applicationname+".properties"		
		def PropFile = library('Global-Shared-Lib@Branch').sni.common.DeploymentSlaveUtility.CreateDeploymentPropFile(env.NODE_NAME,DeployURLXMLFile,DeployPropfileloc,EnvName)
		pomLoc=env.Unstash_SlaveBuildPath+"/"+env.applicationname+"/"+Pathop
        dir(path:"${pomLoc}")
        {
           
					def capability=env.capability
					def depprops= readProperties file: "${env.DeployPropfileloc}"
                  def propArrayURL=env.EnvName+'.'+capability
                  def arrayurl=depprops["${propArrayURL}"] 
				  String resultStatus = ""                 
                      def count=arrayurl.count(',')		
                      for (int k = 0; k <= count; ++k) 
					      { 
                            def URL=arrayurl.tokenize(',')[k]		                    				
							
                             def scriptDtlOp = sh(script: '#!/bin/sh -e\n'+ "export PATH=$PATH:/usr/java/jdk1.8.0_65/bin \n ${env.Maven_Path}/mvn org.apache.maven.plugins:maven-antrun-plugin:run -DserverURL=${URL} -Duser=${env.soauser} -Dsoapassword=${env.soapass}", returnStdout: true).split("\r?\n")
		  ansiColor('xterm') {echo "${INFO}### Deploy Script Output: ${scriptDtlOp} ###"}
			 if ("${scriptDtlOp}".contains('FAILED')) {
			resultStatus = resultStatus + "${URL} : Deployment Failed" + " , "
			ansiColor('xterm') {echo "${ERROR}### Deployment Failed for MDS to ${URL}. ###"}
			env.Status = "DeploymentFailed"	
			throw new Exception()
		} else {
		resultStatus = resultStatus + "${URL} : Deployment Successful" + " , "
		env.Status = "Deployed"  
		ansiColor('xterm') {echo "${SUCCESS}### Deployment Successful for MDS to ${URL}. ###"}			
		}  
                          }
						 
                     
                  
        }
        sh("rm -rf ${env.DeployPropfileloc}")
     } 
else {
ansiColor('xterm') {echo "${INFO}### No MDS Folder Found To be Deployed ###"}	
}	 
    }

	}
node('master') 
 {
     
  stage ('Checkout') 
   {
    env.projectpath=env.JOB_NAME
    
                

env.Stash_MasterBuildPath=env.WORKSPACE+"/"+env.applicationname
                
                ansiColor('xterm') {echo "${INFO}### Master Stash Path:${env.Stash_MasterBuildPath} ###"}                
                dir(path: "${env.Stash_MasterBuildPath}") 
                 {
                  sh("rm -rf *")
                  sh ("rm -rf .git")
                  checkout([$class: 'GitSCM', branches: [[name: "${gitBranch}"]], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'CleanBeforeCheckout']], submoduleCfg: [], userRemoteConfigs: [[credentialsId: "${GitHubCrdToken}", url: "${giturl}"]]])				  
                def Message=sh(returnStdout: true, script: "git log -1").split("\r?\n")				
          Message=Message.toString()         		  
		  env.CommitID="${Message}".substring(("${Message}".indexOf("[commit "))+8,"${Message}".indexOf(",")).replaceAll("^\\s+","")          
		  echo "CommitID: ${env.CommitID}"
		  env.CommitHash="${env.CommitID}".substring(0,7)
		  echo "CommitHash: ${env.CommitHash}"
		 
				}
   }
   
   stage('Append CommitID in composite.xml'){
            def UpdationStatus = library('Global-Shared-Lib@Branch').sni.xlabs.XLabsCommonUtility.UpdateCommitID(new File(env.Stash_MasterBuildPath),env.CommitID) 
      ansiColor('xterm') {echo "${INFO}Status for appending commitID in composite.xml: ${UpdationStatus}"}
   }
  stage('Replicate Pom File If not present already')             
   {
                def PomAppPath=env.Stash_MasterBuildPath+"/"+env.applicationname
                def pomGenResult = library('Global-Shared-Lib@Branch').sni.soa.SOAXLRSvcPomGenerator.ReplicateXlrSOAPom(PomAppPath)
                ansiColor('xterm') {echo "${INFO}### Dynamic pom file creation Status: ${pomGenResult} ###"}				
                
   }
  stage('Stashing Build in Master')
   {
    dir(path: "${env.Stash_MasterBuildPath}") 
                {                
                stash includes: '**', name: 'BuildResources'        
               }
   }
}

node('uxunt1310') 
 {
  stage ('Unstash Build')
   { 
       echo "node: ${NODE_NAME}"
    env.Unstash_SlaveBuildPath=env.WORKSPACE
    ansiColor('xterm') {echo "${INFO}### Slave Unstash Path:${env.Unstash_SlaveBuildPath} ###"}
    dir(path: "${env.Unstash_SlaveBuildPath}") 
     {      
                 sh("rm -rf ${env.applicationname}")
                 unstash 'BuildResources'
     } 
   }
stage('Copy Config File')
	              {
	              def srcAdfflie=env.ADFPath
	                     def destpath=env.Unstash_SlaveBuildPath+"/"+env.applicationname+"/"+".adf"+"/"+"META-INF"+"/"+"adf-config.xml"
	                     sh (script: "cp ${srcAdfflie} ${destpath}")
	              }
				  if("${env.applicationlocation}".contains("On-Premise/SOA/Snapshot")){
				  
				  DeployMDSToUnit()
				      
				  }

  stage ('Compile') 
   {
   def MDSArchivePath=env.Unstash_SlaveBuildPath+"/"+env.applicationname
                dir(path:"${env.Unstash_SlaveBuildPath}/${env.applicationname}")
                {
				  def strLastRevisionid="${lastrevisionid}"
				  print "strLastRevisionid:"+strLastRevisionid
				  def lastdeployedversion
				  if (strLastRevisionid=="") {
				   lastdeployedversion="5.0"
				  }
				  else
				  {
				   lastdeployedversion=strLastRevisionid.substring((strLastRevisionid.lastIndexOf("/"))+1)
				   lastdeployedversion=lastdeployedversion.substring(0,lastdeployedversion.lastIndexOf("-"))
				   
				  }
				  print "lastdeployedversion:"+lastdeployedversion
				  DecimalFormat form = new DecimalFormat("#.#")
				  env.versionToBeUpd=Double.valueOf(form.format((Double.parseDouble(lastdeployedversion))+0.1))
				  env.versionInManifest=env.versionToBeUpd+"-"+env.CommitHash
                  //env.versionToBeUpd=(Double.parseDouble(lastdeployedversion))+0.1				  
                  ansiColor('xterm') {echo "${INFO}Deployed Revision ${lastdeployedversion}"}
                  ansiColor('xterm') {echo "${INFO}Incremented Revision ${versionToBeUpd}"}  
				  cmd1 = "sed -i 's/DeploymentPackage application=\"applicationloc\" version=\"1.0\"/DeploymentPackage version=\"1.0\" application=\"applicationloc\"/g' deployit-manifest.xml"
			      print cmd1
			      def status1 = sh(cmd1)
				  cmd = "sed -i 's/DeploymentPackage version=\"1.0\"/DeploymentPackage version=\"" +env.versionInManifest+ "\"/g' deployit-manifest.xml"
			      print cmd
			      def status = sh(cmd)			  
                  sh ('#!/bin/sh -e\n '+ "export PATH=$PATH:/usr/java/jdk1.8.0_65/bin \n ${env.Maven_Path}/mvn package -Denv.oracle_home=/opt/oracle/middleware -Dappversion=${versionToBeUpd} -Dapplicationloc=${applicationlocation} -DMDSJARPath=${MDSArchivePath} -Dchecksum=${CommitID}")
                }
   }
                
              
  stage('Package') 
   {
   env.manifestfilepath=env.applicationname+"/"+"deployit-manifest.xml"
   echo "filepath: ${env.manifestfilepath}"
                xldCreatePackage artifactsPath: "", manifestPath: "${manifestfilepath}", darPath: '${applicationname}-${versionToBeUpd}-${CommitHash}.dar' 
                                                                ansiColor('xterm') {echo "${SUCCESS}### Package Created ###"}
   }
   stage('Publish') 
  {  
    xldPublishPackage serverCredentials: 'xldadmin', darPath: '${applicationname}-${versionToBeUpd}-${CommitHash}.dar'
                ansiColor('xterm') {echo "${SUCCESS}### Package Published ###"}
  }
 
 } 
