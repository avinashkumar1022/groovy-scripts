GIT_BASE_URL = "https://vaprd078.schneider.com/schneider/"
GIT_CREDENTIAL = 'eebde66b-39b8-4483-9ba0-7dc8d5d209da'
MVN_CMD = '/var/jenkins_home/tools/hudson.tasks.Maven_MavenInstallation/Default/bin/mvn'
APP_MODEL_REPO = "foundation-springboot-appmodels"
GIT_DOMAIN = "vaprd078.schneider.com/schneider/"
SERVER_INIT_ARTIFACT_ID = "/com/schneider/foundation/server/init/foundation-springboot-server-init/1.1.2/"
SERVER_INIT_TAR_FILE_NAME = "foundation-springboot-server-init-1.1.2"
SERVER_INIT_CONF = "server-init.conf"
APPLICATION_YML = "application.yml"
STOP_SCRIPT = "stop.sh"
START_SCRIPT = "start.sh"
STATUS_SCRIPT = "status.sh"
LATEST_BUILD_VERSION = 'latest-build-version'
DEPLOYED_VERSION = "deployed-versions"
GIT_BRANCH = "git-branch"
VERSION = "version"
CONFIGS = "configs"
TYPE = "type"
JVM_OPTIONS = "jvmOptions"
DEFAULT_JAVA_OPTIONS = "-Xmx200m -Dlogging.config=config/logback.xml"
JAVA_OPTIONS_WITH_APPNAME = "-Dspring.application.name="

APPLICATION_NAME = ApplicationName.trim()
PROMOTE_TO_ENV = PromoteToEnvironment.trim()
GIT_BRANCH_NAME = GitBranchName.trim()
DEPLOY_SERVICES = DeployServices.trim()
VERSIONED_DEPLOYMENT = VersionedDeployment.trim()
MODEL_FILE = APPLICATION_NAME + ".json"
GIT_BRANCH_NODE = "git-${GIT_BRANCH_NAME}"
//default value...to be changed to general support email
GLOBAL_NOTIFY_EMAIL="itnextgenoadevgroup@schneider.com"
//App specific 
NOTIFY_EMAIL=""
node('prd-xebia-build-agent') {

    def repositoriesToDeploy = []
    appGraph = "";

    stage("Load App Model from Git - ${APPLICATION_NAME}") {
         if(APPLICATION_NAME == "") {
            error "Build Parameter - ApplicationName is missing"
        }

        if(PROMOTE_TO_ENV == "") {
            error "Build Parameter - PromoteToEnvironment is missing"
        }

        if(GIT_BRANCH_NAME == "") {
            error "Build Parameter - GitBranchName is missing"
        }

        if(DEPLOY_SERVICES == "") {
            error "Build Parameter - DeployServices is missing"
        }

        if(VERSIONED_DEPLOYMENT == "") {
            error "Build Parameter - VersionedDeployment is missing"
        }
        else if(VERSIONED_DEPLOYMENT.equalsIgnoreCase("Y")){
            if(GIT_BRANCH_NAME.equalsIgnoreCase("master")) {
                error "Versioned Deployment not allowed from master branch, Please create a branch to deploy a new version of the services"
            }
            else if(DEPLOY_SERVICES.equalsIgnoreCase("FORCE_ALL") || DEPLOY_SERVICES.equalsIgnoreCase("MODIFIED_ONLY")) {
                error "Versioned Deployment not allowed for Parameter DEPLOY_SERVICES = ${DEPLOY_SERVICES}, please specify the list of services you would like to deploy as new version"
            }
            else {
                echo "Executing Versioned Deployment for ${DEPLOY_SERVICES}"
            }
        }

        println 'Loading App Model from ' + MODEL_FILE
        gitCheckoutFor(APP_MODEL_REPO, 'master')
        appGraph = readJSON file: APP_MODEL_REPO+'/'+MODEL_FILE
        def notifyEmail = appGraph.notifyEmail;
        println "App model specific notifyEmail= ${notifyEmail}"
        if(notifyEmail == "" || notifyEmail == null) {
            NOTIFY_EMAIL = GLOBAL_NOTIFY_EMAIL
            println "No separate email for this app model so setting to global value ${GLOBAL_NOTIFY_EMAIL}"
        }
        repositoriesToDeploy = getRepositoriesToDeploy(appGraph)
        println "List of Repositories to deploy : " + repositoriesToDeploy
        println "******** Load App Model from Git Successful *********"
    }
    
    stage("Execute Deploy Flow - ${APPLICATION_NAME}") {
        
        def index = 0
        repositoriesToDeploy.each {
            def repoName = repositoriesToDeploy[index]['repoName']
            def latestBuildVersion = repositoriesToDeploy[index]['latestBuildVersion']
            def type = repositoriesToDeploy[index]['type']
            def mountSize = repositoriesToDeploy[index]['mountSize']
            def notifyEmail = repositoriesToDeploy[index]['notifyEmail']

            if(mountSize == "" || mountSize == null) {
                mountSize = "S"
                println "No mountSize defined so setting default value=${mountSize}"
            }

            if(notifyEmail == "" || notifyEmail == null) {
                notifyEmail = NOTIFY_EMAIL
                println "No separate email for service so setting to global ${NOTIFY_EMAIL}"
            }

            if(VERSIONED_DEPLOYMENT.equalsIgnoreCase("Y")) {
                repoName = repoName + "-" + GIT_BRANCH_NAME
            }

            if(latestBuildVersion == "" || latestBuildVersion == null) {
                error "Unable to get the latestBuildVersion for " + repoName + " from ${MODEL_FILE}, Run the AppModel-BuildFlow if you haven't done so"
            }

            def hosts = repositoriesToDeploy[index]['hosts'].split(",")

            if(hosts.size() == 0) {
                error "No hosts defined for " + repoName " from ${MODEL_FILE}"
            }

            def i=0
            hosts.each {
                def host = hosts[i].trim()
                println "Deploying " + repoName + " with version " + latestBuildVersion + " on host - " + host
                node("${host}") {
                    executeDeployFlowFor(repoName, latestBuildVersion, type,mountSize, notifyEmail)
					     
                }
				stage("Run JMeter Testcases"){
         build job: 'Run-JMeter-Tests', parameters: [[$class: 'StringParameterValue', name: 'GitRepositoryName', value: "${repoName}"], [$class: 'StringParameterValue', name: 'GitBranchName', value: "${GIT_BRANCH_NAME}"]] 
 	 }
                i++
            }

            if(VERSIONED_DEPLOYMENT.equalsIgnoreCase("Y")) {
                //Removing the versioned repo Name after deployment
                repoName = repoName.replace("-" + GIT_BRANCH_NAME, "")
            }

            updateAppModel(appGraph, repoName, PROMOTE_TO_ENV, DEPLOYED_VERSION, latestBuildVersion);
            index++
        }
        println '********* Execute Deploy Flow Successful **********' 
    }

	 
     stage("Update App Model to git - ${APPLICATION_NAME}") {
        writeJSON file: APP_MODEL_REPO+'/'+MODEL_FILE, json: appGraph, pretty: 4
        pushToGit(APP_MODEL_REPO, 'master')
        println '********* Update App Model to Git with latest values Successful **********'
    }
}

def executeDeployFlowFor(repoName, latestBuildVersion, type,mountSize, notifyEmail) {
    repoExists = sh(script: "test -d ${DEPLOY_DIR}/${repoName} && echo 'Y' || echo 'N'", returnStdout: true).trim()

    if(type.equalsIgnoreCase("resources")) {
        echo "Executing Resource Deployment for ${repoName}" 

        if(repoExists.equalsIgnoreCase("Y")) {
            xfsBased = sh(script: "test -d /opt/schneider/fs && echo 'N' || echo 'Y'", returnStdout: true).trim()
            if("${xfsBased}".equalsIgnoreCase("Y")) {
                println "Undeploying based on xfs based system... "
                sh "/opt/sni/unix/tools/linux/remove_pquota_dir -d ${DEPLOY_DIR}/${repoName}"
            }
            else {
                currentVolume = sh(script: "readlink -f ${DEPLOY_DIR}/${repoName}", returnStdout: true).trim()
                echo "Removing existing volume ${currentVolume} for ${repoName} "
                sh "rm ${DEPLOY_DIR}/${repoName}"
                sh "rm -rf ${currentVolume}/*"
            }
            deployResourceArtifacts(repoName, latestBuildVersion, mountSize, notifyEmail)
        }
        else {
            deployResourceArtifacts(repoName, latestBuildVersion, mountSize, notifyEmail)
        }
    }
    else {
        if(repoExists.equalsIgnoreCase("Y")) {
            println "Folder ${repoName} already exists ..., so skipping deployment of init scripts and update server configs stages"

            stage("Stop Server - ${repoName}") {
                serviceStatus = sh(script: "${DEPLOY_DIR}/${repoName}/${STATUS_SCRIPT}", returnStatus: true)
            
                if(serviceStatus != 0) {
                    println "Skipping stop.sh because service status is ${serviceStatus}"
                }
                else {
                    executeScript(repoName, "STOP")  
                }
            }

            stage("Deploy Jar - ${repoName}") {
                println "Deploying jar for ${repoName} with version ${latestBuildVersion}"
                deployArtifactFor(repoName, latestBuildVersion)
            }

            stage("Start Server - ${repoName}") {
                executeScript(repoName, "START")
            }
        }
        else {
            println "Folder ${repoName} not available ..., so executing deployment of init scripts and update server configs stages"
        
            stage("Deploy Server Init Scripts - ${repoName}") {
                deployServerInitScripts(repoName,mountSize, notifyEmail)
            } 

            stage("Deploy Jar - ${repoName}") {
                println "Deploying jar for ${repoName} with version ${latestBuildVersion}"
                deployArtifactFor(repoName, latestBuildVersion)
            }

            stage("Update Server Configs - ${repoName}") {
                def configsNode = getInfoFromAppModel(appGraph, repoName, CONFIGS)
                if(configsNode == null) {
                    jvmOptions = DEFAULT_JAVA_OPTIONS
                }
                else {
                    jvmOptions = configsNode[JVM_OPTIONS]
                }
                updateServerConfigs(repoName, jvmOptions)
            }

            stage("Start Server - ${repoName}") {
                executeScript(repoName, "START")
            }
        }
    }
}

def deployResourceArtifacts(repoName, latestBuildVersion, mountSize, notifyEmail) {

    xfsBased = sh(script: "test -d /opt/schneider/fs && echo 'N' || echo 'Y'", returnStdout: true).trim()
    println "Is host xfsBased=${xfsBased}"
    if("${xfsBased}".equalsIgnoreCase("Y"))
    {
        println "Deploying based on xfs based system... "
        sh "/opt/sni/unix/tools/linux/create_pquota_dir -d ${DEPLOY_DIR}/${repoName} -s ${mountSize} -e ${notifyEmail}"
    }
    else if("${SYMLINKS_DEPLOYMENT}".equalsIgnoreCase("Y")) {
        println("SYMLINKS_DEPLOYMENT = ${SYMLINKS_DEPLOYMENT}")
        println "Deploying using symlinks ... "
        availableVolume = getAvailableVolume()
        sh "ln -s ${availableVolume} ${DEPLOY_DIR}/${repoName}"
    }
    else {
        println "Deploying without using symlinks and xfsBased... "
        sh "mkdir -p ${DEPLOY_DIR}/${repoName}"
    }
    deployArtifactFor(repoName, latestBuildVersion)
    sh "unzip ${DEPLOY_DIR}/${repoName}/${repoName}.jar -d ${DEPLOY_DIR}/${repoName}/ -x \"META-INF/*\""
    sh "rm -rf ${DEPLOY_DIR}/${repoName}/${repoName}.jar"
}

def executeScript(repoName, operation) {
    withEnv(['JENKINS_NODE_COOKIE=dontkill']) {
        if(operation.equalsIgnoreCase("START")) {
            // serviceStatus = sh(script: "${DEPLOY_DIR}/${repoName}/${START_SCRIPT}", returnStatus: true)
            // if(serviceStatus == 1) {
            //     echo "${repoName} not started after 50 iterations, ignoring this error"
            // }
            // else {
            //     echo "Started the server successfully - ${repoName}"
            // }
            sh "${DEPLOY_DIR}/${repoName}/${START_SCRIPT}" 
        }
        else if(operation.equalsIgnoreCase("STOP")) {
            sh "${DEPLOY_DIR}/${repoName}/${STOP_SCRIPT}"
            echo "Stopped the server successfully - ${repoName}"
        }
        else if(operation.equalsIgnoreCase("STATUS")) {
            sh "${DEPLOY_DIR}/${repoName}/${STATUS_SCRIPT}"
        }
        else if(operation.equalsIgnoreCase("RESTART")) {
            sh "${DEPLOY_DIR}/${repoName}/${STOP_SCRIPT}"
            // serviceStatus = sh(script: "${DEPLOY_DIR}/${repoName}/${START_SCRIPT}", returnStatus: true)
            // if(serviceStatus == 1) {
            //     echo "${repoName} not started after 50 iterations, ignoring this error"
            // }
            // else {
            //     echo "Started the server successfully - ${repoName}"
            // }
            sh "${DEPLOY_DIR}/${repoName}/${START_SCRIPT}"
        }
        else {
            error "Unknown operation - ${Operation}"
        }
    }
}

def deployArtifactFor(repoName, latestBuildVersion){
    def appVersionSplits = latestBuildVersion.split(':');
    def splitGroupId = appVersionSplits[0].replace('.','/');
    def splitArtifactId = appVersionSplits[1];
    def splitVersionId = appVersionSplits[2];
    def jarFile = splitArtifactId+"-"+splitVersionId + ".jar"

    httpStatusCode = sh(script: "curl -s -o /dev/null -w \"%{http_code}\" -I ${ARCHIVA_URL}/${splitGroupId}/${splitArtifactId}/${splitVersionId}/${jarFile}", returnStdout: true).trim()
    
    if(httpStatusCode.equalsIgnoreCase("200")) {
        echo "Found jar for ${repoName} with version ${latestBuildVersion} in Archiva Repository, deploying ..."
        if(VERSIONED_DEPLOYMENT.equalsIgnoreCase("Y")) {
            sh "curl ${ARCHIVA_URL}/${splitGroupId}/${splitArtifactId}/${splitVersionId}/${jarFile} -o ${DEPLOY_DIR}/${repoName}/${splitArtifactId}-${GIT_BRANCH_NAME}.jar"
        }
        else {
            sh "curl ${ARCHIVA_URL}/${splitGroupId}/${splitArtifactId}/${splitVersionId}/${jarFile} -o ${DEPLOY_DIR}/${repoName}/${splitArtifactId}.jar"
        }
    }
    else {
        error "Unable to find the jar for ${repoName} with version ${latestBuildVersion} in Archiva Repository"
    }
}

def deployServerInitScripts(repoName,mountSize, notifyEmail) {

    xfsBased = sh(script: "test -d /opt/schneider/fs && echo 'N' || echo 'Y'", returnStdout: true).trim()

    println "Is host xfsBased=${xfsBased}"
    if("${xfsBased}".equalsIgnoreCase("Y"))
    {
        println "Deploying based on xfs based system... "
        sh "/opt/sni/unix/tools/linux/create_pquota_dir -d ${DEPLOY_DIR}/${repoName} -s ${mountSize} -e ${notifyEmail}"
    }
    else if("${SYMLINKS_DEPLOYMENT}".equalsIgnoreCase("Y")) {
        println "Deploying using symlinks ... "
        availableVolume = getAvailableVolume()
        if(availableVolume == null || availableVolume == "") {
            error "No free volume available to create a symlink for repository ${repoName}" 
        }
        sh "ln -s ${availableVolume} ${DEPLOY_DIR}/${repoName}"
    } else {
        println "Deploying without symlinks ... "
        sh "mkdir -p ${DEPLOY_DIR}/${repoName}"
    }
    
    sh "curl ${ARCHIVA_URL}/${SERVER_INIT_ARTIFACT_ID}/${SERVER_INIT_TAR_FILE_NAME}.tar.gz -o ${DEPLOY_DIR}/${repoName}/${SERVER_INIT_TAR_FILE_NAME}.tar.gz"
    sh "tar -xvf ${DEPLOY_DIR}/${repoName}/${SERVER_INIT_TAR_FILE_NAME}.tar.gz -C ${DEPLOY_DIR}/${repoName}/"
    sh "chmod -R 0755 ${DEPLOY_DIR}/${repoName}/*"
    sh "rm -rf ${DEPLOY_DIR}/${repoName}/${SERVER_INIT_TAR_FILE_NAME}.tar.gz"
}

def getAvailableVolume() {
    availableVolume = sh(
                    script: "find /opt/schneider/fs -mindepth 1 -maxdepth 1 -type d -exec du -ks {} + | awk '\$1 <= 10' | cut -f 2- | head -n 1",
                    returnStdout: true
                ).trim()
    return availableVolume
}

def updateServerConfigs(repoName, jvmOptions) {
    sh "sed -i 's/{{JAR_FILENAME}}/${repoName}.jar/g' ${DEPLOY_DIR}/${repoName}/${SERVER_INIT_CONF}"
    sh "sed -i 's~{{JAVA_OPTIONS}}~${jvmOptions}~g' ${DEPLOY_DIR}/${repoName}/${SERVER_INIT_CONF}"
    sh "sed -i 's/{{envName}}/${PROMOTE_TO_ENV}/g' ${DEPLOY_DIR}/${repoName}/config/${APPLICATION_YML}"
    sh "sed -i -e 's/\r\$//' ${DEPLOY_DIR}/${repoName}/${START_SCRIPT}"
    sh "sed -i -e 's/\r\$//' ${DEPLOY_DIR}/${repoName}/${STOP_SCRIPT}"
    sh "sed -i -e 's/\r\$//' ${DEPLOY_DIR}/${repoName}/${STATUS_SCRIPT}"
    sh "sed -i -e 's/\r\$//' ${DEPLOY_DIR}/${repoName}/${SERVER_INIT_CONF}"
    if(VERSIONED_DEPLOYMENT.equalsIgnoreCase("Y")) {
        versionedAppName = "${jvmOptions} ${JAVA_OPTIONS_WITH_APPNAME}${repoName}"
        echo "Overriding JAVA_OPTIONS as ${versionedAppName} in ${SERVER_INIT_CONF}"
        sh "sed -i 's~${jvmOptions}~${versionedAppName}~g' ${DEPLOY_DIR}/${repoName}/${SERVER_INIT_CONF}"
    }
}

def getInfoFromAppModel(appGraph, repoName, nodeName) {

    if(VERSIONED_DEPLOYMENT.equalsIgnoreCase("Y")) {
        repoName = repoName.replace("-" + GIT_BRANCH_NAME, "")
    }

    for (int nodePos = 0; nodePos < appGraph.graphs[0].nodes.size(); nodePos++) {
        if (appGraph.graphs[0].nodes[nodePos].id == repoName) {
            if(appGraph.graphs[0].nodes[nodePos][nodeName] == null) {
                echo "Unable to find the ${nodeName} in ${MODEL_FILE} for ${repoName}, ignoring this and continuing deploy flow'"
            }
            jsonNode = appGraph.graphs[0].nodes[nodePos][nodeName];
            break;
        }
     }
     return jsonNode;
}

def updateAppModel(appGraph, repoName, env, attrName, newValue) {
    for (int nodePos = 0; nodePos < appGraph.graphs[0].nodes.size(); nodePos++) {
        if (appGraph.graphs[0].nodes[nodePos].id == repoName) {
            if(appGraph.graphs[0].nodes[nodePos][env][attrName] != null) {
                echo "deployed-versions already exists for ${env}, so updating the existing one"
                deployedVersions = appGraph.graphs[0].nodes[nodePos][env][attrName]
                exists = false
                for(int i=0; i<deployedVersions.size(); i++) {
                    if(deployedVersions[i][GIT_BRANCH] == GIT_BRANCH_NAME) {
                        deployedVersions[i][VERSION] = newValue
                        exists = true
                    }
                }
                if(!exists) {
                    currentVersion = [:]
                    currentVersion.put(GIT_BRANCH, GIT_BRANCH_NAME)
                    currentVersion.put(VERSION, newValue)
                    deployedVersions << currentVersion
                }
            }
            else {
                echo "No deployed-versions exists for ${env}, so creating one"
                deployedVersions = []   
                currentVersion = [:]
                currentVersion.put(GIT_BRANCH, GIT_BRANCH_NAME)
                currentVersion.put(VERSION, newValue)
                deployedVersions << currentVersion
            }
            appGraph.graphs[0].nodes[nodePos][env][attrName] = deployedVersions;
            break;
        }
     }
}

def getRepositoriesToDeploy(appGraph) {
    def pos = 0;
    def repoName = "";
    def repoListToDeploy = []
    def deployServicesList = DEPLOY_SERVICES.split(',').collect { it.trim() }

    appGraph.graphs[0].edges.each {
        
        if (appGraph.graphs[0].edges[pos].source == APPLICATION_NAME) {
            repoName = appGraph.graphs[0].edges[pos].target
            def jsonNode = getInfoFromAppModel(appGraph, repoName, PROMOTE_TO_ENV)
            def gitBranchNode = getInfoFromAppModel(appGraph, repoName, GIT_BRANCH_NODE)
            def typeNode = getInfoFromAppModel(appGraph, repoName, TYPE)

            if(DEPLOY_SERVICES.equalsIgnoreCase("FORCE_ALL")) {
                echo "Deploying All services from ${APPLICATION_NAME}"
                def repoNode = [:]
                repoNode.put('repoName', repoName)
                repoNode.put('latestBuildVersion', gitBranchNode[LATEST_BUILD_VERSION])
                repoNode.put('hosts', jsonNode['hosts'])
                repoNode.put('type', typeNode)
                repoListToDeploy << repoNode
            }
            else if(DEPLOY_SERVICES.equalsIgnoreCase("MODIFIED_ONLY")) {
                echo "Deploying only modified services from ${APPLICATION_NAME}"
                def deployedVersions = jsonNode[DEPLOYED_VERSION]
                existingDeployedVersion = ""
                if(deployedVersions != null) {
                    for(int i=0; i<deployedVersions.size(); i++) {
                        if(deployedVersions[i][GIT_BRANCH] == GIT_BRANCH_NAME) {
                            existingDeployedVersion = deployedVersions[i][VERSION]
                        }
                    }
                }
                
                if ((jsonNode[DEPLOYED_VERSION] == "") || ((gitBranchNode[LATEST_BUILD_VERSION]).equalsIgnoreCase(existingDeployedVersion) == false)) {
                    println 'New build available for ' + repoName + ', so executing deploy flow'
                    def repoNode = [:]
                    repoNode.put('repoName', repoName)
                    repoNode.put('latestBuildVersion', gitBranchNode[LATEST_BUILD_VERSION])
                    repoNode.put('hosts', jsonNode['hosts'])
                    repoNode.put('type', typeNode)
                    repoListToDeploy << repoNode
                } 
                else {
                    println "No Changes, so skipping repourl=" + repoName
                }
            }
            else {
                echo "Deploying only these services = ${DEPLOY_SERVICES}"
                if(deployServicesList.contains(repoName)) {
                    def repoNode = [:]
                    repoNode.put('repoName', repoName)
                    repoNode.put('latestBuildVersion', gitBranchNode[LATEST_BUILD_VERSION])
                    repoNode.put('hosts', jsonNode['hosts'])
                    repoNode.put('type', typeNode)
                    repoListToDeploy << repoNode
                }
            }
        }
        pos++
    }
    return repoListToDeploy
}

def gitCheckoutFor(repoName, branchName) {
    
    withCredentials([
         [$class: 'UsernamePasswordMultiBinding', credentialsId: GIT_CREDENTIAL, usernameVariable: 'GIT_USERNAME', passwordVariable: 'GIT_PASSWORD']
        ]) {
            def repoUrl = repoName + '.git'
            println "Pulling code for repoUrl =" + repoUrl
            sh("rm -rf ${repoName}")
            sh("git clone --branch ${branchName} https://${GIT_USERNAME}:${GIT_PASSWORD}@${GIT_DOMAIN}${repoUrl} ${repoName}")
        }
}

def pushToGit(repoName, branchName) {
    
    def repoUrl = repoName + '.git'
    println 'Pushing to ' + repoUrl
    
    withCredentials([
         [$class: 'UsernamePasswordMultiBinding', credentialsId: GIT_CREDENTIAL, usernameVariable: 'GIT_USERNAME', passwordVariable: 'GIT_PASSWORD']
         ]) {
             sh "ls -ltr"
             sh "pwd"
             sh("git -C ./${repoName} pull https://${GIT_USERNAME}:${GIT_PASSWORD}@${GIT_DOMAIN}${repoUrl} ${branchName}")
             sh("git -C ./${repoName} config user.name 'sni-deployer'")		
             sh("git -C ./${repoName} config user.email 'subramanij@schneider.com'")
             sh("git -C ./${repoName} add ${MODEL_FILE}")
             sh("git -C ./${repoName} diff --quiet --exit-code --cached || git -C ./${repoName} commit -am 'Updated From Jenkins Build Flow ID - .${currentBuild.id} for ${APPLICATION_NAME}'")
             sh("git -C ./${repoName} push https://${GIT_USERNAME}:${GIT_PASSWORD}@${GIT_DOMAIN}${repoUrl} ${branchName}")
        }
}
