# foundation-springboot-jenkins-workflowartifacts
jenkins workflowartifacts for OCP, AKS, NamedHost, APK, EKS Builds

http://itwiki.schneider.com:7777/confluence/display/FNDARCH/10.+Deployment
