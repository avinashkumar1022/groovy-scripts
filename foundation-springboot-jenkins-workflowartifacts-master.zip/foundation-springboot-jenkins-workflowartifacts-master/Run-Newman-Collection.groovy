node('uxunt1310') 
{
    stage ('Checkout') 
    {
        env.projectpath=env.JOB_NAME
        env.BuildPath=env.WORKSPACE
        println "### Build Workspace Path:${env.BuildPath} ###"         
        dir(path: "${env.BuildPath}") 
        {
            sh("rm -rf *")
            checkout([$class: 'GitSCM', branches: [[name: '${gitBranch}']], doGenerateSubmoduleConfigurations: false, extensions: [[$class: 'RelativeTargetDirectory', relativeTargetDir: '$releasename']], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'eebde66b-39b8-4483-9ba0-7dc8d5d209da', url: '${giturl}']]])
        }
    }
    stage ('Run Collections')  
    {
		env.basePath=env.BuildPath+"/"+env.releasename
		env.envjson=env.envname+".json"
        dir(path: "${env.basePath}")
        {
            envFile = sh(script: "find . -name $envjson -print",returnStdout: true).trim()
            def status
            if (envFile == "") {
                println "***** No EnvFile, So running without env json ****"
                status = sh(returnStatus: true, script: "for file in `find . -name collections -type d`/*.json; do newman run --reporters html \$file --insecure --reporter-html-export `find . -name collections -type d`/output/\$(basename \$file json)html; done")
            }
            else {
                println "***** Found EnvFile, So executing newman with env json****"
                status = sh(returnStatus: true, script: "for file in `find . -name collections -type d`/*.json; do newman run -e `find . -name collections -type d`/$envjson --reporters html \$file --insecure --reporter-html-export `find . -name collections -type d`/output/\$(basename \$file json)html; done")
            }            
            
            emailext attachmentsPattern: '**/*.html', body: 'Jenkins Build URL: ${BUILD_URL} \n\nGit Repo: ${giturl} \n\nGit Branch: ${gitbranch} \n\nAttached newman test results as attachments', subject: 'Postman Collection Results for release ${releasename}', to: '${emailids}'
            if (status != 0) {
                currentBuild.result = 'FAILED'
            }    
        }
    }    
}