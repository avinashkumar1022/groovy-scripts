GIT_BASE_URL = "https://vaprd078.schneider.com/schneider/"
GIT_CREDENTIAL = 'eebde66b-39b8-4483-9ba0-7dc8d5d209da'
GIT_DOMAIN = "vaprd078.schneider.com/schneider/"
DOCKER_REGISTRY_URL = "dockerregistryunt1.intra.schneider.com"
DOCKER_REGISTRY_USERNAME = "dockerregistry"
DOCKER_REGISTRY_PASSWORD = "dockerregistry42018"
DEPLOYMENT_ARTIFACTS_REPO = "foundation-deployment-artifacts"
HELM_CHARTS_REPO = "/opt/kubernetes/helm-templates/tile-template"
GIT_REPO_NAME = GitRepositoryName.trim()
GIT_BRANCH_NAME = GitBranchName.trim()
CONTEXT_PATH = ContextPath.trim()

node('uxtst411') {
    stage("Execute Build Job - ${GIT_REPO_NAME}") {  

        if(GIT_REPO_NAME == "") {
            error "Build Parameter - GitRepositoryName is missing"
        }

        if(GIT_BRANCH_NAME == "") {
            error "Build Parameter - GitBranchName is missing"
        }

        if(CONTEXT_PATH == "") {
            error "Build Parameter - ContextPath is missing"
        }

        executeBuildFlowFor(GIT_REPO_NAME, GIT_BRANCH_NAME)
        println '********* Execute Build Job Successful **********'
    }
}

def executeBuildFlowFor (repoName, branchName) {
    
    stage("Git Checkout") {
        println "******** Checking out source code from Git *********"
        gitCheckoutFor(repoName, branchName)
        println "******** Git Checkout Successful *********"
    }

    stage("Build Docker Image") {
        gitCheckoutFor(DEPLOYMENT_ARTIFACTS_REPO, "master")
        sh("cp -r ${repoName} ./${DEPLOYMENT_ARTIFACTS_REPO}/tiles/${CONTEXT_PATH}")
        sh "sed -i 's~{{SERVICE_NAME}}~${CONTEXT_PATH}~g' ./${DEPLOYMENT_ARTIFACTS_REPO}/tiles/Dockerfile"
        sh("docker build -t ${DOCKER_REGISTRY_URL}/${repoName}:latest ./${DEPLOYMENT_ARTIFACTS_REPO}/tiles/")
        println "*********** Build docker image And Publish to registry Successful *************"
    }

    stage("Push to Docker Registry") {
        sh("echo ${DOCKER_REGISTRY_PASSWORD} | docker login ${DOCKER_REGISTRY_URL} --username ${DOCKER_REGISTRY_USERNAME} --password-stdin")
        sh("docker push ${DOCKER_REGISTRY_URL}/${repoName}:latest")
        println "Cleaning up workspace and images..."
        deleteDir()
        sh("docker rmi ${DOCKER_REGISTRY_URL}/${repoName}:latest")
        println "*********** Pushing docker image to registry Successful *************"
    }

     stage("Deploy to Kubernetes") {
        node("uxunt4500") {
            sh("rm -rf ${repoName}-charts")
            sh("cp -r ${HELM_CHARTS_REPO} ${repoName}-charts")
            sh "sed -i 's~{{CHART_NAME}}~${repoName}~g' ./${repoName}-charts/Chart.yaml"
            
            def releaseName = getReleaseNameIfExists("${repoName}-${GIT_BRANCH_NAME}")
            if(releaseName == null || releaseName == "") {
                println "Installing a new release with name ${repoName}-${GIT_BRANCH_NAME}"
                sh("helm install ./${repoName}-charts --name=${repoName}-${GIT_BRANCH_NAME} --namespace sni-frontend --set image.repository=${DOCKER_REGISTRY_URL}/${repoName} --set ingress.path=/${CONTEXT_PATH}")
            }
            else {
                println "Upgrading the existing release - ${repoName}-${GIT_BRANCH_NAME}"
                sh("helm upgrade ${repoName}-${GIT_BRANCH_NAME} ./${repoName}-charts --namespace sni-frontend --set image.repository=${DOCKER_REGISTRY_URL}/${repoName} --set ingress.path=/${CONTEXT_PATH}")
            }   
            // Cleanup older charts directory
            deleteDir()
            println "*********** Deploy to Kubernetes Successful *************"
        }
    }
}

def getReleaseNameIfExists(releaseName) {
     releaseName = sh(
                    script: "helm ls ${releaseName} | cut -f1",
                    returnStdout: true
            ).trim()
    return releaseName
}

def gitCheckoutFor(repoName, branchName) {
    withCredentials([
         [$class: 'UsernamePasswordMultiBinding', credentialsId: GIT_CREDENTIAL, usernameVariable: 'GIT_USERNAME', passwordVariable: 'GIT_PASSWORD']
        ]) {
            def repoUrl = repoName + '.git'
            println "Pulling code for repoUrl =" + repoUrl
            sh("rm -rf ${repoName}")
            sh("git clone --branch ${branchName} https://${GIT_USERNAME}:${GIT_PASSWORD}@${GIT_DOMAIN}${repoUrl} ${repoName}")
        }
}

def getLatestCommitIdFor(repoName, branchName) {
    withCredentials([
         [$class: 'UsernamePasswordMultiBinding', credentialsId: GIT_CREDENTIAL, usernameVariable: 'GIT_USERNAME', passwordVariable: 'GIT_PASSWORD']
         ]) {
            latestGitCommitId = sh(
                    script: "git ls-remote https://${GIT_USERNAME}:${GIT_PASSWORD}@${GIT_DOMAIN}${repoName} ${branchName} | cut -f1",
                    returnStdout: true
            ).trim()
        }
    return latestGitCommitId
}