GIT_BASE_URL = "https://vaprd078.schneider.com/schneider/"
GIT_CREDENTIAL = 'eebde66b-39b8-4483-9ba0-7dc8d5d209da'
GIT_DOMAIN = "vaprd078.schneider.com/schneider/"

GIT_REPO_NAME = GitRepositoryName.trim()
GIT_BRANCH_NAME = GitBranchName.trim()
ENV_NAME = EnvName.trim()

node('uxunt1480') 
{
    stage("Validate Input Parameters") {
        
        if(GIT_REPO_NAME == "") {
            error "Build Parameter - GitRepositoryName is missing"
        }

        if(GIT_BRANCH_NAME == "") {
            error "Build Parameter - GitBranchName is mandatory"
        } 

        if(ENV_NAME == "") {
            error "Build Parameter - EnvName is mandatory"
        } 
    }

    stage ('Code Checkout'){
        gitCheckoutFor(GIT_REPO_NAME, GIT_BRANCH_NAME);
    }

    stage ('Run JMeter Tests')  {
		sh("/export/home/sa_xebiaadm/apache-jmeter-5.1.1/bin/jmeter.sh -n -t ./${GIT_REPO_NAME}/collections/$ENV_NAME/${GIT_REPO_NAME}.jmx -l ${GIT_REPO_NAME}.jtl")
    		
    }    
    stage ('Publish Perf results')  {
		performanceReport parsers: [[$class: 'JMeterParser', glob: "${GIT_REPO_NAME}.jtl"]]
    }
	    stage ('Clean up')  {
		deleteDir()
    }  
}

def gitCheckoutFor(repoName, branchName) {
    withCredentials([
         [$class: 'UsernamePasswordMultiBinding', credentialsId: GIT_CREDENTIAL, usernameVariable: 'GIT_USERNAME', passwordVariable: 'GIT_PASSWORD']
        ]) {
            def repoUrl = repoName + '.git'
            println "Pulling code for repoUrl =" + repoUrl
            sh("rm -rf ${repoName}")
            sh("git clone --branch ${branchName} https://${GIT_USERNAME}:${GIT_PASSWORD}@${GIT_DOMAIN}${repoUrl} ${repoName}")
        }
}
