GIT_CREDENTIAL = 'eebde66b-39b8-4483-9ba0-7dc8d5d209da'
GIT_DOMAIN = "vaprd078.schneider.com/schneider/"
SONAR_URL = "http://uxprd2600.schneider.com:8080/sonarqube"

node("prd-xebia-build-agent") {
	echo commitId
	echo repoName
	echo "Pull request from ${headRef} to ${baseRef}"
    buildUrl = "${BUILD_URL}/console"
    sonarServiceUrl = "${SONAR_URL}/dashboard?id=${repoName}"
    def autoCancelled = false

    def protectedBranchesSeq = "sprint_release, release, master"
    if(baseRef == "sprint_release" || baseRef == "uat_release") {
        protectedBranchesSeq = "${baseRef}, release, master"
    }
    println "protectedBranchesSeq = ${protectedBranchesSeq}"
    branches = protectedBranchesSeq.split(",")
    def baseIndex = branches.findIndexOf { it.trim() == baseRef.toLowerCase() }
    def headIndex = branches.findIndexOf { it.trim() == headRef.toLowerCase() }

        try {
           stage('Validating Pull Request Protected Branches') { 
               if (headIndex < baseIndex) { 
		          echo "success - exexuting all the checks"
		       } else {
                 invokeGithubStatusApi("success", "Skipped", "Jenkins - Check base branch ahead of head branch", buildUrl)
                 invokeGithubStatusApi("success", "Skipped", "Jenkins - Mvn Build & Test", buildUrl)
                 invokeGithubStatusApi("success", "Skipped", "Jenkins - Sonar Quality Gate", sonarServiceUrl)
                 autoCancelled = true
                 echo "skipping pull request verification"
                 error "Aborting the build"
		      }
           }
       } catch (Exception e) {
           if (autoCancelled) {
              currentBuild.result = 'SUCCESS'
               // return here instead of throwing error to keep the build "green"
              return
           }
           throw e
       }

	stage('Gitcheckout') {
        sh("rm -rf ${repoName}")
			withCredentials([
			[$class: 'UsernamePasswordMultiBinding', credentialsId: GIT_CREDENTIAL, usernameVariable: 'GIT_USERNAME', passwordVariable: 'GIT_PASSWORD']
			]) {
				sh("rm -rf ${repoName}")
				sh("git clone https://${GIT_USERNAME}:${GIT_PASSWORD}@${GIT_DOMAIN}${repoName}.git ${repoName}")
				sh("cd ${repoName}; git reset --hard ${commitId}")
				sh("ls -la")
			}
		}

     stage("Check base branch ahead of head branch") {
         println "Protected Branches Seq = ${branches}"
           if(baseIndex >= 0) {
               if(headIndex == baseIndex - 1 ) {
                   for(j=baseIndex; j<branches.size()-1; j++) {
                       base = branches[j+1].trim()
                       head = branches[j].trim()
                       isBranchUptodate = checkBranchAheadOf(base, head)
                       if(!isBranchUptodate) {
                          invokeGithubStatusApi("failure", "Failed - ${base} is not in sync with ${head}", "Jenkins - Check base branch ahead of head branch", buildUrl)
                          error "Failed - ${base} is not in sync with ${head}"
                       }
                   }
                   invokeGithubStatusApi("success", "All branches are uptodate", "Jenkins - Check base branch ahead of head branch", buildUrl)
               } else {
                   invokeGithubStatusApi("failure", "Failed - Unauthorized pull from ${headRef} to ${baseRef}", "Jenkins - Check base branch ahead of head branch", buildUrl)
               }
           } else {
               if(headRef.toLowerCase() == "hotfix") {
                   isBranchUptodate = checkBranchAheadOf("master", "hotfix")
                   if(!isBranchUptodate) {
                      invokeGithubStatusApi("failure", "Failed - master is ahead of hotfix", "Jenkins - Check base branch ahead of head branch", buildUrl)
                      error "Failed - master is ahead of hotfix"
                   }
               } else {
                   invokeGithubStatusApi("success", "Skipped for ${headRef} to ${baseRef}", "Jenkins - Check base branch ahead of head branch", buildUrl)
               }
           }
    }

	try {
    	stage("Maven Build and Unit Test Cases") {
            println "*********** Running maven build and test cases *************"
            executeMvnGoal(repoName, "clean verify test install package")
            invokeGithubStatusApi("success", "Successful", "Jenkins - Mvn Build & Test", buildUrl)
        }
	} catch (Exception e) {
        invokeGithubStatusApi("failure", "Failed, please click on details to see the logs", "Jenkins - Mvn Build & Test", buildUrl)
		throw e
	}
	try {
        stage('Code Coverage') { 
         dir(path: "${repoName}") {
             jacocoExecFilePath = sh(
                    script: "find . -name jacoco*.exec -print",
                    returnStdout: true
            ).trim()

            jacocoXmlPath = sh(
                    script: "find . -name jacoco.xml -print",
                    returnStdout: true
            ).trim()

            println "Jacoco Xml Path = ${jacocoXmlPath}"
            println "Jacoco Exec File Path = ${jacocoExecFilePath}"

            sh "/opt/schneider/sonar-scanner-cli/bin/sonar-scanner -e -Dsonar.projectKey=${repoName} -Dsonar.host.url=${SONAR_URL} -Dsonar.login=bfc9f8d776ff0e8ff1f75121160b853765daf8b1 -Dsonar.language=java -Dsonar.projectBaseDir=$WORKSPACE/${repoName} -Dsonar.java.binaries=. -Dsonar.java.coveragePlugin=jacoco -Dsonar.jacoco.reportPaths=${jacocoExecFilePath} -Dsonar.coverage.jacoco.xmlReportPaths=${jacocoXmlPath} -Dsonar.source=$WORKSPACE/${repoName}/src -Dsonar.sourceEncoding=UTF-8 -Dsonar.exclusions=**/site/**"
            sleep 3
            if(isSonarQualityGatePassed(repoName)) {
                invokeGithubStatusApi("success", "Successful", "Jenkins - Sonar Quality Gate", sonarServiceUrl)
            } else {
                invokeGithubStatusApi("failure", "Failed, Please click on details to see the status ", "Jenkins - Sonar Quality Gate", sonarServiceUrl)
                error "Sonar Quality Gate Check Failed, For more details, Please check here ${sonarServiceUrl}"
            }
         }
     }
    } catch (Exception e) {
        invokeGithubStatusApi("failure", "Failed, Please click on details to see the status ", "Jenkins - Sonar Quality Gate", sonarServiceUrl)
		throw e
    }

    println "Cleaning up workspace ..."
    deleteDir()
}	

def executeMvnGoal(repoName, mvnGoal) {
    withMaven(
        maven: 'M3',
        mavenSettingsConfig: '861beabf-0e69-49b4-bc3c-aa5de0b1eb7e',
        mavenLocalRepo: '.repository'
    ) {
        sh "mvn -f ./${repoName}/pom.xml ${mvnGoal}"
    }
}

def invokeGithubStatusApi(state, description, context, targetUrl) {
    withCredentials([
		[$class: 'UsernamePasswordMultiBinding', credentialsId: GIT_CREDENTIAL, usernameVariable: 'GIT_USERNAME', passwordVariable: 'GIT_PASSWORD']
		]) {
			sh "curl -X POST https://${GIT_USERNAME}:${GIT_PASSWORD}@vaprd078.schneider.com/api/v3/repos/schneider/${repoName}/statuses/${commitId} -H 'Content-Type: application/json' -d '{\"state\": \"${state}\",\"description\": \"${description}\",\"context\": \"${context}\",\"target_url\": \"${targetUrl}\"}'"
		}
}

def checkBranchAheadOf(baseBranchName, headBranchName) {
    def isBranchUptodate = true;
    println "Checking branch ${baseBranchName} is ahead of ${headBranchName}"
    dir(path: "${repoName}") {
            commitDiff = sh (
                script: "git diff origin/${headBranchName}...origin/${baseBranchName}",
                returnStdout: true
            ).trim()
            println commitDiff
            if(commitDiff == "") {
                println "Branch ${baseBranchName} is in sync with ${headBranchName}"
                isBranchUptodate = isBranchUptodate
            }
            else {
                println "Branch ${baseBranchName} is not in sync with ${headBranchName}"
                isBranchUptodate = false
            }
            return isBranchUptodate
        }
}

def isSonarQualityGatePassed(repoName) {
    qualityGateStatusUrl = "${SONAR_URL}/api/project_branches/list?project=${repoName}"
    qualityGateStatusJson = sh (
                script: "curl -X GET ${qualityGateStatusUrl} -H 'Accept: application/json'",
                returnStdout: true
            )
    println "QualityGateJson=${qualityGateStatusJson}" 
    qualityGateStatus = readJSON text: qualityGateStatusJson
    if(qualityGateStatus != null && qualityGateStatus.branches[0].status.qualityGateStatus == "OK") {
        println "Sonar Quality Gate Check Passed"
        return true
    } else {
        return false
    }
}
