GIT_BASE_URL = "https://vaprd078.schneider.com/schneider/"
GIT_CREDENTIAL = 'eebde66b-39b8-4483-9ba0-7dc8d5d209da'
GIT_DOMAIN = "vaprd078.schneider.com/schneider/"
DOCKER_REGISTRY_URL = "dockerregistryunt1.intra.schneider.com"
DOCKER_REGISTRY_USERNAME = "dockerregistry"
DOCKER_REGISTRY_PASSWORD = "dockerregistry42018"
DEPLOYMENT_ARTIFACTS_REPO = "foundation-deployment-artifacts"

WHITE_LISTED_IMAGE_NAMES = "schneider, alpine, ubuntu, centos, linux, scanner, console, gateway, enforcer, sndr, nginx, heap-dump-java-app-new"
WHITE_LISTED_TAGS = "latest"

NAMESPACES = ["unt-oms", "fit-oms", "prd-oms"]

OCP_NONPRD_URL = "https://master.ocpunt.schneider.com:443"
OCP_PRD_URL = "https://master.ocp.schneider.com:443"

node('prd-xebia-build-agent') {

    imagesWithTagsToDelete = [:]
    runningImagesWithTagsAsMap = [:]

    stage("Retrieve Images with Tags running in OCP") {  
        NAMESPACES.each {
            println "Getting list of images on namespace ${it}" 
            if(it.contains("prd")) {
                runningImagesWithTags = getListOfImagesAndTagsFromOCPFor(it, "prd")
            } else {
                runningImagesWithTags = getListOfImagesAndTagsFromOCPFor(it, "non-prd")
            }
            runningImagesWithTags = runningImagesWithTags.split("\n")
            runningImagesWithTags.each {
                if(!it.equalsIgnoreCase("images")) {
                    imageWithTag = it.split(":")
                    def tags = []
                    if(runningImagesWithTagsAsMap[imageWithTag[0].trim()] == null) {
                        tags = tags + imageWithTag[1].trim()
                    }
                    else {
                        tags = runningImagesWithTagsAsMap[imageWithTag[0].trim()]
                        tags = tags + imageWithTag[1].trim()
                    }
                    runningImagesWithTagsAsMap.put(imageWithTag[0].trim(), tags)
                }
            }
        }
        println "List of running images with tags in ${NAMESPACES}"
        println runningImagesWithTagsAsMap
        println '********* Retrieve Images with Tags running in OCP Successful **********'
    }

    stage("Retrieving images with tags to delete") {
        availableRepositoriesJsonString = invokeHttpRequest(DOCKER_REGISTRY_URL, DOCKER_REGISTRY_USERNAME, DOCKER_REGISTRY_PASSWORD, "GET", "v2/_catalog")

        repositoriesJsonObj = readJSON text: availableRepositoriesJsonString
        println "List of repositories from Docker registry "
        println "${repositoriesJsonObj.repositories}"

        repositories = "${repositoriesJsonObj.repositories}".replace("[", "").replace("]", "").replaceAll("\\s","").split(",")

        repositories.each {
            if(WHITE_LISTED_IMAGE_NAMES.contains(it)) {
                println "${it} is in white listed images, so ignoring it" 
            }
            else {
                repositoryTagsJsonString = invokeHttpRequest(DOCKER_REGISTRY_URL, DOCKER_REGISTRY_USERNAME, DOCKER_REGISTRY_PASSWORD, "GET", "v2/${it}/tags/list")
                println "List of tags available for ${it}"
                println repositoryTagsJsonString
                repositoryTagsJsonObj = readJSON text: repositoryTagsJsonString

                runningTags = runningImagesWithTagsAsMap[repositoryTagsJsonObj.name]
                tagsToDelete = []

                repositoryTagsJsonObj.tags.each {
                    markToDeleteFlag = true
                    for(tag in runningTags) {
                         if(it.equalsIgnoreCase(tag) || it.contains(WHITE_LISTED_TAGS)) {
                            println "Ignoring running image in ${repositoryTagsJsonObj.name} with tag ${tag}"
                            markToDeleteFlag = false
                            break
                        }
                    }
                    if(markToDeleteFlag) {
                        tagsToDelete = tagsToDelete + it
                    }
                }
                imagesWithTagsToDelete.put(repositoryTagsJsonObj.name, tagsToDelete);
            }
        }
        println "Docker Images With Tags to Delete"
        println imagesWithTagsToDelete
        println "********* Retrieving images with tags to delete successful **********"
    }

    stage("Deleting the tags in Docker Registry") {
        imagesWithTagsToDelete.each {
            tags = it.value
            if(tags.size() > 0) {
                for(tag in tags) {
                    dockerContentDigest = invokeHttpRequest(DOCKER_REGISTRY_URL, DOCKER_REGISTRY_USERNAME, DOCKER_REGISTRY_PASSWORD, "GET", "v2/${it.key}/manifests/${tag} 2>&1 | grep Docker-Content-Digest | awk '{print (\$3)}'")
                    println "Marking it for garbage collection on ${it.key} = ${dockerContentDigest}"
                    invokeHttpRequest(DOCKER_REGISTRY_URL, DOCKER_REGISTRY_USERNAME, DOCKER_REGISTRY_PASSWORD, "DELETE", "v2/${it.key}/manifests/${dockerContentDigest}")
                }
            }
        }
        println "********** Deleting the tags in Docker Registry successful ************"
    }

     stage("Running Garbage Collection in Docker registry") {
        
        node("uxunt4590") {
             sh("docker exec -i registry registry garbage-collect /nfs_registry/garbage_collector_config.yml")
        }

        println "********** Running Garbage Collection in Docker registry successful ************"
    }
}

def loginWithCredentials(ocpUrl, token, namespace) {
    sh("oc login ${ocpUrl} --token=${token} -n ${namespace}")
}

def getListOfImagesAndTagsFromOCPFor(namespace, env) {
    if(env.equalsIgnoreCase("prd")) {
       withCredentials([string(credentialsId: 'ocp-prd-token', variable: 'OCP_PRD_TOKEN')]) {
            loginWithCredentials(OCP_PRD_URL, OCP_PRD_TOKEN, namespace)
        }
    }
    else {
         withCredentials([string(credentialsId: 'ocp-nonprd-token', variable: 'OCP_NONPRD_TOKEN')]) {
            loginWithCredentials(OCP_NONPRD_URL, OCP_NONPRD_TOKEN, namespace)
        }
    }
    
    runningImagesWithTags = sh(
        script: "oc get deployments -o wide | awk '{print \$8}'",
        returnStdout: true
    ).trim()
    runningImagesWithTags = runningImagesWithTags.replace("${DOCKER_REGISTRY_URL}/", "")
    return runningImagesWithTags
}

def invokeHttpRequest(registryUrl, registryUsername, registryPassword, httpMethod, params) {
        httpResponse = sh(
                    script: "curl -v --silent -u '${registryUsername}:${registryPassword}' -H 'Accept: application/vnd.docker.distribution.manifest.v2+json' -X ${httpMethod} https://${registryUrl}/${params}",
                    returnStdout: true
            ).trim()
    return httpResponse;
}
