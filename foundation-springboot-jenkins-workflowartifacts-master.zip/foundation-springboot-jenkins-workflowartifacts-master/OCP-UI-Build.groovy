GIT_ORG = GitOrgName.trim()

GIT_BASE_URL = "https://vaprd078.schneider.com/"+ GIT_ORG +"/"
GIT_DOMAIN = "vaprd078.schneider.com/"+ GIT_ORG +"/"
GIT_CREDENTIAL = 'eebde66b-39b8-4483-9ba0-7dc8d5d209da'
DOCKER_CONTAINER_REGISTRY_URL = "dockerregistryunt1.intra.schneider.com"
K8S_DEPLOYMENT_YAML = "deployment.yml"
XL_DEPLOYIT_MANIFEST_FILE_NAME = "deployit-manifest.xml"
K8S_ROUTE_YAML = "route.yml"
XLD_FOLDER_PREFIX = "On-Premise/OCP/UI"

DEPLOYMENT_ARTIFACTS_REPO = "foundation-deployment-artifacts"

SONAR_URL = "http://uxprd2600:8080/sonarqube"

REPO_NAME = GitRepoName.trim()
GIT_BRANCH_NAME = GitBranchName.trim()
PROJECT_NAMESPACE = ProjectNamespace.trim()
XLD_FOLDER = XLDFolder.trim()
DeploymentArtifactsRepoBranch = "master"
XLD_RESOURCE_NODE = """<openshift.ResourcesFile name=\"/{{REPO_NAME}}-{{RESOURCE_FOLDER_NAME}}\" file=\"{{RESOURCE_FOLDER_PATH}}\"><tags><value>${PROJECT_NAMESPACE}</value></tags><scanPlaceholders>true</scanPlaceholders><preScannedPlaceholders>true</preScannedPlaceholders><placeholders /><delimiters>{{ }}</delimiters></openshift.ResourcesFile>"""

node('prd-xebia-build-agent') {
    stage("Validations") {  

        if(REPO_NAME == "") {
            error "Build Parameter - GitRepoName is missing"
        }

        if(GIT_BRANCH_NAME == "") {
            error "Build Parameter - GitBranchName is missing"
        }
        if(XLD_FOLDER == "") {
            error "Build Parameter - XLDFolder is missing"
        }
        if(PROJECT_NAMESPACE == "") {
            error "Build Parameter - ProjectNamespace is missing"
        }
        executeBuildFlowFor(REPO_NAME, GIT_BRANCH_NAME)
        println '********* Build Job Successful **********'
    }
}

def executeBuildFlowFor (repoName, branchName) {
    stage("Git Checkout") {
        println "******** Checking out source code from Internal Git *********"
        gitCheckoutFor(repoName, branchName)
        env.gitCommitId = getLatestCommitIdFor(REPO_NAME, GIT_BRANCH_NAME)
        println "******** Internal Git Checkout Successful *********"
    }
	
    stage('Generate Code Coverage Report') {
        try {
            packageJsonFileExists = sh(
                script: "find ./${repoName} -name 'package.json'",
                returnStdout: true
            ).trim()

            if (packageJsonFileExists?.trim()) {       
                sh "cd ${repoName};npm install"
                sh "cd ${repoName};npx eslint -f json -o reports/eslint/report.json ."
                sh "cd ${repoName};npm test -- --watchAll=false --coverage"
            }
        } catch (Exception e) {
            println "********* Tests Failed - Exception Handled ***************"
        }
    }

    stage('Publish Code Coverage') {
        println "********* Publishing Sonarqube Scan Results ***************"
        packageJsonFileExists = sh(
                script: "find ./${repoName} -name 'package.json'",
                returnStdout: true
            ).trim()
        if (packageJsonFileExists?.trim()){    
            sh "cd ${repoName};/opt/schneider/sonar-scanner-cli/bin/sonar-scanner -e -Dsonar.projectKey=${repoName} -Dsonar.host.url=${SONAR_URL} -Dsonar.login=bfc9f8d776ff0e8ff1f75121160b853765daf8b1 -Dsonar.eslint.reportPaths=./reports/eslint/report.json -Dsonar.javascript.lcov.reportPaths=./coverage/lcov.info -Dsonar.sources=src -Dsonar.javascript.file.suffixes=.js,.jsx -Dsonar.sourceEncoding=UTF-8"
        }
    }

    stage("Build & Push Docker Image") {
        println "*********** Building Docker Image *************"
        buildDockerImage(repoName, env.gitCommitId)
        println "*********** Building Docker Image Successful *************"
    
        println "*********** Push Docker Image Container Registry *************"
        pushImage(repoName, env.gitCommitId)
        println "*********** Push Docker Image Container Registry Successful *************"
    }

    stage("Build XL Deploy DAR Package") {        
      
        k8sDeploymentFile = sh(
            script: "find ./${repoName}/k8s -name '${K8S_DEPLOYMENT_YAML}'",
            returnStdout: true
        ).trim()
        k8sRouteFile = sh(
            script: "find ./${repoName}/k8s -name '${K8S_ROUTE_YAML}'",
            returnStdout: true
        ).trim()        
        
        println "${k8sDeploymentFile}"
        println "${k8sRouteFile}"

        // Replace deployment.yml and route.yml files

        sh("sed -i 's~{{IMAGE_VERSION}}~${datetime}-${env.gitCommitId}~g' ${k8sDeploymentFile}");
        sh("sed -i 's~{{NAMESPACE}}~${PROJECT_NAMESPACE}~g' ${k8sRouteFile}");
        sh("sed -i 's~minReadySeconds:[ 0-9]*~minReadySeconds: 10~g' ${k8sDeploymentFile}");          
        
        sh("cp -r ./${repoName}/k8s/* ./${repoName}")

        resourceFiles = sh(
                    script: "find ./${repoName}/k8s/ -name '*.yml' -print",
                    returnStdout: true
            ).trim()

        resourceFiles = resourceFiles.replace("./${repoName}/k8s", "")
        println "************ Resources in k8s Folder ************"
        println "${resourceFiles}"

        xldResourcesNode = generateResourcesOnXLDManifestFile(repoName, resourceFiles)     
        println("************* Generated XLD Resources Node *****************")
        println "${xldResourcesNode}"

        // Copy default deployit-manifest file for XLD and replace

        gitCheckoutFor(DEPLOYMENT_ARTIFACTS_REPO, DeploymentArtifactsRepoBranch)
        echo "Using ${DeploymentArtifactsRepoBranch} branch for ${DEPLOYMENT_ARTIFACTS_REPO}"

        sh "cp ./${DEPLOYMENT_ARTIFACTS_REPO}/xebia/K8S/${XL_DEPLOYIT_MANIFEST_FILE_NAME} ${repoName}/${XL_DEPLOYIT_MANIFEST_FILE_NAME}"

        sh("sed -i 's~{{ARTIFACT_VERSION}}~${env.datetime}-${env.gitCommitId}~g' ${repoName}/${XL_DEPLOYIT_MANIFEST_FILE_NAME}");
        sh("sed -i 's~{{XLD_FOLDER}}~${XLD_FOLDER}~g' ${repoName}/${XL_DEPLOYIT_MANIFEST_FILE_NAME}");
        sh("sed -i 's~{{XLD_FOLDER_PREFIX}}~${XLD_FOLDER_PREFIX}~g' ${repoName}/${XL_DEPLOYIT_MANIFEST_FILE_NAME}");

        if(XLD_FOLDER.equalsIgnoreCase("Snapshots")) {
            sh("sed -i 's~{{REPO_NAME}}~${repoName}-snapshot~g' ${repoName}/${XL_DEPLOYIT_MANIFEST_FILE_NAME}");
        }
        else {
            sh("sed -i 's~{{REPO_NAME}}~${repoName}~g' ${repoName}/${XL_DEPLOYIT_MANIFEST_FILE_NAME}");
        }

        sh("sed -i 's~{{XLD_RESOURCES_NODES}}~${xldResourcesNode}~g' ${repoName}/${XL_DEPLOYIT_MANIFEST_FILE_NAME}");

        xldCreatePackage artifactsPath: "", manifestPath: "${repoName}/${XL_DEPLOYIT_MANIFEST_FILE_NAME}", darPath: "${repoName}/${repoName}-${gitCommitId}.dar" 
        println "### Build XL Deploy DAR Package Successful ###";
    }

    stage('XL Deploy Publish') {  
        xldPublishPackage serverCredentials: 'XldCreds', darPath: "${repoName}/${repoName}-${gitCommitId}.dar"
        println "Cleaning up workspace ..."
        dir(path: "${repoName}") {
            deleteDir()
        }
        println "### XL Deploy Publish Successful ###"
    }

}

def gitCheckoutFor(repoName, branchName) {
    withCredentials([
         [$class: 'UsernamePasswordMultiBinding', credentialsId: GIT_CREDENTIAL, usernameVariable: 'GIT_USERNAME', passwordVariable: 'GIT_PASSWORD']
        ]) {
            def repoUrl = repoName + '.git'
            println "Pulling code for repoUrl =" + repoUrl
            sh("rm -rf ${repoName}")
            if(repoName.equalsIgnoreCase("foundation-deployment-artifacts")) {
                sh("git clone --branch ${branchName} https://${GIT_USERNAME}:${GIT_PASSWORD}@vaprd078.schneider.com/schneider/${repoUrl} ${repoName}")
            }
            else {
                sh("git clone --branch ${branchName} https://${GIT_USERNAME}:${GIT_PASSWORD}@${GIT_DOMAIN}${repoUrl} ${repoName}")
            }
        }
}

def buildDockerImage(repoName, gitCommitId){
    env.datetime = new Date().format( 'yyyyMMddHHmmssSSS' )
    sh("docker build -t ${DOCKER_CONTAINER_REGISTRY_URL}/${repoName}:${datetime}-${gitCommitId} -t ${DOCKER_CONTAINER_REGISTRY_URL}/${repoName}:latest ./${repoName}")
}

def pushImage(repoName, gitCommitId){
    withCredentials([
        [$class: 'UsernamePasswordMultiBinding', credentialsId: 'snidockerinternal', usernameVariable: 'DOCKER_CONTAINER_REGISTRY_USERNAME', passwordVariable: 'DOCKER_CONTAINER_REGISTRY_PASSWORD']
        ]) {
            sh("docker login ${DOCKER_CONTAINER_REGISTRY_URL} -u ${DOCKER_CONTAINER_REGISTRY_USERNAME} -p ${DOCKER_CONTAINER_REGISTRY_PASSWORD}")
            sh("docker push ${DOCKER_CONTAINER_REGISTRY_URL}/${repoName}:${datetime}-${gitCommitId}")
            sh("docker push ${DOCKER_CONTAINER_REGISTRY_URL}/${repoName}:latest")
            sh("docker rmi ${DOCKER_CONTAINER_REGISTRY_URL}/${repoName}:${datetime}-${gitCommitId}")
            sh("docker rmi ${DOCKER_CONTAINER_REGISTRY_URL}/${repoName}:latest")
        }
}

def getLatestCommitIdFor(repoName, branchName) {
    withCredentials([
         [$class: 'UsernamePasswordMultiBinding', credentialsId: GIT_CREDENTIAL, usernameVariable: 'GIT_USERNAME', passwordVariable: 'GIT_PASSWORD']
         ]) {
            latestGitCommitId = sh(
                    script: "git ls-remote https://${GIT_USERNAME}:${GIT_PASSWORD}@${GIT_DOMAIN}${repoName} ${branchName} | cut -f1",
                    returnStdout: true
            ).trim()
        }
    return latestGitCommitId.substring(0,7)
}

def generateResourcesOnXLDManifestFile(repoName, resourceFiles) {
    def xldResourcesNode = "";
    ymlFiles = resourceFiles.split('\n');

    def resourceNames = ["configmap", "secret", "deployment", "service", "route"]
    def order = 1
    
    for(int index=0; index < resourceNames.size(); index++) {
        ymlFiles.each() {
            if(it) {
                if(it.contains(resourceNames[index])) {
                    resourceNode = "${XLD_RESOURCE_NODE}";
                    resourceNode = resourceNode.replace("{{RESOURCE_FOLDER_PATH}}", repoName+"/"+it);
                    resourceNode = resourceNode.replace("{{REPO_NAME}}", order + "-" + repoName);
                    println "Updating resource file name for ${resourceNames[index]} = " + it.contains(resourceNames[index])
                    resourceNode = resourceNode.replace("{{RESOURCE_FOLDER_NAME}}", it.split("/")[2]);
                    order++
                    xldResourcesNode = xldResourcesNode + resourceNode;
                }
            }
            else {
                error "Unable to retrieve the Yml files inside k8s folder for ${repoName}";
            }
        }
    }
    return xldResourcesNode;
}
