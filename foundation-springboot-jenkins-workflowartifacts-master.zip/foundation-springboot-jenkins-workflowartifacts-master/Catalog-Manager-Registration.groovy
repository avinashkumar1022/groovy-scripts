SERVICE_NAME = ServiceName.trim().toLowerCase()
DEPLOY_TO_ENV = DeployToEnv.trim().toLowerCase()

CATALOG_MANAGER_RESOURCE_PATH = "/entserv/ctlgmgr/resources/v1/"

node('prd-xebia-build-agent') {
    stage("Validate Input Parameters") {  
        if(SERVICE_NAME == "") {
            error "Build Parameter - ServiceName is missing"
        }

        if(DEPLOY_TO_ENV == "") {
            error "Build Parameter - DeployToEnv is missing"
        }

        println SERVICE_NAME
        println DEPLOY_TO_ENV
    }

    stage("Catalog Manager Registration") {
        accessToken = getJWTToken(DeployToEnv)
        if(accessToken) {
            println "Successfully retrieved the token for ${DEPLOY_TO_ENV}"
            if(isServiceUrlExists(accessToken)) {
                println "Catalog Manager serviceBind=${SERVICE_NAME} already exists, so skipping the next steps"
            } else {
                println "Registering the serviceName=${SERVICE_NAME} in Catalog Manager"
                baseUrlId = getBaseUrlId(accessToken)
                if(!baseUrlId) {
                    println "BaseUrlId = ${baseUrlId}"
                    baseUrlResponseJson = createBaseUrlEntry(accessToken)
                    if(baseUrlResponseJson['status'].equalsIgnoreCase("success")) {
                        sleep 5
                        baseUrlId = getBaseUrlId(accessToken)
                    } else {
                        error "Unable to create Base Url, REST API call failed ..."
                    }
                }

                if(baseUrlId) {
                    servicesResponseJson = createCatalogManagerServicesEntry(baseUrlId, accessToken)
                    if(servicesResponseJson['status'].equalsIgnoreCase("success")) {
                        println "Successfully created the service url in catalog manager"
                    } else {
                        error "Unable to create the service url ${servicesUrl} with baseUrlId = ${baseUrlId} in catalog manager"
                    }
                } else {
                    error "Unable to get the baseUrlId for ${SERVICE_NAME} in ${DEPLOY_TO_ENV}"
                }
            }
        } else {
            error "Unable to retrive the token for ${DEPLOY_TO_ENV}"
        }
    }
}

def createCatalogManagerServicesEntry(baseUrlId, accessToken) {
    servicesUrl = getBaseUrlForCatalogManagerAPI() + CATALOG_MANAGER_RESOURCE_PATH + "services"

    payload = "'{\"serviceName\": \"${SERVICE_NAME}\", \"serviceDesc\": \"${SERVICE_NAME} - Created via jenkins pipeline\", \"serviceBind\": \"${SERVICE_NAME}\", \"baseUrlId\": \"${baseUrlId}\", \"serviceUrl\": \"/v1\", \"owner\": \"OA\", \"isActive\": \"Y\" }'"
    servicesResponse = invokeHttpRequest("POST", servicesUrl, payload, accessToken)
    println servicesResponse
    servicesResponseJson = readJSON text: servicesResponse
    return servicesResponseJson
}

def createBaseUrlEntry(accessToken) {
    baseUrl = getBaseUrlForCatalogManagerAPI() + CATALOG_MANAGER_RESOURCE_PATH + "baseurls"
    payloadServiceUrl = "https://${SERVICE_NAME}-${DEPLOY_TO_ENV}-oms.apps.ocpunt.schneider.com"
	if(DEPLOY_TO_ENV.equalsIgnoreCase("prd")) {
        payloadServiceUrl = payloadServiceUrl.replace("ocpunt", "ocp")
    }
    payload = "'{\"baseUrl\": \"${payloadServiceUrl}\", \"isActive\": \"Y\"}'"
    baseUrlResponse = invokeHttpRequest("POST", baseUrl, payload, accessToken)
    println baseUrlResponse
    baseUrlResponseJson = readJSON text: baseUrlResponse
    return baseUrlResponseJson
}

def isServiceUrlExists(accessToken) {
    servicesUrl =  getBaseUrlForCatalogManagerAPI() + CATALOG_MANAGER_RESOURCE_PATH + "services?serviceBind=${SERVICE_NAME}"
    servicesResponse = invokeHttpRequest("GET", servicesUrl, '', accessToken)
    servicesResponseJson = readJSON text: servicesResponse
    println "${servicesResponseJson}"
    println "Size of servicesResponseJson = " + servicesResponseJson['payload'].size()
    if(servicesResponseJson['payload'].size() > 0) { 
        return true
    } else {
        return false
    }
}

def invokeHttpRequest(httpMethod, url, payload, accessToken) {
    httpResponse = sh(
                script: "curl -v --silent -d ${payload} -H 'Accept: application/json' -H 'Content-Type: application/json' -H 'Authorization: Bearer ${accessToken}' -H 'Accept-Encoding: gzip'  -X ${httpMethod} ${url} | gunzip -",
                returnStdout: true
            ).trim()
    return httpResponse;
}

def getBaseUrlId(accessToken) {
    def baseUrlId = ""
    def baseUrlValue = "https://${SERVICE_NAME}-${DEPLOY_TO_ENV}-oms.apps.ocpunt.schneider.com"
	if(DEPLOY_TO_ENV.equalsIgnoreCase("prd")) {
        baseUrlValue = baseUrlValue.replace("ocpunt", "ocp")
    }
    response = invokeHttpRequest("GET", getBaseUrlForCatalogManagerAPI() + CATALOG_MANAGER_RESOURCE_PATH + "baseurls", '', accessToken)
    println response  
    responseJson = readJSON text: response

    println "Getting BaseUrlId for ${baseUrlValue}"
    responseJson.payload.each {
        if((it.baseUrl).equalsIgnoreCase(baseUrlValue)) {
            baseUrlId = it.baseUrlId
        }
    }
    return baseUrlId
}

def getBaseUrlForCatalogManagerAPI() {
    def baseUrl = "https://services${DEPLOY_TO_ENV}3.intra.schneider.com"
    if(DEPLOY_TO_ENV.equalsIgnoreCase("prd")) {
        baseUrl = baseUrl.replace("prd", "")
    }
    return baseUrl
}

def getJWTToken(env) {
    def accessToken = ""
    oAuthTokenUrl = "https://oauth2${DEPLOY_TO_ENV}.schneider.com/f5-oauth2/v1/token"
    if(env.equalsIgnoreCase("fit")) {
        oAuthTokenUrl = oAuthTokenUrl.replace("fit", "uat")
    } else if(env.equalsIgnoreCase("prd")) {
        oAuthTokenUrl = oAuthTokenUrl.replace("prd", "")
    }

    withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId:"sa_freighteval_${env}", usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD']]) {
        withCredentials([[$class: 'UsernamePasswordMultiBinding', credentialsId:"F5_OAuth2_creds_${env}", usernameVariable: 'CLIENT_ID', passwordVariable: 'CLIENT_SECRET']]) {
            payload = "\"grant_type=password&username=${USERNAME}&password=${PASSWORD}&scope=&client_id=${CLIENT_ID}&client_secret=${CLIENT_SECRET}\""
			httpResponse = sh(
                    script: "curl -v --silent -d ${payload} -H 'Accept: application/json' -H 'Content-Type: text/plain' -X POST ${oAuthTokenUrl}",
                    returnStdout: true
            ).trim()
            jwtTokenJson = readJSON text: httpResponse
            accessToken = jwtTokenJson['access_token']
        } 
    } 
    return accessToken        
}