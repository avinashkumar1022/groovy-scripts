appName=''
branch=''
envName=''
valid=false
BASE_GIT_URL="https://vaprd078.schneider.com/schneider/"
appModelRepoName='foundation-springboot-appmodels'
APP_MODELS_URL="vaprd078.schneider.com/schneider/"+appModelRepoName+"/"
GIT_URL="vaprd078.schneider.com/schneider/"
appModel=null

stage('Input Validation')
{
	validateInput()
	println "Application name: " + appName
	println "Branch name: " + branchName
	println "Environment name: " + envName
}

stage('Environment Validation')
{
	validateEnvironment()
}

node('prd-xebia-build-agent') {
	println "On master"
	println "App model: " + appModel
	def repoName = appModel.repository
	appModel.envs.each {
		environment ->
			println environment.name
			if(environment.name == envName)
			{
				println "Deploying to ${envName}"

				def destDir = environment.destdir.replaceAll("/+\$","")
				println "Repository name: ${repoName}"
				println "Repository name: ${destDir}"
				stage('Deployment'){

					environment.hosts.each{
						host ->
						println "Deploying to $host"
						node("${host}")
						{
							shlog=sh returnStdout: true, script: 
							"""
							set -x
							echo "Check if ${repoName} exists"
							if [ -d "${repoName}" ]; then 
							rm -rf "${repoName}"; 
							fi
							"""
							println shlog
							withCredentials([usernamePassword(credentialsId: 'snibadm', passwordVariable: 'password', usernameVariable: 'username')]) {
								sh "git -c http.sslVerify=false clone --branch ${branchName} https://${username}:${password}@${GIT_URL}${repoName}"
							}
							copyFiles(repoName, destDir)
						}
						
					}
				}
			}
		}

}

def copyFiles(repoName, destDir)
{
def shlog = sh returnStdout: true, script:  """#!/bin/bash
bash
set -x
echo "\$0"
echo "${destDir}"
echo "${repoName}"
ls -lart "${repoName}"
if [ -d ${destDir} ]; then
	echo "Deleting old backup folders.."
	rm -rf ${destDir}/backup_20*
	if [ -d ${destDir}/backup ]; then
		echo "Move existing backup directory..."
		mv ${destDir}/backup ${destDir}/backup_`date +"%Y%m%d%H%M%s"`
	fi
	echo "Create new backup directory..."
	mkdir ${destDir}/backup
else
	#Deploy path needs to be manually created
	echo "${destDir} does not exist, needs to be created first"
	exit -1
fi
echo "Backing up existing files..."
toIgnorePattern="backup"
echo "Ignoring \$toIgnorePattern..."
for file in `ls ${destDir}`
do
echo File: "\$file"
if [ -d "${destDir}/\$file" ]; then
if [[ ! \$file == \$toIgnorePattern* ]]; then
echo "Backing up directory: ${destDir}/\$file"
cp -r ${destDir}/\$file "${destDir}/backup/"
fi
elif [ -f "${destDir}/\$file" ]; then
echo "Backing up file: \$file"
cp ${destDir}/\$file "${destDir}/backup"
fi
done
echo "cp -r ${repoName}/* ${destDir}/"
cp -r ${repoName}/* ${destDir}/
rm -rf ${repoName}
"""
println shlog
}

def validateInput()
{
	println "Validating inputs"
	if(ApplicationName == "" || BranchName == "" || EnvironmentName == "")
	{
		throw new Exception("ApplicationName, BranchName and EnvironmentName cannot be empty!!")
	}
	else
	{
		appName = params.ApplicationName
		branchName = params.BranchName
		envName = params.EnvironmentName
	}
}

def validateEnvironment()
{
	node('prd-xebia-build-agent')
	{
		sh  "echo Current directory: " + pwd()
		sh "if [ -d ${appModelRepoName} ]; then rm -rf ${appModelRepoName}; fi"
		println "Fetching app model from Git..."
		withCredentials([usernamePassword(credentialsId: 'snibadm', passwordVariable: 'password', usernameVariable: 'userName')]) {
			sh "echo Username: ${userName}"
			sh "git clone https://${userName}:${password}@${APP_MODELS_URL}"
		}
		appModel = readJSON file: appModelRepoName+'/'+appName+'.json'
		println appModel
		envNames=appModel.envNames
		branchNames=appModel.branchNames
		println "Validating branch and environment against the input..."
		Integer branchIndex = branchNames.findIndexOf{it == branchName}
		Integer envIndex = envNames.findIndexOf{it == envName}
		println "Branch: " + branchIndex + ",  environment: " + envIndex
		if(branchIndex >= 0 && envIndex >= 0)
		{
			println "Branch and environment are known..."
			println "Branch: " + branchIndex + ",  environment: " + envIndex
			if(branchIndex >= envIndex)
			{
				println "Branch " + branchName + " can be deployed to " + envName + "..."
			}
			else
			{
				throw new Exception("Branch " + branchName + " cannot be deployed to " + envName + "!!!")
			}
		}
		else
		{
			throw new Exception("Branch or environment supplied not present in app model!!")
		}
	}
}
