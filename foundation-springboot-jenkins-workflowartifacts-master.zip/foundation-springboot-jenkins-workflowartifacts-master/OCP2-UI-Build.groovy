GIT_ORG = GitOrgName.trim()

GIT_BASE_URL = "https://vaprd078.schneider.com/"+ GIT_ORG +"/"
GIT_DOMAIN = "vaprd078.schneider.com/"+ GIT_ORG +"/"
GIT_CREDENTIAL = 'eebde66b-39b8-4483-9ba0-7dc8d5d209da'

NEXUS_DOCKER_REGISTRY_URL = "sonatypenexus.schneider.com:21443"

DEPLOYMENT_YAML_PATH = "k8s-4.3/deployment/deployment.yml"
K8S_ROUTE_YAML = "route.yml"
K8S_DEPLOYMENT_YAML = "deployment.yml"
XL_DEPLOYIT_MANIFEST_FILE_NAME = "deployit-manifest.xml"

XLD_FOLDER_PREFIX = "On-Premise/OCP2/UI"

DEPLOYMENT_ARTIFACTS_REPO = "foundation-deployment-artifacts"

SONAR_URL = "http://uxprd2600:8080/sonarqube"

REPO_NAME = GitRepoName.trim()
GIT_BRANCH_NAME = GitBranchName.trim()
PROJECT_NAMESPACE = ProjectNamespace.trim()
XLD_FOLDER = XLDFolder.trim()
nexusFolder = NexusFolder.trim()
DeploymentArtifactsRepoBranch = "master"

XLD_RESOURCE_NODE = """<openshift.ResourcesFile name=\"/{{REPO_NAME}}-{{RESOURCE_FOLDER_NAME}}\" file=\"{{RESOURCE_FOLDER_PATH}}\"><tags><value>${PROJECT_NAMESPACE}-ocp2</value></tags><scanPlaceholders>true</scanPlaceholders><preScannedPlaceholders>true</preScannedPlaceholders><placeholders /><delimiters>{{ }}</delimiters></openshift.ResourcesFile>"""

node('prd-xebia-build-agent') {
    stage("Validations") {  

        if(REPO_NAME == "") {
            error "Build Parameter - GitRepoName is missing"
        }

        if(GIT_BRANCH_NAME == "") {
            error "Build Parameter - GitBranchName is missing"
        }
        if(XLD_FOLDER == "") {
            error "Build Parameter - XLDFolder is missing"
        }
        if(PROJECT_NAMESPACE == "") {
            error "Build Parameter - ProjectNamespace is missing"
        }
        if(nexusFolder == "") {
            error "Build Parameter - NexusFolder is missing"
        }

        executeBuildFlowFor(REPO_NAME, GIT_BRANCH_NAME)
        println '********* Build Job Successful **********'
    }
}

def executeBuildFlowFor (repoName, branchName) {
    stage("Git Checkout") {
        println "******** Checking out source code from Internal Git *********"
        gitCheckoutFor(repoName, branchName)
        env.gitCommitId = getLatestCommitIdFor(REPO_NAME, GIT_BRANCH_NAME)
        println "******** Internal Git Checkout Successful *********"
    }
	
    stage('Generate Code Coverage Report') {
        try {
            packageJsonFileExists = sh(
                script: "find ./${repoName} -name 'package.json'",
                returnStdout: true
            ).trim()

            if (packageJsonFileExists?.trim()) {       
                sh "cd ${repoName};npm install"
                sh "cd ${repoName};npx eslint -f json -o reports/eslint/report.json ."
                sh "cd ${repoName};npm test -- --watchAll=false --coverage"
            }
        } catch (Exception e) {
            println "********* Tests Failed - Exception Handled ***************"
        }
    }

    stage('Publish Code Coverage') {
        println "********* Publishing Sonarqube Scan Results ***************"
        packageJsonFileExists = sh(
                script: "find ./${repoName} -name 'package.json'",
                returnStdout: true
            ).trim()
        if (packageJsonFileExists?.trim()){    
            sh "cd ${repoName};/opt/schneider/sonar-scanner-cli/bin/sonar-scanner -e -Dsonar.projectKey=${repoName} -Dsonar.host.url=${SONAR_URL} -Dsonar.login=bfc9f8d776ff0e8ff1f75121160b853765daf8b1 -Dsonar.eslint.reportPaths=./reports/eslint/report.json -Dsonar.javascript.lcov.reportPaths=./coverage/lcov.info -Dsonar.sources=src -Dsonar.javascript.file.suffixes=.js,.jsx -Dsonar.sourceEncoding=UTF-8"
        }
    }

	stage('Nexus IQ Policy Evaluation') {	
		def policyEvaluationResult=nexusPolicyEvaluation advancedProperties: '', failBuildOnNetworkError: false, iqApplication: manualApplication("${repoName}"), iqScanPatterns: [[scanPattern: '**/*.js'], [scanPattern: '**/*.ts']], iqStage: 'build', jobCredentialsId: 'nexus_iq_scan'
		currentBuild.rawBuild.@result = hudson.model.Result.SUCCESS
	}

    stage("Push Github Topics as Pod Labels") {
        def topicsJson = readJSON text: getRepoTopics(repoName)
        println "Topics For ${repoName} = ${topicsJson.names}"

        def supportESNum = ""
        def supportServerity = ""

        topicsJson.names.each() {
            if(it.contains("support")) {
                 if(it.contains("support-level")) {
                     supportServerity = it.split("-")[2]
                 } else {
                     supportESNum = it.split("-")[1]
                 }
            }
            if(it.contains("testing")) {
                DeploymentArtifactsRepoBranch = "testing"
            }
        }

        if(supportESNum == "") {
            println "Unable to find the support-* from git topics for repository=${repoName}"
        } else {
            println "Found support topics - supportESNum=${supportESNum}"
            updateYaml("${repoName}/${DEPLOYMENT_YAML_PATH}", "EventScenario", supportESNum.toUpperCase())
        }
        
        if(supportServerity == "") {
            println "Unable to find the support-level-<severity>* from git topics for repository=${repoName}"
        } else {
            println "Found support topics - supportServerity=${supportServerity}"
            updateYaml("${repoName}/${DEPLOYMENT_YAML_PATH}", "SupportLevel", supportServerity)
        }
     }

    stage("Build Docker Image") {
        println "*********** Bulding Docker Image *************"
        buildDockerImage(repoName, env.gitCommitId, nexusFolder)
        println "*********** Bulding Docker Image Successful *************"
    }

     stage("Aqua Scan Docker Image") {
        aqua locationType: 'local', localImage: "${NEXUS_DOCKER_REGISTRY_URL}/${nexusFolder}/${repoName}:${env.datetime}-${env.gitCommitId}", onDisallowed: 'pass', notCompliesCmd: '', policies: 'Default', register: false, registry: 'Docker UAT', showNegligible: false
        println "*********** Aqua scan successful *************"
    }

    stage("Publish Docker Image") {
        println "*********** Push Docker Image Container Registry *************"
        pushImageToNexus(repoName, env.gitCommitId, nexusFolder)
        println "*********** Push Docker Image Container Registry Successful *************"
    }

    stage("Build XL Deploy DAR Package") {        

        
        k8sDeploymentFile = sh(
            script: "find ./${repoName}/k8s-4.3 -name '${K8S_DEPLOYMENT_YAML}'",
            returnStdout: true
        ).trim()
        k8sRouteFile = sh(
            script: "find ./${repoName}/k8s-4.3 -name '${K8S_ROUTE_YAML}'",
            returnStdout: true
        ).trim()        
        
        println "${k8sDeploymentFile}"
        println "${k8sRouteFile}"

        // Replace deployment.yml and route.yml files

        sh("sed -i 's~{{IMAGE_VERSION}}~${datetime}-${env.gitCommitId}~g' ${k8sDeploymentFile}");
        sh("sed -i 's~{{NAMESPACE}}~${PROJECT_NAMESPACE}~g' ${k8sRouteFile}");
        sh("sed -i 's~minReadySeconds:[ 0-9]*~minReadySeconds: 10~g' ${k8sDeploymentFile}");          
        
        sh("cp -r ./${repoName}/k8s-4.3/* ./${repoName}")

        resourceFiles = sh(
                    script: "find ./${repoName}/k8s-4.3/ -name '*.yml' -print",
                    returnStdout: true
            ).trim()

        resourceFiles = resourceFiles.replace("./${repoName}/k8s-4.3", "")
        println "************ Resources in k8s-4.3 Folder ************"
        println "${resourceFiles}"

        xldResourcesNode = generateResourcesOnXLDManifestFile(repoName, resourceFiles)     
        println("************* Generated XLD Resources Node *****************")
        println "${xldResourcesNode}"

        // Copy default deployit-manifest file for XLD and replace

        gitCheckoutFor(DEPLOYMENT_ARTIFACTS_REPO, DeploymentArtifactsRepoBranch)
        echo "Using ${DeploymentArtifactsRepoBranch} branch for ${DEPLOYMENT_ARTIFACTS_REPO}"

        sh "cp ./${DEPLOYMENT_ARTIFACTS_REPO}/xebia/K8S/${XL_DEPLOYIT_MANIFEST_FILE_NAME} ${repoName}/${XL_DEPLOYIT_MANIFEST_FILE_NAME}"

        sh("sed -i 's~{{ARTIFACT_VERSION}}~${env.datetime}-${env.gitCommitId}~g' ${repoName}/${XL_DEPLOYIT_MANIFEST_FILE_NAME}");
        sh("sed -i 's~{{XLD_FOLDER}}~${XLD_FOLDER}~g' ${repoName}/${XL_DEPLOYIT_MANIFEST_FILE_NAME}");
        sh("sed -i 's~{{XLD_FOLDER_PREFIX}}~${XLD_FOLDER_PREFIX}~g' ${repoName}/${XL_DEPLOYIT_MANIFEST_FILE_NAME}");

        if(XLD_FOLDER.equalsIgnoreCase("Snapshots")) {
            sh("sed -i 's~{{REPO_NAME}}~${repoName}-snapshot-ocp2~g' ${repoName}/${XL_DEPLOYIT_MANIFEST_FILE_NAME}");
        }
        else {
            sh("sed -i 's~{{REPO_NAME}}~${repoName}-ocp2~g' ${repoName}/${XL_DEPLOYIT_MANIFEST_FILE_NAME}");
        }

        sh("sed -i 's~{{XLD_RESOURCES_NODES}}~${xldResourcesNode}~g' ${repoName}/${XL_DEPLOYIT_MANIFEST_FILE_NAME}");
        xldCreatePackage artifactsPath: "", manifestPath: "${repoName}/${XL_DEPLOYIT_MANIFEST_FILE_NAME}", darPath: "${repoName}/${repoName}-${gitCommitId}.dar" 
        println "### Build XL Deploy DAR Package Successful ###";
    }

    stage('XL Deploy Publish') {  
        xldPublishPackage serverCredentials: 'XldCreds', darPath: "${repoName}/${repoName}-${gitCommitId}.dar"
        println "Cleaning up workspace ..."
        dir(path: "${repoName}") {
            deleteDir()
        }
        println "### XL Deploy Publish Successful ###"
    }

}

def gitCheckoutFor(repoName, branchName) {
    withCredentials([
         [$class: 'UsernamePasswordMultiBinding', credentialsId: GIT_CREDENTIAL, usernameVariable: 'GIT_USERNAME', passwordVariable: 'GIT_PASSWORD']
        ]) {
            def repoUrl = repoName + '.git'
            println "Pulling code for repoUrl =" + repoUrl
            sh("rm -rf ${repoName}")
            if(repoName.equalsIgnoreCase("foundation-deployment-artifacts")) {
                sh("git clone --branch ${branchName} https://${GIT_USERNAME}:${GIT_PASSWORD}@vaprd078.schneider.com/schneider/${repoUrl} ${repoName}")
            }
            else {
                sh("git clone --branch ${branchName} https://${GIT_USERNAME}:${GIT_PASSWORD}@${GIT_DOMAIN}${repoUrl} ${repoName}")
            }
        }
}

def buildDockerImage(repoName, gitCommitId){
    env.datetime = new Date().format( 'yyyyMMddHHmmss' )
    sh("docker build -t ${NEXUS_DOCKER_REGISTRY_URL}/${nexusFolder}/${repoName}:${datetime}-${gitCommitId} -t ${DOCKER_CONTAINER_REGISTRY_URL}/${repoName}:latest ./${repoName}")
}

def pushImageToNexus(repoName, gitCommitId, nexusFolder){

    println "*********** Push Docker Image to Nexus Docker Registry *************"
    withCredentials([
        [$class: 'UsernamePasswordMultiBinding', credentialsId: 'docker_nexus_push', usernameVariable: 'NEXUS_DOCKER_REGISTRY_USERNAME', passwordVariable: 'NEXUS_DOCKER_REGISTRY_PASSWORD']
        ]) {
            sh("docker login ${NEXUS_DOCKER_REGISTRY_URL} -u ${NEXUS_DOCKER_REGISTRY_USERNAME} -p ${NEXUS_DOCKER_REGISTRY_PASSWORD}")
            sh("docker push ${NEXUS_DOCKER_REGISTRY_URL}/${nexusFolder}/${repoName}:${datetime}-${gitCommitId}")
            sh("docker rmi ${NEXUS_DOCKER_REGISTRY_URL}/${nexusFolder}/${repoName}:${datetime}-${gitCommitId}")
        }
    println "*********** Push Docker Image to Nexus Docker Registry Successful *************"   
}


def getLatestCommitIdFor(repoName, branchName) {
    withCredentials([
         [$class: 'UsernamePasswordMultiBinding', credentialsId: GIT_CREDENTIAL, usernameVariable: 'GIT_USERNAME', passwordVariable: 'GIT_PASSWORD']
         ]) {
            latestGitCommitId = sh(
                    script: "git ls-remote https://${GIT_USERNAME}:${GIT_PASSWORD}@${GIT_DOMAIN}${repoName} ${branchName} | cut -f1",
                    returnStdout: true
            ).trim()
        }
    return latestGitCommitId.substring(0,7)
}

def generateResourcesOnXLDManifestFile(repoName, resourceFiles) {
    def xldResourcesNode = "";
    ymlFiles = resourceFiles.split('\n');

    def resourceNames = ["configmap", "secret", "deployment", "service", "route", "hpa"]
    def order = 1
    
    for(int index=0; index < resourceNames.size(); index++) {
        ymlFiles.each() {
            if(it) {
                if(it.contains(resourceNames[index])) {
                    resourceNode = "${XLD_RESOURCE_NODE}";
                    resourceNode = resourceNode.replace("{{RESOURCE_FOLDER_PATH}}", repoName+"/"+it);
                    resourceNode = resourceNode.replace("{{REPO_NAME}}", order + "-" + repoName);
                    println "Updating resource file name for ${resourceNames[index]} = " + it.contains(resourceNames[index])
                    resourceNode = resourceNode.replace("{{RESOURCE_FOLDER_NAME}}", it.split("/")[2]);
                    order++
                    xldResourcesNode = xldResourcesNode + resourceNode;
                }
            }
            else {
                error "Unable to retrieve the Yml files inside k8s folder for ${repoName}";
            }
        }
    }
    return xldResourcesNode;
}

def updateYaml(yamlPath, key, value) {
        sh("sed -i 's~{{~<~g' ${yamlPath}");
        sh("sed -i 's~}}~>~g' ${yamlPath}");
        deploymentYaml = readYaml file: "${yamlPath}"

        podLabelsNode = deploymentYaml.spec.template.metadata.labels
        podLabelsNode.put(key, value)

        deploymentYaml.spec.template.metadata.labels = podLabelsNode

        sh("rm -rf ${yamlPath}")
        
        writeYaml file: "${yamlPath}", data: deploymentYaml

        sh("sed -i 's~<~{{~g' ${yamlPath}");
        sh("sed -i 's~>~}}~g' ${yamlPath}");
}