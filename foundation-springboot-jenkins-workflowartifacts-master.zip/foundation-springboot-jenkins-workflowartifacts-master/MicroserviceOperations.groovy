STOP_SCRIPT = "stop.sh"
START_SCRIPT = "start.sh"
STATUS_SCRIPT = "status.sh"

DEPLOY_DIR = "/opt/schneider/servers"
SCRIPTS_DIR = "/opt/schneider/scripts"

node("${HostName}") {

    stage("Execute ${Operation} Service Flow") {
        if(ServiceName == "") {
            error "Build Parameter - ServiceName is missing"
        }

        if(HostName == "") {
            error "Build Parameter - HostName is missing"
        }

        if(Operation == "") {
            error "Build Parameter - Operation is missing"
        }

        println "Executing ${Operation} for ${ServiceName} in ${HostName}"

        repoExists = sh(script: "test -d ${DEPLOY_DIR}/${ServiceName} && echo 'Y' || echo 'N'", returnStdout: true).trim()

        if(repoExists.equalsIgnoreCase("Y")) {

            withEnv(['JENKINS_NODE_COOKIE=dontkill']) {

                if(Operation.equalsIgnoreCase("START")) {
                    sh "${DEPLOY_DIR}/${ServiceName}/${START_SCRIPT}" 
                }
                else if(Operation.equalsIgnoreCase("STOP")) {
                    sh "${DEPLOY_DIR}/${ServiceName}/${STOP_SCRIPT}"
                }
                else if(Operation.equalsIgnoreCase("STATUS")) {
                    sh "${DEPLOY_DIR}/${ServiceName}/${STATUS_SCRIPT}"
                }
                else if(Operation.equalsIgnoreCase("RESTART")) {
                    sh "${DEPLOY_DIR}/${ServiceName}/${STOP_SCRIPT}"
                    sh "${DEPLOY_DIR}/${ServiceName}/${START_SCRIPT}"
                }
                else {
                    error "Unknown operation - ${Operation}"
                }
                
            }
        }
        else {
            error "Unable to find the ${ServiceName} in ${DEPLOY_DIR}"
        }
    }
}