GIT_BASE_URL = "https://vaprd078.schneider.com/schneider/"
GIT_CREDENTIAL = 'eebde66b-39b8-4483-9ba0-7dc8d5d209da'
GIT_DOMAIN = "vaprd078.schneider.com/schneider/"
AZURE_CONTAINER_REGISTRY_URL = "schneiderrepo.azurecr.io"

GIT_CLOUD_BASE_URL = "git@github.com:schneidertech/"
GIT_CLOUD_CREDENTIAL = 'externalgithub-snideployer'

K8S_DEPLOYMENT_YAML = "deployment.yml"
DEPLOYMENT_ARTIFACTS_REPO = "foundation-deployment-artifacts"
XL_DEPLOYIT_MANIFEST_FILE_NAME = "deployit-manifest.xml"
SONAR_URL = "http://uxprd2600:8080/sonarqube"


SERVICE_NAME = ServiceName.trim()
GIT_BRANCH_NAME = GitBranchName.trim()
REPO_LOCATION = GitRepoLocation.trim()
PROJECT_NAMESPACE = ProjectNamespace.trim()
ENV_PROFILE_NAME = "env"
XLD_FOLDER = XLDFolder.trim()

XLD_RESOURCE_NODE = """<k8s.ResourcesFile name=\"/{{REPO_NAME}}-{{RESOURCE_FOLDER_NAME}}\" file=\"{{RESOURCE_FOLDER_PATH}}\"><tags><value>${PROJECT_NAMESPACE}</value></tags><scanPlaceholders>true</scanPlaceholders><preScannedPlaceholders>true</preScannedPlaceholders><placeholders /><delimiters>{{ }}</delimiters></k8s.ResourcesFile>"""
node('prd-xebia-build-agent') {
    stage("Execute Build Job - ${SERVICE_NAME}") {  

        if(SERVICE_NAME == "") {
            error "Build Parameter - ServiceName is missing"
        }

        if(GIT_BRANCH_NAME == "") {
            error "Build Parameter - GitBranchName is missing"
        }
         if(ENV_PROFILE_NAME == "") {
            error "Build Parameter - EnvProfileName is missing"
        }
        if(XLD_FOLDER == "") {
            error "Build Parameter - XLDFolder is missing"
        }
        if(PROJECT_NAMESPACE == "") {
            error "Build Parameter - ProjectNamespace is missing"
        }      

        executeBuildFlowFor(SERVICE_NAME, GIT_BRANCH_NAME)
        println '********* Execute Build Job Successful **********'
    }
}


def executeBuildFlowFor (repoName, branchName) {
    stage("Git Checkout") {
        if(REPO_LOCATION == "Cloud") {
            println "******** Checking out source code from External Git *********"
            dir(path: "${repoName}") {
                def repoUrl = GIT_CLOUD_BASE_URL + repoName + '.git'
                git branch: branchName, credentialsId: 'externalgithub-snideployer', url: repoUrl
                env.gitCommitId = sh(returnStdout: true, script: "git log -n 1 --pretty=format:'%h'").take(7)
                println "******** External Git Checkout Successful *********"
            }
        }
        else {
            println "******** Checking out source code from Internal Git *********"
            gitCheckoutFor(repoName, branchName)
	    env.gitCommitId = getLatestCommitIdFor(repoName, branchName)	
            println "******** Internal Git Checkout Successful *********"
        }
    }

    stage("Update Pom For Release") {
        println "******** Updating Pom For Release - Removing snapshot version and add a unique build # for release ***********"
        // moved it above to make it work for both onprem and cloud repo
	// env.gitCommitId = getLatestCommitIdFor(SERVICE_NAME, GIT_BRANCH_NAME)
        jarFileName = updatePomForRelease(repoName, env.gitCommitId)
        println "************* Update Pom For Release Successful *************"
    }

    stage("Build Jar") {
        println "*********** Compiling maven project to build the jar *************"
        executeMvnGoal(repoName, "clean test install package")
        println "*********** Build Jar And Publish to Repository Successful *************"
    }

     stage('Code Coverage') { 

         dir(path: "${repoName}") {
             jacocoExecFilePath = sh(
                    script: "find . -name jacoco*.exec -print",
                    returnStdout: true
            ).trim()

            jacocoXmlPath = sh(
                    script: "find . -name jacoco.xml -print",
                    returnStdout: true
            ).trim()

            sh "/opt/schneider/sonar-scanner-cli/bin/sonar-scanner -e -Dsonar.projectKey=${repoName} -Dsonar.host.url=${SONAR_URL} -Dsonar.login=bfc9f8d776ff0e8ff1f75121160b853765daf8b1 -Dsonar.language=java -Dsonar.projectBaseDir=$WORKSPACE/${repoName} -Dsonar.java.binaries=. -Dsonar.java.coveragePlugin=jacoco -Dsonar.jacoco.reportPaths=${jacocoExecFilePath} -Dsonar.coverage.jacoco.xmlReportPaths=${jacocoXmlPath} -Dsonar.source=$WORKSPACE/${repoName}/src -Dsonar.sourceEncoding=UTF-8"
         }
     }
	 
    stage("Build & Push Docker Image to Azure") {

        azureFolder = sh(
             script: "find ./${repoName} -name 'deployment.yml' -exec grep -h 'schneiderrepo.azurecr.io' {} \\; | cut -d'/' -f 2",
             returnStdout: true
        ).trim()

	    println "azureFolder =" + azureFolder
        gitCheckoutFor(DEPLOYMENT_ARTIFACTS_REPO, "master")
	    repoDockerFileExists = sh(
             script: "find ./${repoName} -name 'Dockerfile' -exec wc -l {} \\;",
             returnStdout: true
        ).trim()
        println "repoDockerFileExists =" + repoDockerFileExists
        if(repoDockerFileExists?.trim())
        {
            println "*********** Bulding Docker Image from local docker file*************"
            buildDockerImageInProject(jarFileName, repoName, env.gitCommitId, azureFolder)
            println "*********** Bulding Docker Image Successful *************"
	    }
        else
        {       
       		FOLDER_NAME = "services"        
        	println "*********** Bulding Docker Image from common docker file*************"
        	buildDockerImage(jarFileName, FOLDER_NAME, repoName, env.gitCommitId, azureFolder)
        	println "*********** Bulding Docker Image Successful *************"
        }         
      
        println "*********** Push Docker Image to Azure Container Registry *************"
        pushImageToAcr(repoName, env.gitCommitId, azureFolder)
        println "*********** Push Docker Image to Azure Container Registry Successful *************"
    }

    stage("Build XL Deploy DAR Package") {
        env.serviceName = SERVICE_NAME
	
	k8sDeploymentFile = sh(
	    //script: "find ./${repoName} -type d -name k8s -prune -o -name 'deployment.yml'",
	    script: "find ./${repoName} -name 'deployment.yml'",
	    returnStdout: true
   	 ).trim()
	 
	 println "${k8sDeploymentFile}"

	//sh("sed -i 's~{{IMAGE_VERSION}}~${BUILD_NUMBER}-${env.gitCommitId}~g' ${repoName}/${K8S_DEPLOYMENT_YAML}");    
	 sh("sed -i 's~{{IMAGE_VERSION}}~${BUILD_NUMBER}-${env.gitCommitId}~g' ${k8sDeploymentFile}");    
	 
	    
        sh("cp -r ./${repoName}/k8s/* ./${repoName}")
        sh "cp ./${DEPLOYMENT_ARTIFACTS_REPO}/xebia/AKS/${XL_DEPLOYIT_MANIFEST_FILE_NAME} ${repoName}/${XL_DEPLOYIT_MANIFEST_FILE_NAME}"
        resourceFiles = sh(
                    script: "find ./${repoName}/k8s/ -name '*.yml' -print",
                    returnStdout: true
            ).trim()

        resourceFiles = resourceFiles.replace("./${repoName}/k8s", "")
        println "************ Resources in k8s Folder ************"
        println "${resourceFiles}"

        xldResourcesNode = generateResourcesOnXLDManifestFile(repoName, resourceFiles)     
        println("************* Generated XLD Resources Node *****************")
        println "${xldResourcesNode}"

    	

        sh("sed -i 's~{{ARTIFACT_VERSION}}~${BUILD_NUMBER}-${env.gitCommitId}~g' ${repoName}/${XL_DEPLOYIT_MANIFEST_FILE_NAME}");
        sh("sed -i 's~{{XLD_FOLDER}}~${XLD_FOLDER}~g' ${repoName}/${XL_DEPLOYIT_MANIFEST_FILE_NAME}");
        if(XLD_FOLDER.equalsIgnoreCase("Snapshots")) {
            sh("sed -i 's~{{REPO_NAME}}~${repoName}-snapshot~g' ${repoName}/${XL_DEPLOYIT_MANIFEST_FILE_NAME}");
        }
        else {
            sh("sed -i 's~{{REPO_NAME}}~${repoName}~g' ${repoName}/${XL_DEPLOYIT_MANIFEST_FILE_NAME}");
        }
        sh("sed -i 's~{{REPO_NAME}}~${repoName}~g' ${repoName}/${XL_DEPLOYIT_MANIFEST_FILE_NAME}");
        sh("sed -i 's~{{XLD_RESOURCES_NODES}}~${xldResourcesNode}~g' ${repoName}/${XL_DEPLOYIT_MANIFEST_FILE_NAME}");

        xldCreatePackage artifactsPath: "", manifestPath: "${repoName}/${XL_DEPLOYIT_MANIFEST_FILE_NAME}", darPath: "${repoName}/${serviceName}-${gitCommitId}.dar" 
        println "### Build XL Deploy DAR Package Successful ###";
    }

    stage('XL Deploy Publish') {  
        xldPublishPackage serverCredentials: 'XldCreds', darPath: "${repoName}/${serviceName}-${gitCommitId}.dar"
        println "Pushed docker image with version ${gitCommitId}"
        println "Cleaning up workspace ..."
        dir(path: "${repoName}") {
            deleteDir()
        }
        println "### XL Deploy Publish Successful ###"
    }
}

def gitCheckoutFor(repoName, branchName) {
    withCredentials([
         [$class: 'UsernamePasswordMultiBinding', credentialsId: GIT_CREDENTIAL, usernameVariable: 'GIT_USERNAME', passwordVariable: 'GIT_PASSWORD']
        ]) {
            def repoUrl = repoName + '.git'
            println "Pulling code for repoUrl =" + repoUrl
            sh("rm -rf ${repoName}")
            sh("git clone --branch ${branchName} https://${GIT_USERNAME}:${GIT_PASSWORD}@${GIT_DOMAIN}${repoUrl} ${repoName}")
        }
}

def buildDockerImage(jarFileName, FOLDER_NAME, repoName, gitCommitId, azureFolder){
    sh("cp ${repoName}/target/${jarFileName}.jar ./${DEPLOYMENT_ARTIFACTS_REPO}/${FOLDER_NAME}/${repoName}.jar")
        sh "sed -i 's~{{SERVICE_NAME}}~${repoName}~g' ./${DEPLOYMENT_ARTIFACTS_REPO}/${FOLDER_NAME}/Dockerfile"
        sh "sed -i 's~{{PROFILE_NAME}}~${ENV_PROFILE_NAME}~g' ./${DEPLOYMENT_ARTIFACTS_REPO}/${FOLDER_NAME}/config/application.yml"
        sh "sed -i 's~{{REPO_NAME}}~${repoName}~g' ./${DEPLOYMENT_ARTIFACTS_REPO}/${FOLDER_NAME}/config/application.yml"
        sh("docker build -t ${AZURE_CONTAINER_REGISTRY_URL}/${azureFolder}/${repoName}:${BUILD_NUMBER}-${gitCommitId} -t ${AZURE_CONTAINER_REGISTRY_URL}/${azureFolder}/${repoName}:latest ./${DEPLOYMENT_ARTIFACTS_REPO}/${FOLDER_NAME}/")
}

def buildDockerImageInProject(jarFileName, repoName, gitCommitId, azureFolder){
    sh("cp ${repoName}/target/${jarFileName}.jar ./${repoName}/${repoName}.jar")
    sh "sed -i 's~{{SERVICE_NAME}}~${repoName}~g' ${repoName}/Dockerfile"
    sh("docker build -t ${AZURE_CONTAINER_REGISTRY_URL}/${azureFolder}/${repoName}:${BUILD_NUMBER}-${gitCommitId} -t ${AZURE_CONTAINER_REGISTRY_URL}/${azureFolder}/${repoName}:latest ${repoName}")
}

def pushImageToAcr(repoName, gitCommitId, azureFolder){
    withCredentials([
        [$class: 'UsernamePasswordMultiBinding', credentialsId: 'schneiderrepoazurecr', usernameVariable: 'AZURE_CONTAINER_REGISTRY_USERNAME', passwordVariable: 'AZURE_CONTAINER_REGISTRY_PASSWORD']
        ]) {
            sh("docker login ${AZURE_CONTAINER_REGISTRY_URL} -u ${AZURE_CONTAINER_REGISTRY_USERNAME} -p ${AZURE_CONTAINER_REGISTRY_PASSWORD}")
            sh("docker push ${AZURE_CONTAINER_REGISTRY_URL}/${azureFolder}/${repoName}:${BUILD_NUMBER}-${gitCommitId}")
            sh("docker push ${AZURE_CONTAINER_REGISTRY_URL}/${azureFolder}/${repoName}:latest")
            sh("docker rmi ${AZURE_CONTAINER_REGISTRY_URL}/${azureFolder}/${repoName}:${BUILD_NUMBER}-${gitCommitId}")
            sh("docker rmi ${AZURE_CONTAINER_REGISTRY_URL}/${azureFolder}/${repoName}:latest")
        }
}

def getLatestCommitIdFor(repoName, branchName) {
    withCredentials([
         [$class: 'UsernamePasswordMultiBinding', credentialsId: GIT_CREDENTIAL, usernameVariable: 'GIT_USERNAME', passwordVariable: 'GIT_PASSWORD']
         ]) {
            latestGitCommitId = sh(
                    script: "git ls-remote https://${GIT_USERNAME}:${GIT_PASSWORD}@${GIT_DOMAIN}${repoName} ${branchName} | cut -f1",
                    returnStdout: true
            ).trim()
        }
    return latestGitCommitId.substring(0,7)
}

def updatePomForRelease(repoName, gitCommitId) {
    def pom = readMavenPom file: repoName + '/pom.xml'
    def version = ""

    try {
        if(pom.version.contains("-SNAPSHOT")) {
            version = pom.version.replace("-SNAPSHOT", ".${gitCommitId}")
         }
        else {
            version = pom.version+".${gitCommitId}"
        }
    }
    catch (Exception e) {
        println "Version tag is missing in pom.xml for " + repoName
        sh "exit 1"
    }
 
    executeMvnGoal(repoName, "versions:set versions:commit -DnewVersion=${version}")
    def jarFileName = pom.artifactId + "-" + version   
    return jarFileName
}

def executeMvnGoal(repoName, mvnGoal) {
    withMaven(
        maven: 'M3',
        mavenSettingsConfig: '861beabf-0e69-49b4-bc3c-aa5de0b1eb7e',
        mavenLocalRepo: '.repository'
    ) {
        sh "mvn -f ./${repoName}/pom.xml ${mvnGoal}"
    }
}

def generateResourcesOnXLDManifestFile(repoName, resourceFiles) {
    def xldResourcesNode = "";
    ymlFiles = resourceFiles.split('\n');

    def resourceNames = ["configmap", "secret", "deployment", "service", "route"]
    def order = 1
    
    for(int index=0; index < resourceNames.size(); index++) {
        ymlFiles.each() {
            if(it) {
                if(it.contains(resourceNames[index])) {
                    resourceNode = "${XLD_RESOURCE_NODE}";
                    resourceNode = resourceNode.replace("{{RESOURCE_FOLDER_PATH}}", repoName+"/"+it);
                    resourceNode = resourceNode.replace("{{REPO_NAME}}", order + "-" + repoName);
                    println "Updating resource file name for ${resourceNames[index]} = " + it.contains(resourceNames[index])
                    resourceNode = resourceNode.replace("{{RESOURCE_FOLDER_NAME}}", it.split("/")[1]);
                    order++
                    xldResourcesNode = xldResourcesNode + resourceNode;
                }
            }
            else {
                error "Unable to retrieve the Yml files inside k8s folder for ${repoName}";
            }
        }
    }
    return xldResourcesNode;
}
