GIT_BASE_URL = "https://vaprd078.schneider.com/schneider/"
GIT_DOMAIN = "vaprd078.schneider.com/schneider/"
GIT_CREDENTIAL = 'eebde66b-39b8-4483-9ba0-7dc8d5d209da'

GIT_CLOUD_BASE_URL = "git@github.com:schneidertech/"
GIT_CLOUD_CREDENTIAL = 'externalgithub-snideployer'

DOCKER_BASE_URL="sonatypenexus.schneider.com:19443"

AZURE_CONTAINER_REGISTRY_URL = "schneiderrepo.azurecr.io"

K8S_DEPLOYMENT_YAML = "deployment.yml"
XL_DEPLOYIT_MANIFEST_FILE_NAME = "deployit-manifest.xml"

SONAR_URL = "http://uxprd2600:8080/sonarqube"

REPO_NAME = GitRepoName.trim()
REPO_LOCATION = GitRepoLocation.trim()
GIT_BRANCH_NAME = GitBranchName.trim()
PROJECT_NAMESPACE = ProjectNamespace.trim()
ENV_PROFILE_NAME = "env"
XLD_FOLDER = XLDFolder.trim()


XLD_RESOURCE_NODE = """<k8s.ResourcesFile name=\"/{{REPO_NAME}}-{{RESOURCE_FOLDER_NAME}}\" file=\"{{RESOURCE_FOLDER_PATH}}\"><tags><value>${PROJECT_NAMESPACE}</value></tags><scanPlaceholders>true</scanPlaceholders><preScannedPlaceholders>true</preScannedPlaceholders><placeholders /><delimiters>{{ }}</delimiters></k8s.ResourcesFile>"""
node('prd-xebia-build-agent') {
    stage("Validations") {  

        if(REPO_NAME == "") {
            error "Build Parameter - GitRepoName is missing"
        }

        if(GIT_BRANCH_NAME == "") {
            error "Build Parameter - GitBranchName is missing"
        }
         if(ENV_PROFILE_NAME == "") {
            error "Build Parameter - EnvProfileName is missing"
        }
        if(XLD_FOLDER == "") {
            error "Build Parameter - XLDFolder is missing"
        }
        if(PROJECT_NAMESPACE == "") {
            error "Build Parameter - ProjectNamespace is missing"
        }

        executeBuildFlowFor(REPO_NAME, GIT_BRANCH_NAME)
        println '********* Build Job Successful **********'
    }
}


def executeBuildFlowFor (repoName, branchName) {
    stage("Git Checkout") {
        if(REPO_LOCATION == "Cloud") {
            println "******** Checking out source code from External Git *********"
            dir(path: "${repoName}") {
                def repoUrl = GIT_CLOUD_BASE_URL + repoName + '.git'
                git branch: branchName, credentialsId: 'externalgithub-snideployer', url: repoUrl
                env.gitCommitId = sh(returnStdout: true, script: "git log -n 1 --pretty=format:'%h'").take(7)
                println "******** External Git Checkout Successful *********"
            }
        }
        else {
            println "******** Checking out source code from Internal Git *********"
            gitCheckoutFor(repoName, branchName)
            env.gitCommitId = getLatestCommitIdFor(REPO_NAME, GIT_BRANCH_NAME)
            println "******** Internal Git Checkout Successful *********"
        }
    }

    stage('Code Coverage') { 
        sh "/opt/schneider/sonar-scanner-cli/bin/sonar-scanner -e -Dsonar.projectKey=${repoName} -Dsonar.host.url=${SONAR_URL} -Dsonar.login=bfc9f8d776ff0e8ff1f75121160b853765daf8b1 -Dsonar.projectBaseDir=$WORKSPACE/${repoName} -Dsonar.javascript.file.suffixes=.js,.jsx -Dsonar.sourceEncoding=UTF-8"
    }

    stage("Build & Push Docker Image") {
        
        azureFolder = sh(
            script: "grep 'schneiderrepo.azurecr.io' ./${repoName}/k8s/deployment.yml | cut -d'/' -f 2",
            returnStdout: true
        ).trim()

        println "Azure Container Folder: "+azureFolder
        println "*********** Bulding Docker Image *************"
        buildDockerImage(repoName, env.gitCommitId, azureFolder)
        println "*********** Bulding Docker Image Successful *************"
    
        println "*********** Push Docker Image to Azure Container Registry *************"
        pushImageToAcr(repoName, env.gitCommitId, azureFolder)
        println "*********** Push Docker Image to Azure Container Registry Successful *************"
    }

    stage("Build XL Deploy DAR Package") {
        
        sh("cp -r ./${repoName}/k8s/* ./${repoName}")
        
        resourceFiles = sh(
                    script: "find ./${repoName}/k8s/ -name '*.yml' -print",
                    returnStdout: true
            ).trim()

        resourceFiles = resourceFiles.replace("./${repoName}/k8s", "")
        println "************ Resources in k8s Folder ************"
        println "${resourceFiles}"

        xldResourcesNode = generateResourcesOnXLDManifestFile(repoName, resourceFiles)     
        println("************* Generated XLD Resources Node *****************")
        println "${xldResourcesNode}"

        sh("sed -i 's~{{IMAGE_VERSION}}~${datetime}-${env.gitCommitId}~g' ${repoName}/${K8S_DEPLOYMENT_YAML}");
        sh("sed -i 's~{{ARTIFACT_VERSION}}~${datetime}-${env.gitCommitId}~g' ${repoName}/${XL_DEPLOYIT_MANIFEST_FILE_NAME}");
        sh("sed -i 's~{{XLD_FOLDER}}~${XLD_FOLDER}~g' ${repoName}/${XL_DEPLOYIT_MANIFEST_FILE_NAME}");

        if(XLD_FOLDER.equalsIgnoreCase("Snapshots")) {
            sh("sed -i 's~{{REPO_NAME}}~${repoName}-snapshot~g' ${repoName}/${XL_DEPLOYIT_MANIFEST_FILE_NAME}");
        }
        else {
            sh("sed -i 's~{{REPO_NAME}}~${repoName}~g' ${repoName}/${XL_DEPLOYIT_MANIFEST_FILE_NAME}");
        }

        sh("sed -i 's~{{REPO_NAME}}~${repoName}~g' ${repoName}/${XL_DEPLOYIT_MANIFEST_FILE_NAME}");
        sh("sed -i 's~{{XLD_RESOURCES_NODES}}~${xldResourcesNode}~g' ${repoName}/${XL_DEPLOYIT_MANIFEST_FILE_NAME}");

        xldCreatePackage artifactsPath: "", manifestPath: "${repoName}/${XL_DEPLOYIT_MANIFEST_FILE_NAME}", darPath: "${repoName}/${repoName}-${gitCommitId}.dar" 
        println "### Build XL Deploy DAR Package Successful ###";
    }

    stage('XL Deploy Publish') {  
        xldPublishPackage serverCredentials: 'XldCreds', darPath: "${repoName}/${repoName}-${gitCommitId}.dar"
        println "Cleaning up workspace ..."
        dir(path: "${repoName}") {
            deleteDir()
        }
        println "### XL Deploy Publish Successful ###"
    }

}

def gitCheckoutFor(repoName, branchName) {
    withCredentials([
         [$class: 'UsernamePasswordMultiBinding', credentialsId: GIT_CREDENTIAL, usernameVariable: 'GIT_USERNAME', passwordVariable: 'GIT_PASSWORD']
        ]) {
            def repoUrl = repoName + '.git'
            println "Pulling code for repoUrl =" + repoUrl
            sh("rm -rf ${repoName}")
            sh("git clone --branch ${branchName} https://${GIT_USERNAME}:${GIT_PASSWORD}@${GIT_DOMAIN}${repoUrl} ${repoName}")
        }
}

def buildDockerImage(repoName, gitCommitId, azureFolder){
    env.datetime = new Date().format( 'yyyyMMddHHmmssSSS' )
    sh("docker build --build-arg DOCKER_BASE_URL=${DOCKER_BASE_URL} -t ${AZURE_CONTAINER_REGISTRY_URL}/${azureFolder}/${repoName}:${datetime}-${gitCommitId} -t ${AZURE_CONTAINER_REGISTRY_URL}/${azureFolder}/${repoName}:latest ./${repoName}")
}

def pushImageToAcr(repoName, gitCommitId, azureFolder){
    withCredentials([
        [$class: 'UsernamePasswordMultiBinding', credentialsId: 'schneiderrepoazurecr', usernameVariable: 'AZURE_CONTAINER_REGISTRY_USERNAME', passwordVariable: 'AZURE_CONTAINER_REGISTRY_PASSWORD']
        ]) {
            sh("docker login ${AZURE_CONTAINER_REGISTRY_URL} -u ${AZURE_CONTAINER_REGISTRY_USERNAME} -p ${AZURE_CONTAINER_REGISTRY_PASSWORD}")
            sh("docker push ${AZURE_CONTAINER_REGISTRY_URL}/${azureFolder}/${repoName}:${datetime}-${gitCommitId}")
            sh("docker push ${AZURE_CONTAINER_REGISTRY_URL}/${azureFolder}/${repoName}:latest")
            sh("docker rmi ${AZURE_CONTAINER_REGISTRY_URL}/${azureFolder}/${repoName}:${datetime}-${gitCommitId}")
            sh("docker rmi ${AZURE_CONTAINER_REGISTRY_URL}/${azureFolder}/${repoName}:latest")
        }
}

def getLatestCommitIdFor(repoName, branchName) {
    withCredentials([
         [$class: 'UsernamePasswordMultiBinding', credentialsId: GIT_CREDENTIAL, usernameVariable: 'GIT_USERNAME', passwordVariable: 'GIT_PASSWORD']
         ]) {
            latestGitCommitId = sh(
                    script: "git ls-remote https://${GIT_USERNAME}:${GIT_PASSWORD}@${GIT_DOMAIN}${repoName} ${branchName} | cut -f1",
                    returnStdout: true
            ).trim()
        }
    return latestGitCommitId.substring(0,7)
}

def generateResourcesOnXLDManifestFile(repoName, resourceFiles) {
    def xldResourcesNode = "";
    ymlFiles = resourceFiles.split('\n');

    def resourceNames = ["configmap", "secret", "deployment", "service", "route"]
    def order = 1
    
    for(int index=0; index < resourceNames.size(); index++) {
        ymlFiles.each() {
            if(it) {
                if(it.contains(resourceNames[index])) {
                    resourceNode = "${XLD_RESOURCE_NODE}";
                    resourceNode = resourceNode.replace("{{RESOURCE_FOLDER_PATH}}", repoName+"/"+it);
                    resourceNode = resourceNode.replace("{{REPO_NAME}}", order + "-" + repoName);
                    println "Updating resource file name for ${resourceNames[index]} = " + it.contains(resourceNames[index])
                    resourceNode = resourceNode.replace("{{RESOURCE_FOLDER_NAME}}", it.split("/")[1]);
                    order++
                    xldResourcesNode = xldResourcesNode + resourceNode;
                }
            }
            else {
                error "Unable to retrieve the Yml files inside k8s folder for ${repoName}";
            }
        }
    }
    return xldResourcesNode;
}
