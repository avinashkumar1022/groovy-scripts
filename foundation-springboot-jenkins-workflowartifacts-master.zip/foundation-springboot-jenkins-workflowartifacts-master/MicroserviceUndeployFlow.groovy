DEPLOY_DIR = "/opt/schneider/servers"
STOP_SCRIPT = "stop.sh"
STATUS_SCRIPT = "status.sh"

node("${HostName}") {

    stage("Execute Undeploy Flow") {
        if(ServiceName == "") {
            error "Build Parameter - ServiceName is missing"
        }

        if(HostName == "") {
            error "Build Parameter - HostName is missing"
        }
		
		def deployServicesList = ServiceName.split(',').collect { it.trim() }
		for (service in deployServicesList) {
			repoExists = sh(script: "test -d ${DEPLOY_DIR}/${service} && echo 'Y' || echo 'N'", returnStdout: true).trim()

	        if(repoExists.equalsIgnoreCase("Y")) {

	            serviceStatus = sh(script: "${DEPLOY_DIR}/${service}/${STATUS_SCRIPT}", returnStatus: true)
	            
	            if(serviceStatus != 0) {
	                println "Skipping stop.sh because service status is ${serviceStatus}"
	            }
	            else {
	                withEnv(['JENKINS_NODE_COOKIE=dontkill']) {
	                    sh "${DEPLOY_DIR}/${service}/${STOP_SCRIPT}"
	                    echo "Stopped the server successfully - ${service}"
	                }
	            }
	            
	            xfsBased = sh(script: "test -d /opt/schneider/fs && echo 'N' || echo 'Y'", returnStdout: true).trim()

	            println "Is host xfsBased=${xfsBased}"
	            if("${xfsBased}".equalsIgnoreCase("Y"))
	            {
	                println "Undeploying based on xfs based system... "
	                sh "/opt/sni/unix/tools/linux/remove_pquota_dir -d ${DEPLOY_DIR}/${service}"
	            }
	            else {
	                currentVolume = sh(script: "readlink -f ${DEPLOY_DIR}/${service}", returnStdout: true).trim()
	                if(currentVolume == "" || currentVolume == null) {
	                    error "Unable to find the volume for ${service}"
	                }
	                else {                
	                    echo "Current Volume is " + currentVolume
	                    sh "rm ${DEPLOY_DIR}/${service}"
	                    sh "rm -rf ${currentVolume}/*"
	                    echo "Undeployed successfully ${service}"
	                }
	            }
	        }
	        else {
	            error "Unable to find the ${service} in ${DEPLOY_DIR}"
	        }
		}
    }
}