GIT_BASE_URL = "https://vaprd078.schneider.com/schneider/"
GIT_CREDENTIAL = 'internalgithub-snideployer'
GIT_DOMAIN = "vaprd078.schneider.com/schneider/"

GIT_CLOUD_BASE_URL = "git@github.com:schneidertech/"
GIT_CLOUD_CREDENTIAL = 'externalgithub-snideployer'

GIT_BRANCH_NAME = GitBranchName.trim()
REPO_LOCATION = GitRepoLocation.trim()
REPO_NAME = GitRepoName.trim()

node('mac') {
    stage("Execute Build Job") {  
        executeBuildFlowFor(REPO_NAME, GIT_BRANCH_NAME)
        println '********* Build Job Successful **********'
    }
}

def executeBuildFlowFor (repoName, branchName) {
    stage("Git Checkout") {
        if(REPO_LOCATION == "Cloud") {
            println "******** Checking out source code from External Git *********"
            println "Cleaning up workspace ..."
            deleteDir()
            dir(path: "${repoName}") {
                def repoUrl = GIT_CLOUD_BASE_URL + repoName + '.git'
                git branch: branchName, credentialsId: 'externalgithub-snideployer', url: repoUrl
                env.gitCommitId = sh(returnStdout: true, script: "git log -n 1 --pretty=format:'%h'").take(7)
                println "******** External Git Checkout Successful *********"
            }
        }
        else {
            println "******** Checking out source code from Internal Git *********"
            gitCheckoutFor(repoName, branchName)
            env.gitCommitId = getLatestCommitIdFor(repoName, branchName)
            println "******** Internal Git Checkout Successful *********"
        }
    }

    stage("Run npm build and add ionic and capacitor modules for Android") {
        println "*********** Adding Capacitor Dependencies *************"
        dir(path: "${repoName}") {
            sh "rm -rf node_modules"
            sh "npm install"
            //sh "npm install -D typescript"
            sh "npm install @types/node --save-dev"
            //sh "npm i @types/node"
            sh "npm install ionic"
            //sh "npm i fcm-node"
            //sh "npm install react-scripts"
            //sh "npm install @ionic/react-hooks"
            //sh "npm install node-sass"
            //sh "npm install --save-dev @types/googlemaps"
            //sh "npm install reactjs-pdf-reader"
            sh "npm install @capacitor/core @capacitor/cli"
            //sh "npm install run-script-os"
            //sh "npm i os"
            sh "npm run build"
            //sh "npx cap init Schneider com.cognizantmobilityenterprise.schneider"
            //sh "npx cap add android"
            //sh "gem install xcpretty"
            //sh "npx cap copy ios"
            sh "npx cap sync ios"
        }
        println "*********** Adding ionic and capacitor dependencies successful *************"
    }

    stage("XCode Build IPA") {
        println "*********** Building IPA *************"
        dir(path: "${repoName}") {
            
            xcodeBuild appURL: '', assetPackManifestURL: '', buildDir: '', buildIpa: true, bundleID: '', bundleIDInfoPlistPath: '', cfBundleShortVersionStringValue: '', cfBundleVersionValue: '', cleanBeforeBuild: false, cleanResultBundlePath: false, configuration: 'Release', developmentTeamID: '259H9632GP', developmentTeamName: 'Schneider National, Inc', displayImageURL: '', fullSizeImageURL: '', generateArchive: true, ipaExportMethod: 'enterprise', ipaName: 'FreightPower', ipaOutputDirectory: '', logfileOutputDirectory: '', provisioningProfiles: [[provisioningProfileAppId: 'com.schneider.ce', provisioningProfileUUID: 'f5708748-2615-4659-94ac-9587077eb1cd']], resultBundlePath: '', sdk: '', signingMethod: 'manual', symRoot: '', target: '', thinning: '', xcodeProjectFile: '', xcodeProjectPath: '', xcodeSchema: 'App', xcodeWorkspaceFile: '/Users/j08811/build/workspace/carrier_experience/IOS-IPA-BuildFlow/sni-carrier-experience/ios/App/App', xcodebuildArguments: ''
        }    
        
        println "*********** Building IPA Successful *************"
    }
    
   stage("Publish to Azure App Center") {
   
        dir(path: "${repoName}") {
            
            appCenter apiToken: 'c2ed2768db5c8e4802a110f8750b339061405149', appName: 'SNI-Azure-IOS', distributionGroups: 'CE2O-DEV', notifyTesters: false, ownerName: 'KumarA8-schneider.com', pathToApp: 'build/Release-iphoneos/*.ipa', pathToDebugSymbols: '', pathToReleaseNotes: '', releaseNotes: 'Published from Jenkins Internal'
            
            println "*********** Publish to Microsoft App Center Successful *************"
        }
    }
}

 def gitCheckoutFor(repoName, branchName) {
    withCredentials([
         [$class: 'UsernamePasswordMultiBinding', credentialsId: GIT_CREDENTIAL, usernameVariable: 'GIT_USERNAME', passwordVariable: 'GIT_PASSWORD']
        ]) {
            def repoUrl = repoName + '.git'
            println "Pulling code for repoUrl =" + repoUrl
            sh("rm -rf ${repoName}")
            sh("git clone --branch ${branchName} https://${GIT_USERNAME}:${GIT_PASSWORD}@${GIT_DOMAIN}${repoUrl} ${repoName}")
        }
}

def getLatestCommitIdFor(repoName, branchName) {
    withCredentials([
         [$class: 'UsernamePasswordMultiBinding', credentialsId: GIT_CREDENTIAL, usernameVariable: 'GIT_USERNAME', passwordVariable: 'GIT_PASSWORD']
         ]) {
            latestGitCommitId = sh(
                    script: "git ls-remote https://${GIT_USERNAME}:${GIT_PASSWORD}@${GIT_DOMAIN}${repoName} ${branchName} | cut -f1",
                    returnStdout: true
            ).trim()
        }
    return latestGitCommitId.substring(0,7)
} 