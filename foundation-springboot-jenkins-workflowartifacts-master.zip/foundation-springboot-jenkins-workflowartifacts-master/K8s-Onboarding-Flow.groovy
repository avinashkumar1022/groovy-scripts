GIT_BASE_URL = "https://vaprd078.schneider.com/schneider/"
GIT_CREDENTIAL = 'eebde66b-39b8-4483-9ba0-7dc8d5d209da'
GIT_DOMAIN = "vaprd078.schneider.com/schneider/"

XL_DEPLOYIT_MANIFEST_FILE_NAME = "deployit-manifest.xml"

REPO_NAME = GitRepositoryName.trim()
GIT_BRANCH_NAME = GitBranchName.trim()
PROJECT_NAMESPACE = ProjectNamespace.trim()
K8S_CLUSTER_TYPE = K8sClusterType.trim()

node('prd-xebia-build-agent') {

    stage("Validate Input Parameters") {
        if(GIT_BRANCH_NAME == "") {
            error "Build Parameter - GitBranchName is missing"
        }

        if(REPO_NAME == "") {
            error "Build Parameter - GitRepositoryName is missing"
        }

        if(PROJECT_NAMESPACE == "") {
            error "Build Parameter - ProjectNamespace is missing"
        }

        if(K8S_CLUSTER_TYPE == "") {
            error "Build Parameter - K8sClusterName is missing"
        }
    }

    stage("Git Checkout") {
        println "******** Checking out source code from Git *********"
        gitCheckoutFor(REPO_NAME, GIT_BRANCH_NAME)
        println "******** Git Checkout Successful *********"
    }

    stage("Update Parameters") {
        sh("find ./${REPO_NAME}/${K8S_CLUSTER_TYPE}/ -type f -exec sed -i 's~{{PROJECT_NAMESPACE}}~${PROJECT_NAMESPACE}~g' {} \\;")
        sh("find ./${REPO_NAME}/${K8S_CLUSTER_TYPE}/ -type f -exec sed -i 's~{{APPLICATION_VERSION}}~${BUILD_NUMBER}~g' {} \\;")
        sh("find ./${REPO_NAME}/${K8S_CLUSTER_TYPE}/ -type f -exec sed -i 's~{{REPO_NAME}}~${REPO_NAME}~g' {} \\;")
        sh("find ./${REPO_NAME}/${K8S_CLUSTER_TYPE}/ -type f -exec sed -i 's~{{K8S_CLUSTER_TYPE}}~${K8S_CLUSTER_TYPE}~g' {} \\;")
        println "******** Update Parameters Successful *********"
    }

    stage("Build XL Deploy DAR Package For Namespace") {
        xldCreatePackage artifactsPath: "", manifestPath: "${REPO_NAME}/${K8S_CLUSTER_TYPE}/${XL_DEPLOYIT_MANIFEST_FILE_NAME}", darPath: "${BUILD_NUMBER}-${PROJECT_NAMESPACE}.dar" 
        println "******** Build XL Deploy DAR Package For Namespace Successful ********";
    }

    stage("Build XL Deploy DAR Package For RBAC") {
        xldCreatePackage artifactsPath: "", manifestPath: "${REPO_NAME}/${K8S_CLUSTER_TYPE}/rbac/${XL_DEPLOYIT_MANIFEST_FILE_NAME}", darPath: "${BUILD_NUMBER}-${PROJECT_NAMESPACE}-rbac.dar" 
        println "******** Build XL Deploy DAR Package For RBAC Successful ********";
    }

    stage('XL Deploy Publish For Namespace And RBAC') {  
        println "Publishing XLD Dar Package ${BUILD_NUMBER}-${PROJECT_NAMESPACE}.dar"
        xldPublishPackage serverCredentials: 'XldCreds', darPath: "${BUILD_NUMBER}-${PROJECT_NAMESPACE}.dar"
        println "Publishing XLD Dar Package ${BUILD_NUMBER}-${PROJECT_NAMESPACE}-rbac.dar"
        xldPublishPackage serverCredentials: 'XldCreds', darPath: "${BUILD_NUMBER}-${PROJECT_NAMESPACE}-rbac.dar"
        println "Cleaning up workspace ..."
        deleteDir()
        println "******** XL Deploy Publish For Namespace And RBAC Successful ********"
    }
}

def gitCheckoutFor(repoName, branchName) {
    withCredentials([
         [$class: 'UsernamePasswordMultiBinding', credentialsId: GIT_CREDENTIAL, usernameVariable: 'GIT_USERNAME', passwordVariable: 'GIT_PASSWORD']
        ]) {
            def repoUrl = repoName + '.git'
            println "Pulling code for repoUrl =" + repoUrl
            sh("rm -rf ${repoName}")
            sh("git clone --branch ${branchName} https://${GIT_USERNAME}:${GIT_PASSWORD}@${GIT_DOMAIN}${repoUrl} ${repoName}")
        }
}
