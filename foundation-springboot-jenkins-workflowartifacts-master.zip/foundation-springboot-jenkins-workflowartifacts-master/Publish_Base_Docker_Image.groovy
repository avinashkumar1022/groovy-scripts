GIT_BASE_URL="https://vaprd078.schneider.com/schneider"
GIT_REPO_NAME="enterprise-basedocker-images"
GIT_CREDENTIAL='eebde66b-39b8-4483-9ba0-7dc8d5d209da'
NEXUS_URL="sonatypenexus.schneider.com:20443"


node('prd-xebia-build-agent') {
    stage('Git Checkout') {
	
        println "******** Checking out source code from Git *********"
        checkout changelog: false, poll: false, scm: [$class: 'GitSCM', branches: [[name: '*/${branchName}']], doGenerateSubmoduleConfigurations: false, extensions: [], submoduleCfg: [], userRemoteConfigs: [[credentialsId: "${GIT_CREDENTIAL}", url: "${GIT_BASE_URL}/${GIT_REPO_NAME}.git"]]]
        println "******** Git Checkout Successful *********"
	};
	 stage('Build image') {
	     
	    if(SubfolderName == ""){ 
	                            sh("cd ./${folderName};docker build --no-cache -t ${NEXUS_URL}/${folderName}:${dockerTag} .")
                                sh("docker images | grep ${folderName}")

                docker.withRegistry("https://${NEXUS_URL}", 'docker_nexus_push')
                {
                    sh("docker push ${NEXUS_URL}/${folderName}:${dockerTag}")
                }
	    } 
	    else {
	            sh("cd ./${folderName}/${SubfolderName};docker build --no-cache -t ${NEXUS_URL}/${folderName}/${SubfolderName}:${dockerTag} .")
                sh("docker images | grep ${folderName}")

                docker.withRegistry("https://${NEXUS_URL}", 'docker_nexus_push')
                {
                    sh("docker push ${NEXUS_URL}/${folderName}/${SubfolderName}:${dockerTag}")
	            }
	    }   
    }
}

