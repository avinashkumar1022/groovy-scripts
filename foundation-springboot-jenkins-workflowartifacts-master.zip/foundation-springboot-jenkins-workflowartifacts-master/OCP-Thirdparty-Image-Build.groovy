
GIT_BASE_URL = "https://vaprd078.schneider.com/schneider/"
GIT_CREDENTIAL = 'eebde66b-39b8-4483-9ba0-7dc8d5d209da'
GIT_DOMAIN = "vaprd078.schneider.com/schneider/"
DOCKER_REGISTRY_URL = "dockerregistryunt1.intra.schneider.com"
DOCKER_REGISTRY_USERNAME = "dockerregistry"
DOCKER_REGISTRY_PASSWORD = "dockerregistry42018"
DEPLOYMENT_ARTIFACTS_REPO = "foundation-deployment-artifacts"
XL_DEPLOYIT_MANIFEST_FILE_NAME = "deployit-manifest.xml"
K8S_DEPLOYMENT_YAML = "./deployment/deployment.yml"
DEPLOYMENT_YAML_PATH = "k8s/deployment/deployment.yml"
SONAR_URL = "http://uxprd2600:8080/sonarqube"

SERVICE_NAME = ServiceName.trim()
GIT_BRANCH_NAME = GitBranchName.trim()
ENV_PROFILE_NAME = "env"
XLD_FOLDER = XLDFolder.trim()
PROJECT_NAMESPACE = ProjectNamespace.trim()
HAS_MAPR = HasMapr.trim()
GIT_COMMIT_ID = GitCommitId.trim()
UnitTestResult="False"
DeploymentArtifactsRepoBranch = "master"

XLD_RESOURCE_NODE = """<openshift.ResourcesFile name=\"/{{REPO_NAME}}-{{RESOURCE_FOLDER_NAME}}\" file=\"{{RESOURCE_FOLDER_PATH}}\"><tags><value>${PROJECT_NAMESPACE}</value></tags><scanPlaceholders>true</scanPlaceholders><preScannedPlaceholders>true</preScannedPlaceholders><placeholders /><delimiters>{{ }}</delimiters></openshift.ResourcesFile>"""

node('prd-xebia-build-agent') {
    stage("Execute Build Job - ${SERVICE_NAME}") {  

        if(SERVICE_NAME == "") {
            error "Build Parameter - ServiceName is missing"
        }

        if(GIT_BRANCH_NAME == "" && GIT_COMMIT_ID == "") {
            error "Build Parameter - Either one of GitCommitId or GitBranchName is mandatory"
        } 
        
        if (GIT_COMMIT_ID != "" && GIT_COMMIT_ID.length() < 7) {
            error "Build Parameter - Must have atleast 7 characters for the gitCommitId"
        }

        if(ENV_PROFILE_NAME == "") {
            error "Build Parameter - EnvProfileName is missing"
        }

        if(XLD_FOLDER == "") {
            error "Build Parameter - XLDFolder is missing"
        }

        if(PROJECT_NAMESPACE == "") {
            error "Build Parameter - ProjectNamespace is missing"
        }

        if(HAS_MAPR == "") {
            error "Build Parameter - HasMapr is missing"
        }

        executeBuildFlowFor(SERVICE_NAME, GIT_BRANCH_NAME, GIT_COMMIT_ID)
        println '********* Execute Build Job Successful **********'
    }
}

def executeBuildFlowFor (repoName, branchName, gitCommitId) {
    
    stage("Git Checkout") {
        println "******** Checking out source code from Git *********"
        gitCheckoutFor(repoName, branchName, gitCommitId)
        println "******** Git Checkout Successful *********"
    }

    stage("Push Github Topics as Pod Labels") {
        def topicsJson = readJSON text: getRepoTopics(repoName)
        println "Topics For ${repoName} = ${topicsJson.names}"

        def supportESNum = ""
        def supportServerity = ""

        topicsJson.names.each() {
            if(it.contains("support")) {
                 if(it.contains("support-level")) {
                     supportServerity = it.split("-")[2]
                 } else {
                     supportESNum = it.split("-")[1]
                 }
            }
            if(it.contains("rollback-dockerfile")) {
                DeploymentArtifactsRepoBranch = "rollback"
            }
        }

        if(supportESNum == "") {
            println "Unable to find the support-* from git topics for repository=${repoName}"
        } else {
            println "Found support topics - supportESNum=${supportESNum}"
            updateYaml("${repoName}/${DEPLOYMENT_YAML_PATH}", "EventScenario", supportESNum.toUpperCase())
        }
        
        if(supportServerity == "") {
            println "Unable to find the support-level-<severity>* from git topics for repository=${repoName}"
        } else {
            println "Found support topics - supportServerity=${supportServerity}"
            updateYaml("${repoName}/${DEPLOYMENT_YAML_PATH}", "SupportLevel", supportServerity)
        }
     }
		 
    stage("Build Docker Image") {
        
        gitCheckoutFor(DEPLOYMENT_ARTIFACTS_REPO, DeploymentArtifactsRepoBranch, "")
        echo "Using ${DeploymentArtifactsRepoBranch} branch for ${DEPLOYMENT_ARTIFACTS_REPO}"
        
        if(HAS_MAPR.equalsIgnoreCase("NO")) {
            FOLDER_NAME = "services"
        }
        else {
            FOLDER_NAME = "mapr"
        }

        repoDockerFileExists = sh(
             script: "find ./${repoName} -name 'Dockerfile' -exec wc -l {} \\;",
             returnStdout: true
        ).trim()
        if(repoDockerFileExists?.trim()) {
            println "*********** Bulding Docker Image from local docker file*************"
            buildDockerImageInProject(repoName, env.gitCommitId)
            println "*********** Bulding Docker Image Successful *************"
        } else {
            println "*********** Dcokerfile does not exist. build will fail*************"
           return
        }
    }
	
    stage("Aqua Scan Docker Image") {
        aqua locationType: 'local', localImage: "${DOCKER_REGISTRY_URL}/${repoName}:${env.datetime}-${env.gitCommitId}", onDisallowed: 'pass', notCompliesCmd: '', policies: 'Default', register: false, registry: 'Docker UAT', showNegligible: false
        println "*********** Aqua scan successful *************"
    }

    stage("Push to Docker Registry") {
        sh("docker login ${DOCKER_REGISTRY_URL} --username ${DOCKER_REGISTRY_USERNAME} --password ${DOCKER_REGISTRY_PASSWORD}")
        sh("docker push ${DOCKER_REGISTRY_URL}/${repoName}:${env.datetime}-${env.gitCommitId}")
        sh("docker push ${DOCKER_REGISTRY_URL}/${repoName}:latest")
        sh("docker rmi ${DOCKER_REGISTRY_URL}/${repoName}:${env.datetime}-${env.gitCommitId}")
        sh("docker rmi ${DOCKER_REGISTRY_URL}/${repoName}:latest")
        println "*********** Pushing docker image to registry Successful *************"
    }

    stage("Build XL Deploy DAR Package") {
        sh("cp -r ./${repoName}/k8s/* .")
        sh "cp ./${DEPLOYMENT_ARTIFACTS_REPO}/xebia/${XL_DEPLOYIT_MANIFEST_FILE_NAME} ${XL_DEPLOYIT_MANIFEST_FILE_NAME}"

        resourceFiles = sh(
                    script: "find ./${repoName}/k8s/ -name '*.yml' -print",
                    returnStdout: true
            ).trim()

        resourceFiles = resourceFiles.replace("./${repoName}/k8s", "")
        println "************ Resources in k8s Folder ************"
        println "${resourceFiles}"

        xldResourcesNode = generateResourcesOnXLDManifestFile(repoName, resourceFiles)     
        println("************* Generated XLD Resources Node *****************")
        println "${xldResourcesNode}"

        sh("sed -i 's~{{IMAGE_VERSION}}~${env.datetime}-${env.gitCommitId}~g' ${K8S_DEPLOYMENT_YAML}");

        sh("sed -i 's~minReadySeconds:[ 0-9]*~minReadySeconds: 10~g' ${K8S_DEPLOYMENT_YAML}");

        sh("sed -i 's~{{ARTIFACT_VERSION}}~${env.datetime}-${env.gitCommitId}~g' ${XL_DEPLOYIT_MANIFEST_FILE_NAME}");
        sh("sed -i 's~{{XLD_FOLDER}}~${XLD_FOLDER}~g' ${XL_DEPLOYIT_MANIFEST_FILE_NAME}");

        if(XLD_FOLDER.equalsIgnoreCase("Snapshots")) {
            sh("sed -i 's~{{REPO_NAME}}~${repoName}-snapshot~g' ${XL_DEPLOYIT_MANIFEST_FILE_NAME}");
        }
        else {
            sh("sed -i 's~{{REPO_NAME}}~${repoName}~g' ${XL_DEPLOYIT_MANIFEST_FILE_NAME}");
        }

        sh("sed -i 's~{{REPO_NAME}}~${repoName}~g' ${XL_DEPLOYIT_MANIFEST_FILE_NAME}");
        sh("sed -i 's~{{XLD_RESOURCES_NODES}}~${xldResourcesNode}~g' ${XL_DEPLOYIT_MANIFEST_FILE_NAME}");

        xldCreatePackage artifactsPath: "", manifestPath: "${XL_DEPLOYIT_MANIFEST_FILE_NAME}", darPath: '${serviceName}-${gitCommitId}.dar'
        println "### Build XL Deploy DAR Package Successful ###";
    }

    stage('XL Deploy Publish') {  
        xldPublishPackage serverCredentials: 'XldCreds', darPath: '${serviceName}-${gitCommitId}.dar'
        println "Pushed docker image with version ${env.gitCommitId}"
        println "Cleaning up workspace ..."
        deleteDir()
        println "### XL Deploy Publish Successful ###"
    }   
}

def gitCheckoutFor(repoName, branchName, gitCommitId) {
    withCredentials([
         [$class: 'UsernamePasswordMultiBinding', credentialsId: GIT_CREDENTIAL, usernameVariable: 'GIT_USERNAME', passwordVariable: 'GIT_PASSWORD']
        ]) {
            def repoUrl = repoName + '.git'
            println "Pulling code for repoUrl =" + repoUrl
            sh("rm -rf ${repoName}")
            if(gitCommitId) {
                println "Checking out using git commit id for ${repoName}"
                sh("git clone https://${GIT_USERNAME}:${GIT_PASSWORD}@${GIT_DOMAIN}${repoUrl} ${repoName}")
                sh("git -C ./${repoName} reset --hard ${gitCommitId}")
            }
            else if(branchName) {
                println "Checking out using branch name for ${repoName}"
                sh("git clone --branch ${branchName} https://${GIT_USERNAME}:${GIT_PASSWORD}@${GIT_DOMAIN}${repoUrl} ${repoName}")
            }
            else {
                error "Both branchName and gitCommitId are null, Either one of them is mandatory"
            }
        }
}

def getLatestCommitIdFor(repoName, branchName) {
    withCredentials([
         [$class: 'UsernamePasswordMultiBinding', credentialsId: GIT_CREDENTIAL, usernameVariable: 'GIT_USERNAME', passwordVariable: 'GIT_PASSWORD']
         ]) {
            latestGitCommitId = sh(
                    script: "git ls-remote https://${GIT_USERNAME}:${GIT_PASSWORD}@${GIT_DOMAIN}${repoName} ${branchName} | cut -f1",
                    returnStdout: true
            ).trim()
        }
    return latestGitCommitId.substring(0,7)
}




def generateResourcesOnXLDManifestFile(repoName, resourceFiles) {
    def xldResourcesNode = "";
    ymlFiles = resourceFiles.split('\n');

    def resourceNames = ["configmap", "secret", "deployment", "service", "route", "hpa"]
    
    for(int index=0; index < resourceNames.size(); index++) {
        ymlFiles.each() {
            if(it) {
                if(it.contains(resourceNames[index])) {
                    resourceNode = "${XLD_RESOURCE_NODE}";
                    resourceNode = resourceNode.replace("{{RESOURCE_FOLDER_PATH}}", it);
                    resourceNode = resourceNode.replace("{{REPO_NAME}}", index+2 + "-" + repoName);
                    println "Updating resource file name for ${resourceNames[index]} = " + it.contains(resourceNames[index])
                    resourceNode = resourceNode.replace("{{RESOURCE_FOLDER_NAME}}", it.split("/")[2]);
                    xldResourcesNode = xldResourcesNode + resourceNode;
                }
            }
            else {
                error "Unable to retrieve the Yml files inside k8s folder for ${repoName}";
            }
        }
    }
    return xldResourcesNode;
}

def getRepoTopics(repoName) {
    def topics = ""
    withCredentials([
         [$class: 'UsernamePasswordMultiBinding', credentialsId: GIT_CREDENTIAL, usernameVariable: 'GIT_USERNAME', passwordVariable: 'GIT_PASSWORD']
        ]) {
            topics= sh (
                script: "curl -X GET https://${GIT_USERNAME}:${GIT_PASSWORD}@vaprd078.schneider.com/api/v3/repos/schneider/${repoName}/topics -H 'Accept: application/vnd.github.mercy-preview+json'",
                returnStdout: true
            )
          }
    return topics
}

def updateYaml(yamlPath, key, value) {
        sh("sed -i 's~{{~<~g' ${yamlPath}");
        sh("sed -i 's~}}~>~g' ${yamlPath}");
        deploymentYaml = readYaml file: "${yamlPath}"

        podLabelsNode = deploymentYaml.spec.template.metadata.labels
        podLabelsNode.put(key, value)

        deploymentYaml.spec.template.metadata.labels = podLabelsNode

        sh("rm -rf ${yamlPath}")
        
        writeYaml file: "${yamlPath}", data: deploymentYaml

        sh("sed -i 's~<~{{~g' ${yamlPath}");
        sh("sed -i 's~>~}}~g' ${yamlPath}");
}


def buildDockerImageInProject( repoName, gitCommitId){
    sh("docker build -t ${DOCKER_REGISTRY_URL}/${repoName}:${env.datetime}-${env.gitCommitId} -t ${DOCKER_REGISTRY_URL}/${repoName}:latest ${repoName}")
}
